# Roseachy Desk 2.16.11

Adaptive premium redesign and precise appearance controls. The full app remains a static Cloudflare Pages project, with no build command or new runtime dependencies.

## Downloads

The deployment ZIP has index.html, sw.js, manifest.json, _headers, _redirects, two existing JavaScript files, and six existing icons at its root. Upload it through Cloudflare Pages Direct Upload. This task does not deploy to Cloudflare.

The standalone Preview.html embeds scripts/icons and can be served with a local HTTP server. It retains local persistence; browsers may restrict storage for file:// URLs. The Visual-Report.html is a self-contained before/after screenshot gallery using synthetic data.

## Source and preservation

- original/: the user's uploaded 2.16.8 build, unmodified.
- baseline/: the previously verified 2.16.10 build used for incremental implementation.
- app/: released 2.16.11 code. Only index.html and sw.js changed from baseline.
- tests/: reproducible presentation patch, canonical CSS, regression and browser checks.
- results/ and reports/: actual verification evidence.
- checkpoints/: recoverable deployment ZIPs.
- REQUEST-REDESIGN.md and REQUEST-PRECISION.md: the user's specifications.

Existing numerical appearance preferences are retained. Old named shapes migrate to 25/40/55/75. Fresh appearance defaults use 80 roundness, 30 border thickness, and 50 shadow effect. Each control accepts every integer 0–100. Maximum control radii use actual half-height, while cards have proportional 16/28/40px scales. Borders use fractional 0–3px inset edges with stable dimensions. Shadows interpolate offset, blur, spread and alpha without rounded stages.

## Reproduce

Use Python 3 with Playwright, Pillow, and installed Chromium, and Node with the parser packages in tools/package-lock.json. Set the Chromium executable in tests/common.py for your environment. Install parser packages in tools with npm ci. Run node tests/patch_upgrade.cjs to rebuild app/index.html and sw.js from baseline using the supplied stylesheet and geometry/tokens helpers. This intentionally overwrites app/index.html and sw.js; change the helpers to preserve new work.

Run python tests/validate.py for the existing business and PWA suite. Dedicated UI checks include appearance_precision.py, control_geometry.py, responsive_matrix.py, extreme_appearance.py, settings_navigation.py, extra_states.py, field_states.py, visual_interactions.py and production_console.py. Test hooks are inserted only by the harness and do not ship in the application.

See reports/VERIFICATION.md for executed results and limitations.
