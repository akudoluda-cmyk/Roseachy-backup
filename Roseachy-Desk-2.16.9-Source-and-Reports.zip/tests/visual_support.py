from common import *
THEMES=['cobalt','ember','pearl','cyanflux','coralbank','monomint']
WIDTHS=[320,375,390,425,768,1024,1280,1440]
def seed(page):
 fixture(page,6,0)
 page.evaluate('''async()=>{const T=__test,$=id=>document.getElementById(id),s=T.getStock();
 const names=['Paracetamol 500mg','Bottled water','Vitamin C','Laundry soap','First aid kit','Rice 1kg'];s.forEach((p,i)=>p.name=names[i]);s[0].qty=s[0].batches[0].qty=5;s[0].lowThreshold=10;T.setStock(s);T.setOpening(T.stockSnapshot());
 const rows=[{id:'visual-cash',type:'sale_cash',productId:s[1].id,productName:s[1].name,note:s[1].name,qty:2,amount:200,unitPrice:100,unitSellingPrice:100,costSnapshot:60,division:s[1].division,ts:new Date().toISOString()},
 {id:'visual-credit',type:'sale_credit',purchaseGroupId:'visual-credit-cart',productId:s[2].id,productName:s[2].name,note:s[2].name,party:'Ada',qty:3,amount:300,unitPrice:100,unitSellingPrice:100,costSnapshot:60,splitCredit:300,division:s[2].division,ts:new Date().toISOString()}];
 await T.inventoryCommit(()=>{const e=T.commitSalesLedger(rows);if(e)throw Error(e);return true},'Sales Desk');await T.runManualDaySave();
 const m=T.getMarketState();m.suppliers=[{id:'visual-supplier',name:'Ade Wholesale',createdAt:'2026-10-20T12:00:00Z',updatedAt:'2026-10-20T12:00:00Z'}];m.requests.push({id:'visual-request',name:s[3].name,count:2,status:'requested'});T.setMarketState(m);T.setNotes([{id:'visual-note',text:'Count the pharmacy shelf before closing.\\nConfirm the remaining supplier balance.',createdAt:'2026-10-20T12:00:00Z',savedAt:'2026-10-27T09:00:00Z'}]);await T.RS.whenSaved();T.render();
 T.switchDesk('financial',false);$('finSetupPassword').value=$('finSetupPassword2').value='2741';$('finAnchorInput').value=200000;$('finAnchorMode').value='day';await T.finSetup();T.switchDesk('sales');
 }''')
def screen(page,name):
 page.evaluate('''async name=>{const T=__test,$=id=>document.getElementById(id);
 for(const id of ['creditOverlay','cartCorrectionOverlay','syncOverlay'])$(id)?.classList.add('hidden');
 if(name==='market'){T.switchDesk('market',false);document.querySelector('[data-mview="active"]').click();}
 else if(name==='suppliers'){T.switchDesk('market',false);document.querySelector('[data-mview="suppliers"]').click();}
 else if(name==='financial'){T.switchDesk('financial',false);if(RoseachyFinance.locked()){$('finUnlockPass').value='2741';await T.finUnlock();}}
 else if(name==='settings')T.switchDesk('settings',false);
 else{T.switchDesk('sales',false);const tabs={sales:'tabBtnTx',stock:'tabBtnStock',reports:'tabBtnReport',notes:'tabBtnNotes',analytics:'tabBtnAnalytics',history:'tabBtnTx',credit:'tabBtnTx'};$(tabs[name]).click();if(name==='history'||name==='credit'){document.querySelector('[data-history-view="'+(name==='credit'?'credit':'saved')+'"]').click();$('creditHistoryPane'===name?'creditHistoryPane':'historyCard')?.scrollIntoView();}}
 window.scrollTo(0,0);
 }''',name)
 page.wait_for_timeout(80)
def theme(page,name,mode):
 page.evaluate('v=>__test.saveAppearanceSettings({...__test.getAppearanceSettings(),theme:v.name,colorMode:v.mode,animation:"off"},true)',{'name':name,'mode':mode})

MEASURE='''()=>{
 const canvas=document.createElement('canvas');canvas.width=canvas.height=1;const cx=canvas.getContext('2d',{willReadFrequently:true});
 const rgb=value=>{cx.clearRect(0,0,1,1);cx.fillStyle=value;cx.fillRect(0,0,1,1);return [...cx.getImageData(0,0,1,1).data].map((v,i)=>i===3?v/255:v)};
 const lum=c=>{const v=c.slice(0,3).map(v=>{v/=255;return v<=.04045?v/12.92:((v+.055)/1.055)**2.4});return v[0]*.2126+v[1]*.7152+v[2]*.0722};
 const ratio=(a,b)=>{const x=lum(a),y=lum(b);return (Math.max(x,y)+.05)/(Math.min(x,y)+.05)};
 const composite=(a,b)=>a.slice(0,3).map((v,i)=>v*a[3]+b[i]*(1-a[3])).concat(1);
 function bgs(el){const chain=[];for(let e=el;e;e=e.parentElement)chain.unshift(e);let colors=[[255,255,255,1]];for(const e of chain){const s=getComputedStyle(e),bg=rgb(s.backgroundColor);colors=colors.map(c=>composite(bg,c));const stops=s.backgroundImage.match(/#[a-f\\d]{3,8}|rgba?\\([^)]*\\)/gi);if(stops?.length)colors=stops.map(v=>composite(rgb(v),colors[0]));}return colors;}
 const visible=e=>{if(!e.checkVisibility({checkVisibilityCSS:true,checkOpacity:true}))return false;for(let a=e.parentElement;a;a=a.parentElement)if(a.tagName==='DETAILS'&&!a.open&&!a.querySelector(':scope>summary')?.contains(e))return false;const s=getComputedStyle(e),r=e.getBoundingClientRect();return r.width>0&&r.height>0&&s.visibility!=='hidden'&&s.display!=='none'&&!e.closest('.hidden')};
 const results=[];for(const e of document.querySelectorAll('div,h1,h2,h3,h4,h5,p,label,span,small,strong,b,button,summary,input,select,textarea,th,td,em')){
 if(!visible(e)||e.closest('.rs-swipe-labels')||['checkbox','radio','range','color','hidden'].includes(e.type))continue;const s=getComputedStyle(e);if(parseFloat(s.opacity)===0)continue;
 const text=(e.tagName==='INPUT'?e.value||e.placeholder:e.textContent).trim();if(!text||([...e.children].some(ch=>ch.textContent.trim())&&!['BUTTON','SUMMARY','LABEL','TD','TH'].includes(e.tagName)))continue;
 const ps=e.tagName==='INPUT'&&!e.value&&e.placeholder?getComputedStyle(e,'::placeholder'):s;const fill=ps.webkitTextFillColor||ps.color,fg=rgb(fill),bg=bgs(e);if(fg[3]<.1)continue;
 const large=parseFloat(s.fontSize)>=24||(parseFloat(s.fontSize)>=18.66&&parseInt(s.fontWeight)>=700),required=large?3:4.5;
 const indicator=e.closest('.hasInd')?.querySelector(':scope > .tabInd');if(indicator&&e.classList.contains('active')&&!e.closest('.marketViewTabs')){const a=e.getBoundingClientRect(),b=indicator.getBoundingClientRect();if(b.width>0&&b.height>a.height*.7)bg.splice(0,bg.length,rgb(getComputedStyle(indicator).backgroundColor));}const contrast=Math.min(...bg.map(c=>ratio(composite(fg,c),c)));
 results.push({id:e.id,tag:e.tagName,classes:e.className,text:text.slice(0,70),contrast:+contrast.toFixed(2),required,foreground:fill,background:bg,fontSize:s.fontSize,disabled:!!e.disabled});
 }
 return {pageWidth:document.documentElement.clientWidth,scrollWidth:document.documentElement.scrollWidth,failures:results.filter(x=>x.contrast+.02<x.required),tested:results.length,results};
}'''
