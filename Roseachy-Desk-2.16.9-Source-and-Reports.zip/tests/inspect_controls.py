from visual_support import *
with sync_playwright() as p:
 b=launch(p);c=context_for(b,'app');page,err=open_page(c);seed(page);page.set_viewport_size({'width':320,'height':900})
 theme(page,'ember','light');screen(page,'sales');page.locator('#txEntryCard').scroll_into_view_if_needed();page.screenshot(path=str(ROOT/'results/screenshots/after/detail-sales.png'))
 for name in ['settings','financial','analytics']:
  screen(page,name)
  if name=='settings':page.locator('.themeGrid').scroll_into_view_if_needed()
  page.screenshot(path=str(ROOT/'results/screenshots/after'/f'detail-{name}.png'))
  print(name,page.evaluate(MEASURE)['failures'])
 print(page.evaluate('''()=>{const e=document.getElementById('deskMenuBtn'),r=e.getBoundingClientRect(),range=document.createRange();range.selectNodeContents(e);return {outer:e.outerHTML,rect:r.toJSON(),text:range.getBoundingClientRect().toJSON(),before:getComputedStyle(e,'::before').content,after:getComputedStyle(e,'::after').content}}'''))
 b.close()
