# Roseachy Desk 2.16.8 — UX refinements

This release continues from the verified 2.16.7 source. The requested changes are recorded verbatim in `REQUEST.md`.

## Deploy to Cloudflare Pages

Use `Roseachy-Desk-2.16.8-Cloudflare-Pages.zip`. It contains the 13 static application files at the ZIP root, including `index.html`, `_headers`, `_redirects`, `sw.js`, `manifest.json`, `js/`, and `icons/`. There is no build step or production dependency install.

For a GitHub source archive, extract it and upload the inner folder containing `index.html`. Cloudflare has not been deployed from this workspace.

## What changed

- Select any item in an open or completed cart to edit its quantity. Totals update immediately; completed records save atomically with stock, payments, and saved-day copies.
- One Add to Cart button adds the first or next product, merges repeated products, and clears the active input. Each cart item has a compact remove control. Reviewing a cart does not add an item.
- The selected-product field has a compact × clear control.
- Notes collapse by default, expand into an inline editor, and update Last Saved when saved. Original creation dates and note IDs are retained.
- Grouped sales have restrained theme-aware table tinting without repeated cart badges or thick group borders.
- Credit History uses a quieter private-account link and a Show Total Outstanding checkbox; amounts start masked.
- Supplier purchases require a valid explicit Amount Paid. Empty is not zero. Explicit zero supports supplier credit. The brief prompt stops when the amount is valid and respects reduced motion.
- Cart editors use a friendly Cart Purchase heading, retaining internal group identifiers in storage.

Stock products continue using their recorded selling price and quantity-discount rules. Manual, non-stock lines retain editable unit amounts. Existing refund, repayment, stock, historical-day, and concurrent-edit safeguards remain in effect.

## Source and validation package

- `app/`: final application source.
- `baseline/`: unchanged 2.16.7 source; `original/` is the portable test baseline.
- `tests/`: browser workflows, static checks, and validation runner. Test hooks are injected into browser responses and are absent from the production application.
- `results/`: machine-readable results, logs, synthetic recovery fixtures, and screenshots.
- `reports/`: completion and validation notes.
- `checkpoints/`: recoverable intermediate static ZIPs.
- `source-history.bundle`: recoverable Git history.
- `tools/package.json` and lockfile: static-parser tooling.

To rerun checks, install the tooling with `npm ci --prefix tools` and Python Playwright and Pillow. Browser tests use Chromium at `/usr/bin/chromium`. Run `python tests/validate.py`. The `patch_*.py` files document historical implementation steps; do not rerun them against the finished source.

No real business data was used in the tests. Earlier releases and the GitHub main branch are preserved.
