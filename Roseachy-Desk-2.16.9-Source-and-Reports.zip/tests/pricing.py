from common import *
import sys
mode=sys.argv[1] if len(sys.argv)>1 else 'app'
with sync_playwright() as p:
 b=launch(p);c=context_for(b,mode);page,errors=open_page(c);page.on('dialog',lambda d:d.accept());fixture(page,3,0)
 result=page.evaluate('''async()=>{
 const T=__test,$=id=>document.getElementById(id),checks=[];
 const check=(name,actual,expected)=>checks.push({name,actual,expected,passed:JSON.stringify(actual)===JSON.stringify(expected)});
 const products=T.getStock();products.forEach((p,i)=>{p.price=[125.25,280.5,75][i];p.costPrice=p.currentCostPrice=40+i;p.priceMode='manual'});T.setStock(products);T.setOpening(T.stockSnapshot());await T.RS.whenSaved();
 $('type').value='sale_cash';T.resetTxForm();T.chooseProductSuggestion(products[0]);$('qty').value=2;T.computeTotal();
 check('Product A selection',[$('amount').value,$('totalAmount').value],['125.25','250.50']);
 T.chooseProductSuggestion(products[1]);T.computeTotal();check('Product B replaces displayed and saved price',[$('amount').value,$('totalAmount').value,T.validateAndBuildTx().obj.unitPrice],['280.5','561.00',280.5]);
 $('type').value='purchase_cash';T.refreshTypeUI();check('Purchase uses cost',Number($('amount').value),41);
 $('type').value='sale_transfer';T.refreshTypeUI();check('Sale restores selling price',[Number($('amount').value),Number($('totalAmount').value)],[280.5,561]);
 products[2].quantityPricingEnabled=true;products[2].quantityPricingQuantity=3;products[2].quantityPricingPrice=200;T.setStock(products);T.chooseProductSuggestion(products[2]);$('qty').value=7;T.computeTotal();check('Existing quantity discount with remainder',Number($('totalAmount').value),475);
 $('qty').value=2;T.computeTotal();check('Below threshold',Number($('totalAmount').value),150);
 $('type').value='sale_credit';T.refreshTypeUI();check('Credit retains configured total',Number($('totalAmount').value),150);
 return checks;
 }''')
 (ROOT/'results'/f'pricing-{mode}.json').write_text(json.dumps({'checks':result,'errors':errors},indent=2));print(json.dumps(result,indent=2));b.close()
 if not all(x['passed'] for x in result) or errors:sys.exit(1)
