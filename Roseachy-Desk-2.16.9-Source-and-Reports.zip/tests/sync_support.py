from common import *
import traceback
result={'checks':[]};out=ROOT/'results/item-sync.json'
def record(name,detail=None):
 result['checks'].append({'name':name,'status':'passed','detail':detail});out.write_text(json.dumps(result,indent=2));print('PASS',name,flush=True)
def unlock(page):
 page.evaluate('''async()=>{__test.switchDesk('financial',false);if(RoseachyFinance.locked()){document.getElementById('finUnlockPass').value='2741';await __test.finUnlock()}if(RoseachyFinance.locked())throw Error('Unlock failed')}''')
def enroll(b,targets):
 pages=[]
 for target in targets:
  c=context_for(b,target);page,errors=open_page(c);fixture(page,4,0);page.on('dialog',lambda d:d.accept())
  page.evaluate('''async()=>{const T=__test,m=T.getMarketState();m.suppliers=[{id:'ade',name:'Ade Wholesale',createdAt:'2026-01-01T00:00:00Z',updatedAt:'2026-01-01T00:00:00Z'}];await T.RS.atomic(()=>T.setMarketState(m));T.switchDesk('financial',false);for(const id of ['finSetupPassword','finSetupPassword2'])document.getElementById(id).value='2741';document.getElementById('finAnchorInput').value='200000';document.getElementById('finAnchorMode').value='day';await T.finSetup();}''')
  backup=page.evaluate('()=>__test.roseachySafeBackup()');recovery=ROOT/'results'/f'sync-recovery-{len(pages)}.json';recovery.write_text(json.dumps(backup));page.evaluate('b=>__test.SmartSync.verifyRecovery(b)',json.loads(recovery.read_text()));pages.append((page,errors))
 a,z=[x[0] for x in pages];offers=[page.evaluate('()=>__test.SmartSync.offer()') for page,_ in pages]
 remoteA=a.evaluate('f=>__test.SmartSync.unprotect(f)',offers[1]);remoteB=z.evaluate('f=>__test.SmartSync.unprotect(f)',offers[0])
 for page,remote in [(a,remoteA),(z,remoteB)]:page.evaluate('r=>__test.SyncPrivacy.trust(r.sender.deviceId,r.sender.publicKey,true)',remote)
 choices={'sameBusiness':True,'approvedBy':'Synthetic owner','snapshotScope':'shared verified baseline'}
 plan=a.evaluate('v=>__test.SmartSync.initialPlan(v.remote,v.choices)',{'remote':remoteA,'choices':choices});assert not plan['conflicts'],plan['conflicts']
 cp=a.evaluate('v=>__test.SmartSync.createCheckpoint(v.remote,v.choices)',{'remote':remoteA,'choices':plan['choices']})
 for page,_ in pages:page.evaluate('cp=>__test.SmartSync.acceptCheckpoint(cp,{sameBusiness:true,approvedBy:"Synthetic owner"})',cp)
 for sender,receiver in [(a,z),(z,a)]:receiver.evaluate('async f=>__test.SmartSync.acceptAcknowledgement(await __test.SmartSync.unprotect(f))',sender.evaluate('()=>__test.SmartSync.acknowledgement()'))
 return pages

def exchange(sender,receiver,duplicate=False):
 unlock(sender);unlock(receiver);signed=sender.evaluate('()=>__test.SmartSync.updates()');remote=receiver.evaluate('f=>__test.SmartSync.unprotect(f)',signed)
 for _ in range(2 if duplicate else 1):receiver.evaluate('r=>__test.SmartSync.merge(r)',remote)
 return remote
