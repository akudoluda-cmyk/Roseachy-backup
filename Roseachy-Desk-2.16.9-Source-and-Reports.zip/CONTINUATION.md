# ROSEACHY DESK — CONTINUATION INSTRUCTION
## Refine Colour Hierarchy, Reduce Icon Clutter & Establish a Three-Colour Design System

Continue working on the **existing Roseachy Desk application and the UI refinement already in progress**.

Do not restart the project, discard previous work, generate a separate mockup, or rebuild the interface from scratch.

I have reviewed the proposed visual direction and want to refine it before proceeding further.

### 1. Correct the Main Design Problem

The previous visual direction uses too many prominent icons, colourful icon backgrounds, competing accent colours, and decorative highlights.

**This makes the interface feel too shouty and visually busy.**

I want Roseachy Desk to feel:

- Calm and professional.
- Premium and modern.
- Clean and well-organized.
- Easy to scan quickly.
- Visually distinctive without excessive decoration.
- Intuitive, with clear guidance on what matters and what to do next.

The objective is not to remove all visual distinction or make everything plain. The objective is to achieve **strong visual hierarchy with fewer colours, fewer icons, and more deliberate emphasis**.

### 2. Enforce a Three-Colour Palette

Use a maximum of **three principal colours per theme**:

1. **Neutral foundation:** Existing white, off-white, grey, charcoal, or near-black surfaces and text.
2. **Primary accent:** One dominant accent colour for active navigation, primary buttons, selected states, and important interactive elements.
3. **Secondary accent:** At most one complementary colour, used selectively where it adds meaningful distinction.

Use either a monochromatic palette, with carefully selected shades of one hue, or a restrained complementary palette.

Do not combine several unrelated accent colours simply to make individual cards, icons, or sections look different.

For example, a navy-and-blue monochromatic theme may use navy for active navigation, medium blue for primary actions, and pale blue tints for subtle highlights. A complementary theme may use a dominant blue with restrained teal accents.

These are examples of the design approach, not instructions to replace Roseachy's existing themes.

**Important rules:**

- Limit prominent interface colours to the chosen palette.
- Reuse the same accent colours consistently across the application.
- Use lighter and darker tonal variations for depth instead of introducing additional hues.
- Keep cards, tables, and content areas predominantly neutral.
- Reserve strong colour emphasis for elements that genuinely need attention.
- Do not add rainbow-style charts, multicoloured icon tiles, or unrelated accent colours throughout the interface.
- Preserve essential warning and error communication, but keep these treatments small, semantic, and non-decorative.

White, grey, charcoal, and near-black may be used as structural neutrals. However, do not use that allowance to introduce more decorative accent colours.

### 3. Reduce the Number and Visual Weight of Icons

The current design contains too many icons, and many are too prominent.

Simplify icon usage throughout the application.

**Required changes:**

- Remove decorative icons that provide no meaningful information.
- Use icons only when they improve recognition, navigation, or understanding.
- Keep icons small and consistent in size and stroke weight.
- Prefer simple, restrained outline icons.
- Use the surrounding text to communicate meaning rather than expecting users to interpret an icon.
- Make icons inherit the surrounding text colour by default.
- Use the primary accent for selected or particularly important icons only.
- Remove the coloured square, circle, or gradient backgrounds behind ordinary icons.
- Avoid placing a bright icon beside every heading, card, product, and status label.
- Do not use multiple icons where one is sufficient.
- Keep icons subordinate to important text and values.

Navigation may retain the small icons necessary for recognition, but the active navigation state should be communicated primarily through a clear background, border, or restrained accent indicator.

Do not remove functional icons that users genuinely need, such as the cart, search, back, edit, delete, or menu controls. Refine their appearance rather than making them harder to identify or use.

### 4. Use Structure Instead of Colour to Separate Sections

Do not rely on different background colours to make every section distinguishable.

Improve differentiation through a consistent combination of:

- Clear headings.
- Appropriate typography.
- Consistent spacing.
- Subtle borders.
- Carefully differentiated neutral surfaces.
- Consistent alignment.
- Deliberate placement of primary actions.
- Restrained accent lines or indicators where useful.

Related information should visually belong together. Separate sections should be distinguishable without requiring different bright colours.

Avoid giving every card its own colour identity.

For example, supplier search, supplier summaries, and supplier records can share a neutral surface and consistent borders. The selected tab and primary action can use the dominant accent colour.

This creates hierarchy without visual clutter.

### 5. Apply the Simplified Design Across Roseachy

Continue refining the existing screens, particularly:

**Market Desk**

Keep the heading, description, tabs, search controls, supplier cards, purchase lists, and Smart Sync & Merge action clearly organized. Use restrained accents to show the active tab and important actions. Do not decorate every card with an icon and coloured background.

**Sales Desk**

Make the product selector, cart, quantities, purchase total, and payment controls easy to distinguish. The primary next action should be clear without competing with several equally prominent buttons.

Preserve the existing multi-item cart workflow, product search, quantity controls, incomplete-payment debt recording, and payment processing.

**Supplier Management and Supplier Debt Payment**

Use clear supplier rows, readable balances, subtle status indicators, and one obvious route to resolve an outstanding debt. Do not make every supplier row colourful or visually urgent.

**Transactions and Product History**

Keep the tables clean and information-focused. Use accent colours for active tabs and selected controls, not for every transaction row. Maintain readable quantities, prices, dates, references, and status labels.

**Weekly Summary, Reports, and Analytics**

Use restrained headings, neutral metric cards, and a consistent chart palette. Charts should remain clear and informative without using a different bright colour for every data point or category.

**Financial Desk**

Prioritize accuracy, readability, and a trustworthy visual style. Keep financial figures and account distinctions clear, while using colour sparingly for selected accounts, primary actions, and meaningful statuses.

**Credit Accounts, Credit History, Saved Days, Inventory, and Settings**

Apply the same design principles consistently. Preserve confidential balance visibility, historical records, inventory warnings, theme controls, and all existing navigation.

Do not create different visual systems for individual modules.

### 6. Preserve Roseachy's Existing Themes

Do not replace the established themes or make every theme use the same colours.

Preserve each theme's identity while applying the same hierarchy rules.

For each existing theme:

- Define one dominant accent and, where appropriate, one complementary accent.
- Keep backgrounds and cards predominantly neutral.
- Maintain readable text and control boundaries.
- Use the accent consistently for active navigation and primary actions.
- Avoid multicoloured decoration.
- Ensure the same components behave and look logically equivalent across themes.

Test the existing light and dark themes. Do not restore themes that were intentionally removed in earlier upgrades.

### 7. Establish a Clear Action Hierarchy

Each screen should make it easy to identify its most important action.

Use:

- **Primary action:** The dominant accent treatment for the most important local action.
- **Secondary action:** A restrained outline or neutral button.
- **Tertiary action:** A simple text or low-emphasis control.
- **Destructive action:** An unmistakable but restrained destructive treatment.
- **Selected state:** A consistent indication using the primary accent.
- **Status state:** A clear label supported by a restrained semantic indicator.

Do not style every button as a primary action.

Do not use the secondary accent merely to make an ordinary button look different.

### 8. Preserve Existing Functionality

This is a visual refinement of the implementation already in progress, not permission to redesign the application's architecture.

Do not change:

- Financial calculations.
- Inventory calculations.
- Credit Account privacy.
- Credit History.
- Automatic debt recording.
- Supplier debt handling.
- Saved Days and automatic day saving.
- Market Desk purchasing or restocking.
- Smart Sync & Merge.
- Backup and restore.
- Navigation and swipe behaviour.
- Existing cart and payment workflows.
- Persistent storage or historical records.

Do not remove useful information or controls simply to make the interface look minimalist.

Do not introduce unnecessary components, duplicate CSS systems, or new dependencies.

Make changes directly to the existing source code and reuse its current design tokens and theme structure wherever possible.

### 9. Test the Actual Interface

Inspect the rendered application after applying the changes.

Test at:

- 320px.
- 375px.
- 390px.
- 425px.
- 768px.
- 1024px.
- 1280px.
- 1440px.

Verify:

- The interface no longer feels overcrowded with icons.
- No screen uses a collection of unrelated accent colours.
- Active navigation remains easy to identify.
- Primary actions remain immediately recognizable.
- Cards and sections remain distinguishable.
- All labels, values, and status indicators remain readable.
- Light and dark themes retain sufficient contrast.
- No controls become hidden, clipped, or inaccessible.
- All existing buttons and workflows still function.

Check screens with actual populated data, long product names, long supplier names, large financial values, and populated transaction tables.

Retain screenshots where available and compare the revised design against the previous version.

Do not claim that a screen has been visually verified if it was not actually rendered and inspected.

### 10. Final Design Standard

The revised Roseachy interface must communicate hierarchy through **consistent structure, typography, spacing, and restrained colour** rather than an abundance of icons and decorative treatments.

The overall result should feel quieter, cleaner, more precise, and more professional.

The interface must not become flat or indistinguishable. Important actions, selected sections, financial information, and meaningful alerts must remain easy to recognize.

**The final direction is: a maximum of three principal colours, a mostly neutral foundation, one dominant accent, at most one complementary accent, fewer and quieter icons, and a clear visual hierarchy throughout the application.**

Continue from the current implementation, make the changes in the existing codebase, test the affected screens, and provide the updated preview, deployment package, and concise verification report.