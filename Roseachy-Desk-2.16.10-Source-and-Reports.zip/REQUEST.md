# ROSEACHY DESK — PREMIUM UI UPGRADE, DESIGN PRECISION & APPEARANCE SETTINGS

## PRIMARY OBJECTIVE

Transform Roseachy Desk's existing interface into a premium, sophisticated, modern, and beautifully refined business management application, closely inspired by the attached UI reference images.

The current interface feels somewhat dull, underutilizes its primary colors, lacks sufficient card hierarchy, and has inconsistent spacing and visual effects.

Additionally, the appearance settings need improvement, particularly corner roundness and border thickness controls.

**Core philosophy: Simple, intuitively brilliant, efficient, precise, and visually premium.**

Improve the existing interface without overengineering, introducing unnecessary dependencies, or compromising functionality.

## 1. MATCH THE VISUAL QUALITY OF THE REFERENCES

Study the attached reference images carefully.

The resulting interface should closely reflect their overall level of visual sophistication, including:

- Beautifully balanced layouts.
- Confident primary-color application.
- Premium card designs and surfaces.
- Elegant, well-rounded corners.
- Refined typography and spacing.
- Strong visual hierarchy.
- Sophisticated buttons and controls.
- Soft, intentional shadows.
- Beautifully composed financial summary cards.
- Clean, cohesive, modern aesthetics.

Do not merely make small cosmetic changes and describe the result as premium.

The improvement should be clearly noticeable and visually comparable in quality to the references.

Adapt their design principles to Roseachy Desk's existing functionality, rather than copying unrelated layouts or features.

## 2. IMPROVE PRIMARY-COLOR USAGE

The application's primary brand color should play a more significant role in the interface.

- Apply the primary color to important action buttons.
- Give selected major dashboard cards solid primary-color backgrounds.
- Use softer primary-color tints for supporting elements.
- Improve active navigation states.
- Make important figures and controls visually prominent.
- Maintain strong contrast between text and backgrounds.
- Keep less important elements quieter.

Not every card should use the primary color.

Establish an intentional balance between standout cards and understated supporting cards.

Preserve the identity of every existing theme.

## 3. PREMIUM CARD DESIGN

Refine cards throughout the application.

- Improve internal padding.
- Correct text positioned too close to card borders.
- Use more sophisticated corner rounding.
- Improve spacing between headings, values, descriptions, and controls.
- Introduce subtle surface depth.
- Remove harsh shadows and muddy backgrounds.
- Improve content alignment.
- Make important summary cards visually distinct.
- Maintain consistency across sections.

Cards should feel spacious, polished, cohesive, and professionally designed.

## 4. IMPROVE BUTTONS AND CONTROLS

Upgrade buttons to match the premium appearance of the references.

- Primary buttons should confidently use the active theme's primary color.
- Secondary buttons should remain visually restrained.
- Destructive actions must remain distinguishable.
- Improve padding, height, alignment, and corner rounding.
- Refine hover, pressed, focus, and disabled states.
- Ensure icons and labels are aligned correctly.
- Avoid excessive shadows, unnecessary gradients, or decorative complexity.

## 5. FIX TYPOGRAPHY AND SPACING

Perform a comprehensive spacing and alignment refinement.

- Prevent text from sitting too close to card boundaries.
- Improve internal spacing in panels and containers.
- Establish consistent padding.
- Improve the hierarchy between headings, labels, amounts, and descriptions.
- Prevent text clipping, overflow, and awkward wrapping.
- Improve input alignment.
- Maintain readability across desktop, tablet, and mobile.

Use a consistent spacing system rather than arbitrary adjustments.

## 6. IMPROVE IMPORTANT FINANCIAL SUMMARIES

Make high-priority financial information more visually prominent.

- Give selected summary cards stronger primary-color treatment.
- Improve numerical typography.
- Use hierarchy to distinguish key totals from supporting information.
- Make important dashboard information immediately recognizable.
- Improve spacing around figures and labels.
- Keep secondary information understated.

The interface should feel comparable to a beautifully designed modern finance dashboard.

## 7. FIX THE ZIGZAG PLACEHOLDER ARTIFACT

A strange zigzag pattern sometimes appears when the cursor approaches certain placeholders or input fields.

Investigate the underlying CSS or rendering cause.

Inspect:

- Hover and focus states.
- Outlines and borders.
- Shadows and gradients.
- Pseudo-elements.
- Masks and clipping.
- Transforms.
- Browser-specific rendering behavior.

Eliminate the issue at its source.

Ensure all affected fields remain visually clean during hovering, focusing, typing, and selection.

## 8. FIX THE SALES TOTAL SHADING

The Sales Total placeholder or display has an awkward surrounding shade.

- Identify the exact responsible styling.
- Remove unwanted gradients, overlays, or shadows.
- Correct background and border treatments.
- Improve its spacing and alignment.
- Make the section visually prominent but refined.
- Maintain consistency with the upgraded card system.

## 9. FULLY RESPONSIVE CORNER ROUNDNESS CONTROL — 0 TO 100

The existing corner roundness control in Appearance Settings is too limited.

Even at its maximum value, some interface elements do not become sufficiently rounded.

Upgrade the existing roundness setting into a fully responsive, continuous **0–100 adjustment system**.

### Required behavior

- Minimum value: 0.
- Maximum value: 100.
- Increment: 1.
- Every increase or decrease must produce a corresponding proportional change in the styling.
- Changes must be smooth, progressive, and predictable.
- No sudden jumps between values.
- No artificial limitation that prevents achieving beautifully rounded corners.
- The interface must update immediately while the slider is adjusted.

### Expected visual range

**0:** Square corners.

**25:** Slightly rounded corners.

**50:** Moderately rounded corners.

**75:** Strongly rounded, premium-looking corners.

**100:** Maximum appropriate rounding, allowing pill-shaped buttons and inputs and generously rounded cards where suitable.

Use proportional interpolation rather than a handful of predefined radius presets.

Do not round calculated CSS values unnecessarily to whole pixels if that creates visible jumps.

Ensure components remain structurally correct at maximum roundness.

Apply the setting consistently to relevant:

- Cards.
- Buttons.
- Input fields.
- Search bars.
- Modal containers.
- Dropdowns.
- Panels.
- Applicable navigation elements.

Use sensible component-specific radius mappings so a value of 100 produces maximum appropriate roundness without distorting layouts.

For example, a button may become fully pill-shaped, while a large rectangular card receives generous rounded corners rather than an inappropriate pill shape.

## 10. FULLY RESPONSIVE BORDER THICKNESS CONTROL — 0 TO 100

The existing Border Thickness setting does not update smoothly and consistently with each numerical adjustment.

Correct this behavior.

### Required behavior

- Minimum value: 0.
- Maximum value: 100.
- Increment: 1.
- Each numerical increment should correspond to a proportional change in rendered border thickness.
- The adjustment must be continuous rather than jumping between preset thickness levels.
- Changes must appear immediately.
- Moving the slider backward must reduce thickness smoothly.
- The value shown must accurately match the slider's position.
- Avoid inconsistent behavior between components.

### Important implementation detail

The slider range of 0–100 represents adjustment intensity, not literal pixel thickness.

Map this range proportionally to a visually sensible CSS border-width range.

Use fractional pixel values where appropriate for smooth interpolation instead of abruptly switching between whole-pixel presets.

At 0, applicable decorative borders should disappear.

At 100, borders should reach a clearly noticeable but controlled maximum thickness.

Ensure that:

- Card dimensions remain stable.
- Increasing border thickness does not unexpectedly shift layouts.
- Buttons and inputs maintain their intended dimensions.
- Borders remain visually consistent across the application.
- Required keyboard-focus indicators remain accessible.

Prefer inset borders or appropriate box-sizing techniques where necessary.

## 11. MAKE BOTH APPEARANCE SLIDERS PRECISE AND LIVE

The Corner Roundness and Border Thickness controls must behave like proper continuous adjustment sliders.

Both controls must:

1. Support the complete 0–100 range.
2. Move in increments of 1.
3. Display their current numerical values.
4. Update the interface immediately.
5. Respond accurately to mouse, touch, and keyboard input.
6. Change progressively without abrupt jumps.
7. Preserve the selected values after refresh or reopening the application.
8. Work across all existing themes.
9. Update relevant components consistently.
10. Maintain responsive behavior across desktop, tablet, and mobile.

Do not implement the sliders using a small collection of predefined styles such as low, medium, and high.

Use an efficient CSS-variable-based approach with continuous value interpolation wherever practical.

Avoid unnecessary re-rendering or complex JavaScript calculations.

**Essential requirement:** Both sliders must give users precise, genuinely continuous control over the application's appearance.

## 12. REFINE HOVER AND FOCUS INTERACTIONS

Improve interaction states across the application.

- Use subtle hover feedback.
- Maintain accessible focus indicators.
- Eliminate strange rendering artifacts.
- Keep transitions lightweight.
- Ensure consistent visual feedback.
- Respect reduced-motion preferences.
- Avoid distracting animations.

## 13. RESPONSIVE DESIGN

Preserve and improve responsiveness across desktop, tablet, and mobile.

- Ensure cards adapt correctly.
- Maintain sufficient padding.
- Prevent text and numeric overflow.
- Preserve appropriate touch target sizes.
- Maintain consistent visual hierarchy.
- Ensure appearance-setting adjustments do not break responsive layouts.

## 14. IMPLEMENTATION RULES

Keep the implementation simple, efficient, and maintainable.

- Reuse existing design tokens and CSS variables.
- Modify existing components instead of unnecessarily rebuilding them.
- Avoid adding external dependencies for visual refinements.
- Avoid duplicate styling and excessive overrides.
- Preserve all existing application functionality.
- Preserve sales, stock, credit, purchase, reporting, and transaction logic.
- Maintain compatibility with all supported themes.
- Remove redundant code only when confirmed safe.
- Prioritize performance and accessibility.
- Avoid excessive animations and expensive rendering effects.

Do not introduce unnecessary UI elements or configuration systems.

## 15. FINAL VERIFICATION

Thoroughly test the completed implementation.

Verify that:

- The interface visibly approaches the premium quality of the reference images.
- Major primary-color cards and buttons have stronger visual presence.
- Card spacing and padding are consistent.
- Text no longer crowds card borders.
- Financial summaries feel polished and prominent.
- The zigzag placeholder artifact is eliminated.
- Sales Total shading is corrected.
- Corner Roundness adjusts properly from 0 to 100.
- Border Thickness adjusts properly from 0 to 100.
- Every slider increment is reflected proportionally in the corresponding CSS values.
- No abrupt jumps or artificial slider plateaus occur.
- Both appearance settings update in real time.
- Both settings persist correctly.
- All existing themes remain compatible.
- Extreme appearance settings do not distort the UI.
- Mobile and desktop layouts remain functional.
- Existing business logic and records are unaffected.
- No new console errors or visual regressions appear.

## FINAL EXPECTATION

Roseachy Desk should feel noticeably closer to the attached reference designs in its visual quality, color hierarchy, card composition, typography, rounded corners, and overall refinement.

The interface should be beautiful without unnecessary complexity.

The Appearance Settings should offer genuinely precise, smooth, responsive, and intuitive 0–100 control over corner roundness and border thickness.

**Deliver a premium, elegant, visually confident, and professionally polished application that remains simple, intuitively brilliant, efficient, and precise.**

Implement the improvements directly in the existing codebase and preserve the original application's identity, architecture, data integrity, and functionality.