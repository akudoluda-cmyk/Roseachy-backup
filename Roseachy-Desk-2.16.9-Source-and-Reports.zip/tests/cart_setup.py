from common import *
results=[]
def run(name,code):
 try:
  page.wait_for_function('!__test.busy')
  detail=page.evaluate('async()=>{const T=__test,$=id=>document.getElementById(id);const assert=(x,m)=>{if(!x)throw Error(m)};'+code+'}')
  results.append({'name':name,'status':'passed','detail':detail});print('PASS',name,flush=True)
 except Exception as e:
  results.append({'name':name,'status':'failed','error':str(e)});print('FAIL',name,str(e)[:500],flush=True)
 (ROOT/'results/cart-setup.json').write_text(json.dumps(results,indent=2))
with sync_playwright() as p:
 b=launch(p);c=context_for(b,'app');page,errors=open_page(c);page.on('dialog',lambda d:d.accept());fixture(page,3,0)
 run('Create real transfer cart with shared receipt', '''
 $('type').value='sale_transfer';T.resetTxForm();$('holdBtn').click();
 for(const [i,q] of [[0,2],[1,3]]){T.chooseProductSuggestion(T.getStock()[i]);$('qty').value=q;T.computeTotal();$('holdBtn').click();}
 $('holdCustPaid').value=600;$('holdCustReturned').value=100;
 $('addBtn').click();await T.RS.whenSaved();
 assert(T.tx.length===2,'two lines');assert(T.tx.every(t=>t.type==='sale_transfer'),'method');assert(T.tx.reduce((s,t)=>s+t.amount,0)===500,'total');assert(T.calc().expectedBank===600&&T.calc().expectedCash===99900,'receipt and cash return');window.cartId=T.tx[0].purchaseGroupId;window.stockBefore=JSON.stringify(T.getStock());return T.calc().expectedBank;
 ''')
 run('Transfer to cash applies whole cart once and preserves stock', '''
 window.stockBefore=JSON.stringify(T.getStock());T.CartCorrections.open(cartId);$('cartCorrectionType').value='sale_cash';$('cartCorrectionPaid').value=600;$('cartCorrectionReturned').value=100;
 await Promise.all([T.CartCorrections.save(),T.CartCorrections.save()]);
 assert(T.tx.every(t=>t.type==='sale_cash'),'both cash: '+$('toast').textContent+' / '+$('cartCorrectionError').textContent);assert(T.tx.length===2,'no duplicate');assert(T.calc().expectedCash===100500&&T.calc().expectedBank===0,'cash corrected');assert(JSON.stringify(T.getStock())===stockBefore,'inventory untouched');assert(T.tx.every(t=>t.creditEditHistory.length===1),'one audit per line');return true;
 ''')
 run('Cash to transfer and stale editor safety', '''
 T.CartCorrections.open(cartId);$('cartCorrectionType').value='sale_transfer';await T.CartCorrections.save();assert(T.tx.every(t=>t.type==='sale_transfer'),'both transfer');assert(T.calc().expectedBank===600,'bank receipt');assert(JSON.stringify(T.getStock())===stockBefore,'no stock change');
 T.CartCorrections.open(cartId);const old=JSON.stringify(T.tx);T.tx[0].party='Updated elsewhere';await T.CartCorrections.save();assert(T.tx[0].type==='sale_transfer'&&T.tx[0].creditEditHistory.length===2,'stale prevented');$('cartCorrectionClose').click();return true;
 ''')
 run('Unconfirmed setup editable; confirmation locks DOM and update logic', '''
 $('openingCash').value=200000;T.saveDraft();T.finConfirmDay();await T.RS.whenSaved();T.updateLocks();assert($('openingCash').disabled&&$('openingDebt').disabled&&$('date').disabled,'locked after confirmation');
 $('openingCash').disabled=false;$('openingCash').value=3;T.saveDraft();assert($('openingCash').value==='200000','persistence guard');$('openingDebt').value=900;T.render();assert(Number($('openingDebt').value)===0,'render guard');return true;
 ''')
 run('Settings correction permitted and stays locked elsewhere', '''
 T.DailySetup.open();assert($('setupCorrectionOverlay').classList.contains('hidden'),'cannot open outside settings');T.switchDesk('settings');T.DailySetup.open();assert(!$('setupCorrectionOverlay').classList.contains('hidden'),'settings opens');$('setupEdit_openingCash').value=250000;await T.DailySetup.save();assert(Number($('openingCash').value)===250000,'settings persisted');assert($('openingCash').disabled,'normal still locked');T.switchDesk('sales');$('openingCash').value=1;T.saveDraft();assert(Number($('openingCash').value)===250000,'normal bypass blocked');return true;
 ''')
 run('Database integrity', '''assert((await T.RS.verify()).ok,'db');return true;''')
 print('Browser errors:',errors);b.close()
 if any(r['status']!='passed' for r in results) or errors:raise SystemExit(1)
