const fs=require('fs'),path=require('path'),postcss=require('../tools/node_modules/postcss'),acorn=require('../tools/node_modules/acorn'),walk=require('../tools/node_modules/acorn-walk');
const root=path.resolve(__dirname,'..'),app=path.join(root,'app'),file=path.join(app,'index.html');let html=fs.readFileSync(path.join(root,'baseline/index.html'),'utf8');
const retired=new Set(['roseachy-v270-night-typography','roseachy-v272-theme-contrast','roseachy-v283-five-themes','roseachy-exact-theme-contrast','roseachy-ember-fold-contrast-repair','roseachy-ember-highlight-separators','roseachy-ember-surface-contrast-v296','roseachy-ember-interaction-contrast-v297','roseachy-ember-contrast-v298','roseachy-ember-new-list-contrast-v299','roseachy-surface-text-v2-10-10','roseachy-ember-pale-surfaces-accessibility-v21012','roseachy-ember-smart-sync-shortcut-and-swipe-v21012','roseachy-reference-themes','roseachy-audit-contrast','roseachy-reliability-contrast']);
const paint=/^(color|-webkit-text-fill-color|background(?:-color|-image)?|border(?:-(?:top|right|bottom|left|inline-start|inline-end))?-color|outline-color|text-shadow|box-shadow|fill|stroke|caret-color|accent-color|opacity)$/;
const shorthand=/^(border(?:-(?:top|right|bottom|left|inline-start|inline-end))?|outline)$/;
let removed=0,important=0;const blocks=[];
function migrate(css,id=''){
 let ast;for(let attempt=0;attempt<8;attempt++){try{ast=postcss.parse(css);break}catch(e){if(e.reason!=='Unexpected }')throw e;const lines=css.split('\n');if(lines[e.line-1].trim()!=='}')throw e;lines.splice(e.line-1,1);css=lines.join('\n');}}if(!ast)throw Error('CSS parse failed');ast.walkDecls(d=>{
  if(retired.has(id)&&paint.test(d.prop)){d.remove();removed++;return;}
  if(d.important&&(paint.test(d.prop)||shorthand.test(d.prop))){d.important=false;important++;}
 });
 ast.walkRules(rule=>{if(!rule.nodes?.some(n=>n.type==='decl'||n.type==='rule'||n.type==='atrule'))rule.remove()});
 return '@layer roseachyLegacy {\n'+ast.toString()+'\n}';
}
html=html.replace(/<style\b([^>]*)>([\s\S]*?)<\/style>/gi,(all,attrs,css)=>{
 const id=attrs.match(/id="([^"]+)"/)?.[1]||'';blocks.push(id);return '<style'+attrs+'>'+migrate(css,id)+'</style>'+(id==='roseachy-exact-theme-contrast'?'<style id="roseachy-semantic-theme">\n'+fs.readFileSync(path.join(__dirname,'semantic-theme.css'),'utf8')+'\n</style>':'');
});
// Dynamic component CSS uses the same cascade layer; only presentation literals change.
html=html.replace(/<script\b([^>]*)>([\s\S]*?)<\/script>/gi,(all,attrs,js)=>{
 if(!js.trim())return all;const edits=[];const ast=acorn.parse(js,{ecmaVersion:'latest'});
 walk.simple(ast,{AssignmentExpression(n){if(n.left.type!=='MemberExpression'||n.left.object.name!=='style'||n.left.property.name!=='textContent')return;const v=n.right;let css;if(v.type==='Literal'&&typeof v.value==='string')css=v.value;else if(v.type==='TemplateLiteral'&&!v.expressions.length)css=v.quasis[0].value.cooked;if(!css?.includes('{'))return;edits.push({start:v.start,end:v.end,text:JSON.stringify(migrate(css))});}});
 for(const e of edits.sort((a,b)=>b.start-a.start))js=js.slice(0,e.start)+e.text+js.slice(e.end);return '<script'+attrs+'>'+js+'</script>';
});
const start=html.indexOf('function rsApplyAuditContrast(a,dark){'),end=html.indexOf('let appearanceLayoutFrame=0;',start);
html=html.slice(0,start)+fs.readFileSync(path.join(__dirname,'semantic-tokens.js'),'utf8')+'\n'+html.slice(end);
// Presentation-only action priority: preserve both click handlers and cart behavior.
html=html.replace('id="holdBtn">Add to Cart','id="holdBtn" data-action-role="cart-add">Add to Cart');
const cssExtra=`\n@media screen {\n:where(#txEntryCard:not(:has(#cancelEditBtn:not(.hidden))):has(#type option:checked[value^="sale_"]):not(:has(#holdPanel:not(.hidden))) #holdBtn){background:var(--btn-bg);color:var(--btn-text);border-color:var(--btn-bg)}\n:where(#txEntryCard:not(:has(#cancelEditBtn:not(.hidden))):has(#type option:checked[value^="sale_"]):not(:has(#holdPanel:not(.hidden))) #addBtn):not(:disabled){background:var(--surface-secondary);color:var(--text-primary);border-color:var(--border-strong)}\n:where(#txEntryCard:has(#holdPanel:not(.hidden)) #holdBtn){background:var(--surface-secondary);color:var(--text-primary);border-color:var(--border-strong)}\n}\n`;
// The action selector excludes non-sale types via existing Hold button visibility.
html=html.replace('</style><style id="roseachy-v294', '</style><style id="roseachy-v294'); // No structural rewrite.
html=html.replace(/(<style id="roseachy-semantic-theme">[\s\S]*?)(<\/style>)/,(m,a,b)=>a+cssExtra+b);
// Existing status messages remain their own non-colour signal; colour is supplementary.
html=html.replace("e.textContent=m;e.classList.add('show');", "e.textContent=m;e.dataset.tone=/^(Nothing saved|Save failed|.*(?:failed|not saved|invalid|cannot|could not|error))/i.test(m)?'danger':/^(Enter |Select |Not enough|Insufficient|Review |Wait |A .*save is finishing)/i.test(m)?'warning':/^(.*(?:saved|completed|restored|updated|recorded|removed|corrected|added to cart))$/i.test(m)?'success':'info';e.classList.add('show');");
html=html.replace('<div id="toast"','<div role="status" aria-live="polite" id="toast"');
// Financial row identity is already provided by the ledger. Do not reclassify amounts.
html=html.replace("(r.k>=0?'finPlus':'finMinus')", "(['bank_pos_transfer','bank_to_retail','remit_cash','cash_transfer'].includes(r.type)?'finTransfer':(r.k>=0?'finPlus':'finMinus'))");
html=html.replace('class="supplierDebtStatus">', 'class="supplierDebtStatus" data-tone="\'+(row.review?\'warning\':row.availableK<=0||row.paidK>0?\'pending\':\'warning\')+\'">');
html=html.replace('class="marketPurchaseRow" data-market-purchase-open=', 'class="marketPurchaseRow" data-payment-state="\'+(out>0?(supplierPurchasePaid(p)>0?\'partial\':\'unpaid\'):\'settled\')+\'" data-market-purchase-open=');
html=html.replaceAll('font-weight:700;color:var(--navy);text-transform:uppercase','font-weight:700;color:var(--text-primary);text-transform:uppercase');
html=html.replace('Three original themes and seven reference designs.','Six established themes.');
html=html.replace('Reference 1 · Graphite · cyan · electric violet','Graphite · clear blue').replace('Reference 3 · Carbon · coral · soft glow','Carbon · soft coral').replace('Reference 4 · Porcelain · charcoal · mint','Porcelain · charcoal · mint');
html=html.replace(/<span class="dayBtnIcon" aria-hidden="true">[^<]*<\/span> ?/g,'');
html=html.replace('2.16.8-ux-refinements','2.16.9-semantic-colour');
fs.writeFileSync(file,html);fs.writeFileSync(path.join(app,'sw.js'),fs.readFileSync(path.join(root,'baseline/sw.js'),'utf8').replace('2.16.8-ux-refinements-20261027-final','2.16.9-semantic-colour-20261027-final2'));
fs.writeFileSync(path.join(root,'results/css-consolidation.json'),JSON.stringify({legacyBlocks:blocks.length,retiredThemePaintBlocks:retired.size,removedPaintDeclarations:removed,removedPaintImportantFlags:important,canonicalThemeBlocks:1},null,2));
console.log({removed,important});
