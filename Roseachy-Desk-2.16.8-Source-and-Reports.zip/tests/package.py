from pathlib import Path
import hashlib,json,subprocess,zipfile,shutil
r=Path(__file__).resolve().parents[1];app=r/'app';dest=r/'deliverables';dest.mkdir(exist_ok=True)
def git(*args):return subprocess.check_output(['git',*args],cwd=app,text=True).strip()
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
commit=git('rev-parse','HEAD');assert not git('status','--porcelain'),'Source must be committed'
validation=json.loads((r/'results/final-validation.json').read_text());assert validation['passed'];assert validation['sourceSHA256']==sha(app/'index.html')
remote=git('ls-remote','origin','refs/heads/release-2.16.8').split()[0];assert remote==commit
files=git('ls-files').splitlines();assert len(files)==13
provenance={'version':'2.16.8','sourceCommit':commit,'githubBranch':'release-2.16.8','verifiedRemoteCommit':remote,'sourceFiles':{name:sha(app/name) for name in files},'validation':validation,'browserCheckGroups':91,'cloudflareDeployed':False}
(r/'results/release-provenance.json').write_text(json.dumps(provenance,indent=2))
with (r/'PROGRESS.md').open('a') as f:f.write('\nFinal release: all 14 validation commands passed; 91 browser groups plus static parsing. Final source '+commit+' pushed to GitHub release-2.16.8 and remote commit verified. Cloudflare has not been deployed.\n')
static=dest/'Roseachy-Desk-2.16.8-Cloudflare-Pages.zip'
with zipfile.ZipFile(static,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for name in files:z.write(app/name,name)
with zipfile.ZipFile(static) as z:
 assert z.testzip() is None
 assert set(z.namelist())==set(files)
 for name in files:assert hashlib.sha256(z.read(name)).hexdigest()==sha(app/name)
shutil.copy2(static,r/'checkpoints/03-complete-2.16.8.zip')
source=dest/'Roseachy-Desk-2.16.8-Source-and-Reports.zip';entries={}
for name in ['README.md','REQUEST.md','PROGRESS.md','source-history.bundle']:entries[name]=r/name
for name in ['app','baseline','original','tests','results','reports','checkpoints']:
 for p in (r/name).rglob('*'):
  if p.is_file() and '__pycache__' not in p.parts:entries[str(Path(name)/p.relative_to(r/name))]=p
for name in ['package.json','package-lock.json']:entries['tools/'+name]=r/'tools'/name
with zipfile.ZipFile(source,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for name,p in sorted(entries.items()):z.write(p,name)
with zipfile.ZipFile(source) as z:
 assert z.testzip() is None
 for name,p in entries.items():assert hashlib.sha256(z.read(name)).hexdigest()==sha(p)
checks={p.name:{'bytes':p.stat().st_size,'sha256':sha(p),'entries':len(zipfile.ZipFile(p).namelist()),'crcVerified':True,'allEntryHashesVerified':True} for p in [static,source]}
(dest/'SHA256SUMS.txt').write_text(''.join(v['sha256']+'  '+name+'\n' for name,v in checks.items()))
(dest/'artifact-verification.json').write_text(json.dumps(checks,indent=2));print(json.dumps(checks,indent=2))
