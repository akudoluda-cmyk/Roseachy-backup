const fs=require('fs'),path=require('path'),postcss=require('../tools/node_modules/postcss');
const r=path.resolve(__dirname,'..');let s=fs.readFileSync(path.join(r,'baseline/index.html'),'utf8');
// Retire conflicting geometry and legacy stepped-border rules at their source.
let priorities=0,retired=0;
s=s.replace(/<style\b([^>]*)>([\s\S]*?)<\/style>/gi,(all,attrs,css)=>{
 if(attrs.includes('roseachy-semantic-theme'))return '<style'+attrs+'>'+fs.readFileSync(path.join(__dirname,'semantic-theme.css'),'utf8')+'</style>';
 const ast=postcss.parse(css);ast.walkRules(rule=>{if(/html\.rs-(hairline|border-none)/.test(rule.selector)){rule.remove();retired++;}});
 ast.walkDecls(d=>{if(d.important&&/^(border(?:-radius|-width|-style|-(?:top|right|bottom|left)-(?:width|style|radius))?|box-shadow)$/.test(d.prop)){d.important=false;priorities++;}});
 return '<style'+attrs+'>'+ast.toString()+'</style>';
});
s=s.replace("version:15,colorMode", "version:16,colorMode").replace("shape:'rounded',borderWeight", "shape:'rounded',roundnessLevel:55,borderWeight").replace("shape:['shape','borderWeightLevel']", "shape:['roundnessLevel','borderWeightLevel']");
s=s.replace("level('borderWeightLevel',", "level('roundnessLevel',({compact:25,refined:40,rounded:55,soft:75}[a.shape]??55));level('borderWeightLevel',");
s=s.replace('a.version=15;return a}', 'a.version=16;return a}');
s=s.replace("function radiusSet(v){return{compact:[7,9,12],refined:[9,12,16],rounded:[11,15,20],soft:[13,18,24]}[v]||[11,15,20]}", "function radiusSet(v){const q=Math.max(0,Math.min(100,Number(v)||0))/100;return[16*q,28*q,40*q]}");
s=s.replace('R=radiusSet(a.shape)', 'R=radiusSet(a.roundnessLevel)');
s=s.replace("rs.setProperty('--rs-font-family',fontStack('roseachy'))", "rs.setProperty('--rs-font-family',\"-apple-system,BlinkMacSystemFont,'Segoe UI',Arial,sans-serif\")");
const start=s.indexOf("const bwLevel=Math.max(0,Math.min(100,n(a.borderWeightLevel)))"),end=s.indexOf('const shLevel=',start);
if(start<0||end<0)throw Error('Border mapping not found');
s=s.slice(0,start)+"rs.setProperty('--rs-roundness',a.roundnessLevel/100);rs.setProperty('--rs-radius-control',(a.roundnessLevel*.22)+'px');const bw=a.borderWeightLevel*.03;rs.setProperty('--rs-border-width',bw+'px');rs.setProperty('--rs-border-opacity','1');r.classList.remove('rs-border-none','rs-hairline','rs-border-fine','rs-border-standard');"+s.slice(end);
s=s.replaceAll('balanced:[12,72]','balanced:[12,36]').replace("||[12,72],brand=","||[12,36],brand=");
// A range input only needs variable writes and its output, not a whole theme or preview render.
s=s.replace("function updateAppearanceValue(k,v){const a=getAppearanceSettings();", "function updateAppearanceValue(k,v){const a=getAppearanceSettings();if(k==='roundnessLevel'||k==='borderWeightLevel'){const raw=Number(v);if(!Number.isFinite(raw))return;v=Math.max(0,Math.min(100,Math.round(raw)));if(a[k]===v)return;a[k]=v;storeSet(KEY.appearance,JSON.stringify(appearanceSafe(a)));const rs=document.documentElement.style;if(k==='roundnessLevel'){const R=radiusSet(v);['sm','md','lg'].forEach((n,i)=>rs.setProperty('--rs-radius-'+n,R[i]+'px'));rs.setProperty('--r',R[2]+'px');rs.setProperty('--rs-roundness',v/100);rs.setProperty('--rs-radius-control',(v*.22)+'px')}else rs.setProperty('--rs-border-width',(v*.03)+'px');document.querySelectorAll('[data-setting=\"'+k+'\"]').forEach(e=>e.value=v);document.querySelectorAll('[data-range-value=\"'+k+'\"]').forEach(e=>e.textContent=String(v));return;}");
s=s.replace(/<div class="settingRow"><div><label>Shape<\/label>[\s\S]*?<\/div><\/div>\n/, '<div class="settingRow"><div><label for="appearanceRoundness">Corner roundness</label><div class="settingSub">Square at 0, softly rounded at 50, generous cards and pill-shaped controls at 100.</div></div><div class="settingRange"><input id="appearanceRoundness" data-setting="roundnessLevel" type="range" min="0" max="100" step="1" aria-label="Corner roundness"><output for="appearanceRoundness" data-range-value="roundnessLevel">55</output></div></div>\n');
s=s.replace('<label>Border weight</label>', '<label for="appearanceBorder">Border thickness</label>').replace('0 is practically invisible; 100 is strongly defined. Choose any point between them.', 'From no decorative edge at 0 to a defined 3px inset edge at 100. Focus indicators stay visible.').replace('data-setting="borderWeightLevel" type="range"', 'id="appearanceBorder" data-setting="borderWeightLevel" type="range"').replace('aria-label="Border weight"','aria-label="Border thickness"').replace('<output data-range-value="borderWeightLevel">','<output for="appearanceBorder" data-range-value="borderWeightLevel">');
s=s.replace("'--hero-bg':secondary,'--hero-text':text", "'--hero-bg':p.contrast,'--hero-text':rsContrastGuard(p.onContrast||rsOn(p.contrast),p.contrast,7)");
s=s.replaceAll('background:var(--accent-soft);border-radius:14px;padding:14px;margin-top:', 'background:var(--surface-secondary);border-radius:var(--rs-radius-md);padding:16px;margin-top:');
s=s.replace('2.16.9-semantic-colour','2.16.10-premium-appearance');
fs.writeFileSync(path.join(r,'app/index.html'),s);
fs.writeFileSync(path.join(r,'app/sw.js'),fs.readFileSync(path.join(r,'baseline/sw.js'),'utf8').replace('2.16.9-semantic-colour-20261027-final2','2.16.10-premium-appearance-20261028-final3'));
fs.writeFileSync(path.join(r,'results/geometry-consolidation.json'),JSON.stringify({removedConflictingPriorityFlags:priorities,retiredSteppedBorderRules:retired},null,2));
console.log({priorities,retired});
