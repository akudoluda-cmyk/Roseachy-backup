from common import *
results=[]
def run(name,code):
 try:
  page.wait_for_function('!__test.busy')
  detail=page.evaluate('async()=>{const T=__test,$=id=>document.getElementById(id);const assert=(v,m)=>{if(!v)throw Error(m)};const input=(id,value)=>{$(id).value=value;$(id).dispatchEvent(new Event("input",{bubbles:true}))};'+code+'}')
  results.append(dict(name=name,status='passed',detail=detail));print('PASS',name,flush=True)
 except Exception as e:
  results.append(dict(name=name,status='failed',error=str(e)));print('FAIL',name,str(e)[:1000],flush=True)
 (ROOT/'results/cart-items.json').write_text(json.dumps(results,indent=2))
with sync_playwright() as p:
 b=launch(p);c=context_for(b,'app');page,errors=open_page(c);page.on('dialog',lambda d:d.accept());fixture(page,5,0)
 run('Open cart item expands and edits quantity with immediate discount total', '''
 const stock=T.getStock();Object.assign(stock[0],{quantityPricingEnabled:true,quantityPricingQuantity:3,quantityPricingPrice:250});T.setStock(stock);T.setOpening(T.stockSnapshot());T.render();$('type').value='sale_cash';T.resetTxForm();
 for(const [i,q] of [[0,2],[1,3]]){T.chooseProductSuggestion(stock[i]);$('qty').value=q;T.computeTotal();$('holdBtn').click();}
 const card=document.querySelector('#holdList [data-cart-item="0"]');card.querySelector('summary').click();assert(card.open,'item opens directly');input('heldItemQty_0',4);assert(T.heldItems[0].qty===4&&T.heldItems[0].amount===350,'discount recomputed');assert($('holdTotal').textContent===T.fmt(650),'cart recalculated');assert(T.heldItems[1].qty===3&&T.heldItems[1].amount===300,'other untouched');assert($('heldItemPrice_0').readOnly,'configured price remains protected');
 input('heldItemQty_0',999999);$('addBtn').click();await T.RS.whenSaved();assert(!T.tx.length,'invalid item blocks completing');while(T.busy)await new Promise(r=>setTimeout(r,10));input('heldItemQty_0',4);$('holdCustPaid').value=650;$('holdCustReturned').value=0;$('addBtn').click();await T.RS.whenSaved();return true;
 ''')
 run('Save baseline day and edit completed cart quantity, keeping identities', '''
 assert(T.tx.length===2,'cart saved');await T.runManualDaySave();window.group=T.tx[0].purchaseGroupId;window.ids=T.tx.map(t=>t.id);window.other=JSON.stringify(T.getStock()[1]);window.beforeStock=T.getStock()[0].qty;
 T.CartCorrections.open(group);const card=document.querySelector('#cartCorrectionLines [data-cart-item="0"]');card.querySelector('summary').click();input('cartCorrectionItemQty_0',6);assert(card.querySelector('[data-item-total]').textContent===T.fmt(500),'immediate line total');assert($('cartCorrectionSummary').textContent.includes(T.fmt(800)),'immediate cart total');assert(T.tx[0].qty===4,'draft only before save');$('cartCorrectionPaid').value=800;
 await Promise.all([T.CartCorrections.save(),T.CartCorrections.save()]);assert(T.tx[0].qty===6&&T.tx[0].amount===500,'corrected');assert(JSON.stringify(T.tx.map(t=>t.id))===JSON.stringify(ids),'no duplicate records');assert(T.getStock()[0].qty===beforeStock-2,'stock exactly minus two');assert(JSON.stringify(T.getStock()[1])===other,'other product stock exact');assert(T.tx[1].qty===3&&T.tx[1].amount===300&&T.tx[1].unitPrice===100,'other cart item quantity and price');assert(T.getSaved()[0].tx[0].qty===6,'saved day copy');assert(T.tx[0].creditEditHistory.length===1,'single audit');return true;
 ''')
 run('Quantity reduction restores stock; original price survives configured price change', '''
 const stock=T.getStock();stock[0].price=999;T.setStock(stock);T.CartCorrections.open(group);input('cartCorrectionItemQty_0',3);assert($('cartCorrectionItemPrice_0').value==='100','captured price');$('cartCorrectionPaid').value=550;await T.CartCorrections.save();assert(T.tx[0].qty===3&&T.tx[0].amount===250,'old discount');assert(T.getStock()[0].qty===9997,'returned three to stock');assert(T.getStock()[0].price===999,'current stock price retained');return true;
 ''')
 run('Unchanged receipt creates correct remaining cart debt on quantity increase', '''
 T.CartCorrections.open(group);input('cartCorrectionItemQty_0',6);await T.CartCorrections.save();assert(T.tx[0].qty===6,'saved');const debts=T.creditHistoryObligations();assert(debts.length===1&&debts[0].total===800&&debts[0].initialPaid===550&&debts[0].balance===250,'receipt retained, correct debt');document.querySelector('[data-history-view="credit"]').click();assert($('regularCreditOutstanding').textContent==='••••','nonzero total hidden');$('showCreditOutstanding').click();assert($('regularCreditOutstanding').textContent===T.fmt(250),'exact nonzero balance revealed');$('showCreditOutstanding').click();return debts.map(d=>({total:d.total,paid:d.initialPaid,balance:d.balance}));
 ''')
 run('Insufficient stock and invalid quantity leave stock, records, copies unchanged', '''
 const before=JSON.stringify({tx:T.tx,stock:T.getStock(),saved:T.getSaved()});T.CartCorrections.open(group);input('cartCorrectionItemQty_0',100001);$('cartCorrectionPaid').value=0;$('cartCorrectionType').value='sale_credit';await T.CartCorrections.save();assert(JSON.stringify({tx:T.tx,stock:T.getStock(),saved:T.getSaved()})===before,'stock shortage rollback');input('cartCorrectionItemQty_0',1.5);await T.CartCorrections.save();assert(JSON.stringify({tx:T.tx,stock:T.getStock(),saved:T.getSaved()})===before,'fractional quantity blocked');input('cartCorrectionItemQty_0','');await T.CartCorrections.save();assert(JSON.stringify({tx:T.tx,stock:T.getStock(),saved:T.getSaved()})===before,'blank blocked');$('cartCorrectionClose').click();return true;
 ''')
 run('Injected database failure restores cart, stock and saved copy; retry succeeds once', '''
 const before=JSON.stringify({tx:T.tx,stock:T.getStock(),saved:T.getSaved()});T.CartCorrections.open(group);input('cartCorrectionItemQty_0',7);$('cartCorrectionType').value='sale_credit';$('cartCorrectionPaid').value=0;const put=IDBObjectStore.prototype.put;IDBObjectStore.prototype.put=function(...args){if(this.name==='draft')throw new DOMException('Synthetic item edit failure','QuotaExceededError');return put.apply(this,args)};
 try{await T.CartCorrections.save();}finally{IDBObjectStore.prototype.put=put}
 assert(JSON.stringify({tx:T.tx,stock:T.getStock(),saved:T.getSaved()})===before,'complete rollback');assert($('cartCorrectionItemQty_0').value==='7','input kept');const audits=T.tx[0].creditEditHistory.length;await T.CartCorrections.save();assert(T.tx[0].qty===7&&T.getStock()[0].qty===9993,'retry stock once');assert(T.tx[0].creditEditHistory.length===audits+1,'one audit');return true;
 ''')
 run('Stale cart editor cannot overwrite a concurrent revision', '''
 T.CartCorrections.open(group);input('cartCorrectionItemQty_0',8);T.tx[0].party='Changed elsewhere';const before=JSON.stringify(T.tx);await T.CartCorrections.save();assert(JSON.stringify(T.tx)===before,'stale prevented');$('cartCorrectionClose').click();return true;
 ''')
 run('Linked repayment prevents reducing obligation below already settled amount', '''
 document.querySelector('[data-history-view="credit"]').click();document.querySelector('[data-credit-open]').click();$('creditSettleAmount').value=600;document.querySelector('[data-credit-settle]').click();await T.RS.whenSaved();return true;
 ''')
 run('Repayment protection, manual line price editing and no inventory movement', '''
 const before=JSON.stringify({tx:T.tx,stock:T.getStock()});T.CartCorrections.open(group);input('cartCorrectionItemQty_0',1);await T.CartCorrections.save();assert(JSON.stringify({tx:T.tx,stock:T.getStock()})===before,'paid debt protected');$('cartCorrectionClose').click();
 const manual={id:'manual-ux',purchaseGroupId:'manual-cart',type:'sale_cash',domain:'retail',refKind:'product',productId:null,productName:null,note:'Service',qty:0,amount:100,unitPrice:100,unitSellingPrice:100,customerPaid:100,basketTotal:100,costSnapshot:0,ts:new Date().toISOString()};assert(await T.inventoryCommit(()=>{const err=T.commitSalesLedger([...T.tx,manual]);if(err)throw Error(err);return true},'Sales Desk'),'manual');const stock=JSON.stringify(T.getStock());T.CartCorrections.open('manual-cart');assert(!$('cartCorrectionItemPrice_0').readOnly,'manual price editable');input('cartCorrectionItemPrice_0',120);$('cartCorrectionPaid').value=120;await T.CartCorrections.save();assert(T.tx.find(t=>t.id==='manual-ux').amount===120,'manual price saved');assert(JSON.stringify(T.getStock())===stock,'no stock change');return true;
 ''')
 run('Backup restores item revisions, original IDs and stock after edits', '''
 const before=JSON.stringify({tx:T.tx,stock:T.getStock(),saved:T.getSaved()});const backup=await T.roseachySafeBackup();assert(await T.restoreFullBackup(backup,{confirmRestore:false}),'restored');window.restoreBefore=JSON.parse(before);window.restoreAfter={tx:T.tx,stock:T.getStock(),saved:T.getSaved()};for(const snapshot of [restoreAfter,restoreBefore])for(const day of snapshot.saved)delete day.businessKey;assert(T.stableBackupText(restoreAfter)===T.stableBackupText(restoreBefore),'exact data restored, ignoring derived businessKey');assert((await T.RS.verify()).ok,'database verifies');return true;
 ''')
 (ROOT/'results/cart-restore-before.json').write_text(json.dumps(page.evaluate('window.restoreBefore'),indent=2));(ROOT/'results/cart-restore-after.json').write_text(json.dumps(page.evaluate('window.restoreAfter'),indent=2))
 page.reload();ready(page)
 run('Reload preserves corrected quantities and audit history', '''assert(T.tx.find(t=>t.id===window.ids?.[0])||T.tx.some(t=>t.qty===7&&t.creditEditHistory.length===4),'durable correction');assert((await T.RS.verify()).ok,'durable db');return true;''')
 print('Browser errors:',errors);b.close()
 if errors or any(x['status']!='passed' for x in results):raise SystemExit(1)
