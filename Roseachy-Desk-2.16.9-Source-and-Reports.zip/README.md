# Roseachy Desk 2.16.9

A visual refinement of the existing 2.16.8 application, continued from the first 2.16.9 semantic-colour checkpoint. This is the actual working application, not a mockup.

## Deliverables

- `app/`: all 13 deployable files. Upload the Cloudflare Pages ZIP directly using Pages Direct Upload. `index.html`, `sw.js` and the `icons/` and `js/` directories must remain at the deployment root. No build step or new runtime dependencies.
- `Roseachy-Desk-2.16.9-Preview.html`: single-file application preview with local scripts and icons embedded. No external assets are required. It uses its own browser origin's storage; it does not automatically contain data from your deployed app.
- `reports/VERIFICATION.md`: scope, measurements, changes and limitations.
- `results/`: actual Chromium results and before/after screenshots. Fixture records are synthetic and not shipped in the application.
- `tests/`: browser test harness and reproducible source transformation. `baseline/` is unchanged 2.16.8.
- `REQUEST.md` and `CONTINUATION.md`: the user's requirements.
- `checkpoints/`: recoverable original and intermediate deployment packages.

## Preview

Download the standalone HTML and open it in a browser. If your browser or device restricts local HTML storage, serve its directory using `python -m http.server 8000` and open `http://localhost:8000/Roseachy-Desk-2.16.9-Preview.html`. The managed test browser blocked file URLs, so single-file HTTP operation was verified. Use the full deployment ZIP for installable PWA/service-worker operation.

## Verification setup

Python 3, Playwright and Chromium; Node with Acorn, Acorn Walk and PostCSS. `tools/package-lock.json` fixes the parser tools. The application itself has no added dependencies. The harness uses `/usr/bin/chromium` and intercepts localhost requests for deterministic synthetic data. It injects `tests/hooks.js` into test responses only.

Run `python tests/validate.py`, `python tests/responsive_matrix.py`, `python tests/visual_interactions.py`, `python tests/extra_states.py`, and `python tests/preview_check.py`. Build the preview using `python tests/build_preview.py`. The transformation `node tests/patch_semantic.cjs` rebuilds the visual changes from the unchanged baseline, then `node tests/static_check.cjs` parses scripts/CSS and verifies non-presentation functions.

No production data was accessed and Cloudflare was not deployed by this task. Existing business calculations, persistence formats, sync, privacy and navigation handlers are retained.
