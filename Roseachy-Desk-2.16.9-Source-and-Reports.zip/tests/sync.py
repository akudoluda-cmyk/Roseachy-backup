from common import *
import traceback
result={'checks':[]};out=ROOT/'results/cart-sync.json'
def record(name,detail=None):
 result['checks'].append({'name':name,'status':'passed','detail':detail});out.write_text(json.dumps(result,indent=2));print('PASS',name,flush=True)
def unlock(page):
 page.evaluate('''async()=>{__test.switchDesk('financial',false);if(RoseachyFinance.locked()){document.getElementById('finUnlockPass').value='2741';await __test.finUnlock()}if(RoseachyFinance.locked())throw Error('Unlock failed')}''')
def enroll(b,targets):
 pages=[]
 for target in targets:
  c=context_for(b,target);page,errors=open_page(c);fixture(page,4,0);page.on('dialog',lambda d:d.accept())
  page.evaluate('''async()=>{const T=__test,m=T.getMarketState();m.suppliers=[{id:'ade',name:'Ade Wholesale',createdAt:'2026-01-01T00:00:00Z',updatedAt:'2026-01-01T00:00:00Z'}];await T.RS.atomic(()=>T.setMarketState(m));T.switchDesk('financial',false);for(const id of ['finSetupPassword','finSetupPassword2'])document.getElementById(id).value='2741';document.getElementById('finAnchorInput').value='200000';document.getElementById('finAnchorMode').value='day';await T.finSetup();}''')
  backup=page.evaluate('()=>__test.roseachySafeBackup()');recovery=ROOT/'results'/f'sync-recovery-{len(pages)}.json';recovery.write_text(json.dumps(backup));page.evaluate('b=>__test.SmartSync.verifyRecovery(b)',json.loads(recovery.read_text()));pages.append((page,errors))
 a,z=[x[0] for x in pages];offers=[page.evaluate('()=>__test.SmartSync.offer()') for page,_ in pages]
 remoteA=a.evaluate('f=>__test.SmartSync.unprotect(f)',offers[1]);remoteB=z.evaluate('f=>__test.SmartSync.unprotect(f)',offers[0])
 for page,remote in [(a,remoteA),(z,remoteB)]:page.evaluate('r=>__test.SyncPrivacy.trust(r.sender.deviceId,r.sender.publicKey,true)',remote)
 choices={'sameBusiness':True,'approvedBy':'Synthetic owner','snapshotScope':'shared verified baseline'}
 plan=a.evaluate('v=>__test.SmartSync.initialPlan(v.remote,v.choices)',{'remote':remoteA,'choices':choices});assert not plan['conflicts'],plan['conflicts']
 cp=a.evaluate('v=>__test.SmartSync.createCheckpoint(v.remote,v.choices)',{'remote':remoteA,'choices':plan['choices']})
 for page,_ in pages:page.evaluate('cp=>__test.SmartSync.acceptCheckpoint(cp,{sameBusiness:true,approvedBy:"Synthetic owner"})',cp)
 for sender,receiver in [(a,z),(z,a)]:receiver.evaluate('async f=>__test.SmartSync.acceptAcknowledgement(await __test.SmartSync.unprotect(f))',sender.evaluate('()=>__test.SmartSync.acknowledgement()'))
 return pages

def exchange(sender,receiver,duplicate=False):
 unlock(sender);unlock(receiver);signed=sender.evaluate('()=>__test.SmartSync.updates()');remote=receiver.evaluate('f=>__test.SmartSync.unprotect(f)',signed)
 for _ in range(2 if duplicate else 1):receiver.evaluate('r=>__test.SmartSync.merge(r)',remote)
 return remote
with sync_playwright() as p:
 b=launch(p)
 try:
  pages=enroll(b,['app','app']);a,z=[v[0] for v in pages]
  a.evaluate("""async()=>{const T=__test;const rows=[0,1].map(i=>({id:'sync-sale-'+i,type:'sale_transfer',purchaseGroupId:'sync-cart',domain:'retail',refKind:'product',productId:'fixture-product-'+i,productName:'Product '+i,note:'Product '+i,qty:i+1,amount:(i+1)*100,unitPrice:100,unitSellingPrice:100,costSnapshot:60,division:i?'pharmacy':'essentials',ts:new Date().toISOString()}));rows[1].basketTotal=300;rows[1].customerPaid=400;rows[1].changeReturned=100;rows[1].changeOwed=0;rows[1].paymentReconciliationV2=true;const ok=await T.inventoryCommit(()=>{const e=T.commitSalesLedger([...T.tx,...rows]);if(e)throw Error(e);return true},'Sales Desk');if(!ok)throw Error('Sale failed')}""")
  exchange(a,z,True)
  assert z.evaluate('__test.tx.length')==2
  quantities=z.evaluate('__test.getStock().map(p=>p.qty)')
  record('Signed duplicate import creates one complete cart and one inventory movement')
  a.evaluate("""async()=>{__test.switchDesk('sales');__test.CartCorrections.open('sync-cart');document.getElementById('cartCorrectionType').value='sale_cash';await __test.CartCorrections.save();if(!__test.tx.every(t=>t.type==='sale_cash'))throw Error(document.getElementById('toast').textContent)}""")
  exchange(a,z,True)
  assert z.evaluate('__test.tx.every(t=>t.type==="sale_cash"&&t.creditEditHistory.length===1)')
  assert z.evaluate('__test.getStock().map(p=>p.qty)')==quantities
  assert z.evaluate('__test.calc().expectedCash')==100300
  record('Cart-wide correction and audit synchronize exactly once with no stock replay')
  a.evaluate("""async()=>{__test.switchDesk('sales');__test.CartCorrections.open('sync-cart');document.getElementById('cartCorrectionType').value='sale_credit';document.getElementById('cartCorrectionPaid').value=0;document.getElementById('cartCorrectionReturned').value=0;await __test.CartCorrections.save();if(!__test.tx.every(t=>t.type==='sale_credit'))throw Error(document.getElementById('toast').textContent)}""")
  exchange(a,z,True)
  assert z.evaluate('__test.creditHistoryObligations()[0].balance')==300
  a.evaluate("""()=>{__test.switchDesk('sales');document.querySelector('[data-history-view="credit"]').click();document.querySelector('[data-credit-open]').click();document.getElementById('creditSettleAmount').value=150;document.querySelector('[data-credit-settle]').click()}""")
  a.wait_for_function('!__test.busy');exchange(a,z,True)
  assert z.evaluate('__test.creditHistoryObligations()[0].balance')==150
  assert z.evaluate('__test.creditHistoryObligations()[0].repayments.length')==1
  assert z.evaluate('__test.getStock().map(p=>p.qty)')==quantities
  record('Cart credit and one grouped repayment receipt converge without duplicated sales')
  # Concurrent corrections to the same original cart must request reconciliation.
  for pg in [a,z]:
   pg.evaluate("""async()=>{__test.switchDesk('sales');__test.CartCorrections.open('sync-cart');document.getElementById('cartCorrectionType').value='sale_split';document.getElementById('cartCorrectionPaid').value=0;document.getElementById('cartCorrectionBank').value=0;document.getElementById('cartCorrectionReturned').value=0;await __test.CartCorrections.save();if(!__test.tx.filter(t=>t.purchaseGroupId==='sync-cart').every(t=>t.type==='sale_split'))throw Error(document.getElementById('toast').textContent)}""")
  unlock(a);unlock(z);signed=z.evaluate('()=>__test.SmartSync.updates()');remote=a.evaluate('f=>__test.SmartSync.unprotect(f)',signed)
  before=a.evaluate('JSON.stringify(__test.tx)');rejection=a.evaluate('async r=>{try{await __test.SmartSync.merge(r);return null}catch(e){return e.message}}',remote)
  assert rejection and 'conflict' in rejection.lower(),rejection
  assert a.evaluate('JSON.stringify(__test.tx)')==before
  record('Concurrent cart corrections are rejected as conflicts with local data intact',rejection)
  for pg,errors in pages:assert not errors,errors;pg.context.close()
  pages=enroll(b,['app','original']);a,z=[v[0] for v in pages]
  # Existing 2.16.8 debt record formats receive the upgraded grouped settlement.
  a.evaluate("""async()=>{const T=__test;const rows=[0,1].map(i=>({id:'legacy-sync-'+i,type:'sale_credit',purchaseGroupId:'legacy-cart',domain:'retail',refKind:'product',productId:'fixture-product-'+i,productName:'Product '+i,note:'Product '+i,qty:1,amount:100,unitPrice:100,unitSellingPrice:100,costSnapshot:60,splitCredit:100,division:i?'pharmacy':'essentials',ts:new Date().toISOString()}));if(await T.inventoryCommit(()=>{const e=T.commitSalesLedger(rows);if(e)throw Error(e);return true},'Sales Desk')!==true)throw Error('Seed failed')}""")
  exchange(a,z,True)
  a.evaluate("""()=>{__test.switchDesk('sales');document.querySelector('[data-history-view="credit"]').click();document.querySelector('[data-credit-open]').click();document.getElementById('creditSettleAmount').value=150;document.querySelector('[data-credit-settle]').click()}""")
  a.wait_for_function('!__test.busy');exchange(a,z,True)
  assert z.evaluate('__test.buildCreditHistory().reduce((s,d)=>s+d.balance,0)')==50
  assert z.evaluate('__test.calc().expectedCash')==100150
  record('Original 2.16.8 peer accepts grouped receipt components using unchanged debt/payment records')
  for pg,errors in pages:assert not errors,errors
  result['status']='passed'
 except Exception as e:result['status']='failed';result['error']=str(e);traceback.print_exc()
 finally:out.write_text(json.dumps(result,indent=2));b.close()
raise SystemExit(0 if result.get('status')=='passed' else 1)
