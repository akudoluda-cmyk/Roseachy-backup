from pathlib import Path
p=Path('/workspace/Roseachy-backup/index.html')
s=p.read_text()
def replace(old,new,count=1):
 global s
 assert s.count(old)==count,(old[:100],s.count(old),count)
 s=s.replace(old,new)

# One add action, using the existing held-cart model and price snapshots.
replace('<button class="ghost hidden" id="nextBtn">Add Item</button>','')
replace("$('nextBtn').classList.remove('hidden');",'',2)
replace("$('nextBtn').classList.add('hidden');",'',2)
start=s.index("$('holdBtn').addEventListener('click'")
end=s.index("$('cancelHoldBtn')",start)
s=s[:start]+'''function addCurrentToCart(){
 if(historical||editIndex>=0)return;
 const type=$('type').value;
 if(TYPES[type]?.cat!=='sale'||type==='sale_account')return toast('Cart is for a customer multi-item sale');
 if(!currentItemHasInput()){
  if(holdMode){$('holdPanel').classList.remove('hidden');renderHoldPanel();return;}
  return toast('Select a product and enter its quantity');
 }
 const p=selectedProductId?getStock().find(x=>x.id===selectedProductId):null;
 const {obj,error}=validateAndBuildTx(p?heldQtyFor(p.id):0,true);
 if(error){$('stockWarn').textContent=error;return;}
 const existing=p?heldItems.find(t=>t.productId===p.id):null;
 if(existing){
  const qty=n(existing.qty)+n(obj.qty),price=salePricing(p,qty,ruleFromSaleRecord(existing,p));
  Object.assign(existing,{qty,totalUnits:qty,amount:price.total,actualSaleTotal:price.total,quantityPricingApplied:price.applied,packSelected:false,packsEntered:0,looseUnitsEntered:qty});
 }else{obj.type=holdMode?holdType:type;heldItems.push(obj);}
 if(!holdMode){holdMode=true;holdType=type;}
 $('holdPanel').classList.remove('hidden');resetTxForm(true);refreshTypeUI();renderHoldPanel();updateLocks();toast(existing?'Cart quantity updated':'Added to cart');
}
$('holdBtn').addEventListener('click',addCurrentToCart);
''' + s[end:]
start=s.index("$('nextBtn').addEventListener('click'")
end=s.index('let retailSubmitBusy',start)
s=s[:start]+s[end:]
replace('Add Item keeps the selected product in your cart.','Add to Cart adds the selected product immediately.')
replace('No item stored yet — use Add Item to keep the current item in the cart.','Your cart is empty — select a product and use Add to Cart.')
replace('>Remove from Cart</button>',' aria-label="Remove '+"'+esc(o.note||'item')+'"+' from cart" title="Remove from cart">×</button>')

# Compact clear button lives beside the existing combobox.
replace('<datalist id="stockNames">','<button type="button" id="clearProductSelection" class="iconbtn hidden" aria-label="Clear selected product" title="Clear selected product">×</button><datalist id="stockNames">')
replace("function refreshProductHint(pickedId=null){", "function refreshProductHint(pickedId=null){")
replace("selectedProductId=p?p.id:null;const cat=", "selectedProductId=p?p.id:null;$('clearProductSelection').classList.toggle('hidden',!p);const cat=")
replace("function heldQtyFor(pid)", "$('clearProductSelection').addEventListener('click',()=>{resetTxForm(true);closeProductSuggestions();$('note').focus();});\nfunction heldQtyFor(pid)")

# Notes use native collapse/expand and the existing atomic note store.
start=s.index(" active.forEach(x=>",s.index('function renderNotes()'))
end=s.index(" $('noteTrashCount')",start)
s=s[:start]+''' active.forEach(x=>{const d=document.createElement('details');d.className='noteItem editableNote';
 d.innerHTML='<summary class="noteHead"><strong>'+esc((x.text||'General note').split('\\n')[0].slice(0,90))+'</strong><span class="small">Last Saved '+esc(fmtDateTime(x.savedAt))+'</span></summary><label class="small">Note<textarea rows="5" aria-label="Edit note">'+esc(x.text)+'</textarea></label><div class="notesRowActions"><button type="button" class="iconbtn" data-nsave="'+esc(x.id)+'">Save changes</button><button type="button" class="iconbtn del" data-ndel="'+esc(x.id)+'">Delete</button></div>';
 d._noteSnapshot=stableBackupText(x);list.appendChild(d)});
''' + s[end:]
replace("{id:uid('n'),type:'general',text,savedAt:new Date().toISOString()}","{id:uid('n'),type:'general',text,createdAt:nowIso(),savedAt:nowIso()}")
replace("$('notesList').addEventListener('click',e=>{", """$('notesList').addEventListener('click',e=>{
 const save=e.target.closest('[data-nsave]');if(save){
  const card=save.closest('.editableNote'),text=card.querySelector('textarea').value;
  if(!text.trim())return toast('Write something first');
  const id=save.dataset.nsave,stamp=nowIso();
  commitNotes(a=>{const found=a.find(x=>String(x?.id)===id&&!x.deletedAt);if(!found||stableBackupText(found)!==card._noteSnapshot)throw Error('This note changed. Reopen it before editing.');return a.map(x=>x===found?{...x,text,createdAt:x.createdAt||x.savedAt||stamp,savedAt:stamp}:x)},'Note updated');return;
 }
""")

# Privacy is presentation only, defaults hidden every page load.
replace('<div class="rsHistoryTotal">Total Outstanding <strong id="regularCreditOutstanding">₦0.00</strong></div>', '<div class="rsHistoryTotal">Total Outstanding <strong id="regularCreditOutstanding">••••</strong><label class="checkline small"><input type="checkbox" id="showCreditOutstanding"> Show Total Outstanding</label></div>')
replace("$('regularCreditOutstanding').textContent=fmt(receivable/100);", "$('regularCreditOutstanding').textContent=$('showCreditOutstanding').checked?fmt(receivable/100):'••••';")
replace("function renderCreditHistory(){", "$('showCreditOutstanding').addEventListener('change',renderCreditHistory);\nfunction renderCreditHistory(){")
replace('class="help"><button type="button" class="ghost" data-private-credit>Open private Credit Accounts</button> Private account purchases stay in their dedicated history.', 'class="help privateCreditLink"><button type="button" class="iconbtn" data-private-credit>Open private Credit Accounts</button><small>Private account purchases stay in their dedicated history.</small>')
replace("+' · Cart '+id", "+' · Cart Purchase'")
replace("'<div class=\"rsCreditDetails\"><div class=\"rsCreditDetailGrid\"><div><b>Cart / transaction reference</b><span>'+esc(d.origin?.purchaseGroupId||d.origin?.id||d.id)+'</span></div>", "'<div class=\"rsCreditDetails\"><div class=\"rsCreditDetailGrid\"><div><b>Purchase</b><span>Cart Purchase</span></div>")
replace("['Group ID',t.purchaseGroupId||t.id]", "['Purchase','Cart Purchase']")

# Supplier payment: no default zero or implied fully paid when untouched.
replace("h[st.paidKey]=!methodExplicit&&methods.length===1&&methods[0]==='purchase_credit'?0:null;", "h[st.paidKey]=null;")
replace('Amount Paid (optional)</label><input id="marketAmountPaid" type="number" min="0" step="0.01">', 'Amount Paid</label><input id="marketAmountPaid" type="number" min="0" step="0.01" aria-describedby="marketPaymentWarn" placeholder="Enter amount, including 0">')
replace("let paid=total,issue='';try{if(raw!=='')paid=inventoryPayment(raw,'Amount paid');}catch(err){issue=err.message;}", "const needsPayment=selectedMarketReviewItems().some(x=>!x.purchase.updateOnly),missing=needsPayment&&!raw?.trim();let paid=0,issue=missing?'Enter Amount Paid (enter 0 for an unpaid purchase).':'';try{if(raw!=='')paid=inventoryPayment(raw,'Amount paid');}catch(err){issue=err.message;}")
replace("if($('marketApplyAll'))$('marketApplyAll').disabled=!!issue;", "if(input&&!issue)input.classList.remove('paymentPrompt');if($('marketApplyAll'))$('marketApplyAll').disabled=!!issue&&!missing;")
replace("$('marketApplyAll').addEventListener('click',async () => inventoryCommit(()=>{", """function requireMarketPayment(){
 if(!selectedMarketReviewItems().some(x=>!x.purchase.updateOnly))return true;
 const input=$('marketAmountPaid');try{if(!input.value.trim())throw Error('Enter Amount Paid (enter 0 for an unpaid purchase).');inventoryPayment(input.value,'Amount paid');return true;}
 catch(e){updateReviewBalance();input.classList.remove('paymentPrompt');void input.offsetWidth;input.classList.add('paymentPrompt');input.focus();return false;}
}
$('marketApplyAll').addEventListener('click',async () => {if(!requireMarketPayment())return;return inventoryCommit(()=>{if(!requireMarketPayment())return;""")
replace('}},"Market Desk"));\n', '}},"Market Desk");});\n')

# Scoped visual refinements, respecting existing theme variables and motion.
styles='''
<style id="ux-refinements-2168">
#clearProductSelection{position:absolute;right:7px;top:32px;padding:3px 9px;font-size:20px;line-height:1.2;background:transparent}
#note{padding-right:42px}
.editableNote summary{cursor:pointer;gap:12px;list-style:revert}
.editableNote summary strong{overflow:hidden;text-overflow:ellipsis;white-space:nowrap;min-width:0}
.editableNote textarea{width:100%;margin-top:8px;resize:vertical}
.editableNote>label{display:block;margin-top:12px}
.privateCreditLink{display:flex;align-items:center;flex-wrap:wrap;gap:4px 10px;font-weight:normal}
.privateCreditLink button{font-size:12px;padding:3px 0;background:transparent!important;box-shadow:none!important;border:0!important;text-decoration:underline;text-underline-offset:3px}
.privateCreditLink small{color:var(--muted);font-size:11px}
#creditHistoryPane .rsHistoryTotal .checkline{font-weight:normal;display:inline-flex;margin-left:12px;gap:5px}
html body[data-theme] #recordsTable tr.heldGroupRow>td{background:color-mix(in srgb,var(--text-primary,var(--navy)) 4%,var(--surface))!important}
html body[data-theme] #recordsTable tr.heldGroupRow.heldGroupAlternate>td{background:color-mix(in srgb,var(--text-primary,var(--navy)) 7%,var(--surface))!important}
#recordsTable .heldGroupTag{display:none}
#recordsTable tr.heldGroupRow>td{border-left-width:0;border-right-width:0}
@keyframes paymentAttention{50%{box-shadow:0 0 0 3px color-mix(in srgb,var(--navy) 25%,transparent)}}
#marketAmountPaid.paymentPrompt{animation:paymentAttention .55s ease-in-out 3}
@media(prefers-reduced-motion:reduce){#marketAmountPaid.paymentPrompt{animation:none;outline:2px solid var(--muted);outline-offset:2px}}
</style>
'''
replace('</head>',styles+'</head>')
replace("const frag=document.createDocumentFragment();for(const row of show)", "const groupTints=new Map();for(const {t} of matched)if(t.purchaseGroupId&&!groupTints.has(t.purchaseGroupId))groupTints.set(t.purchaseGroupId,groupTints.size%2);const frag=document.createDocumentFragment();for(const row of show)")
replace("tr.classList.add('heldGroupRow');", "tr.classList.add('heldGroupRow');if(groupTints.get(t.purchaseGroupId))tr.classList.add('heldGroupAlternate');")
replace('2.16.7-business-corrections','2.16.8-ux-refinements')
p.write_text(s)
sw=p.with_name('sw.js');sw.write_text(sw.read_text().replace('2.16.7-business-corrections-20261027','2.16.8-ux-refinements-20261027'))
