from pathlib import Path
import urllib.request,hashlib,json,zipfile,io,time
r=Path(__file__).resolve().parents[1];d=r/'deliverables';a=json.loads((d/'artifact-verification.json').read_text());out=[]
for name,v in a.items():
 url='https://github.com/akudoluda-cmyk/Roseachy-backup/raw/refs/heads/downloads-2.16.10/'+name
 for retry in range(5):
  try:
   with urllib.request.urlopen(urllib.request.Request(url,headers={'Cache-Control':'no-cache'}),timeout=120) as response:
    data=response.read();status=response.status
   break
  except Exception:
   if retry==4:raise
   time.sleep(3)
 assert status==200 and hashlib.sha256(data).hexdigest()==v['sha256'],name
 if name.endswith('.zip'):assert zipfile.ZipFile(io.BytesIO(data)).testzip() is None
 out.append({'file':name,'url':url,'httpStatus':status,'bytes':len(data),'sha256Verified':True});print('VERIFIED',name,len(data),flush=True)
(r/'results/published-downloads.json').write_text(json.dumps(out,indent=2))
