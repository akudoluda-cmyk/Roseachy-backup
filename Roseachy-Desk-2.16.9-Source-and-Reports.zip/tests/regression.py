from common import *
import sys, traceback
target=sys.argv[1] if len(sys.argv)>1 else "original"
results=[]
def test(name, fn):
    start=time.perf_counter()
    try:
        detail=fn()
        results.append({"name":name,"status":"passed","seconds":time.perf_counter()-start,"detail":detail})
        print("PASS",name,flush=True)
    except Exception as e:
        results.append({"name":name,"status":"failed","seconds":time.perf_counter()-start,"error":str(e)})
        print("FAIL",name,str(e)[:500],flush=True)
    (ROOT/"results"/f"regression-{target}.json").write_text(json.dumps(results,indent=2))

with sync_playwright() as p:
    b=launch(p)
    context=context_for(b,target)
    page,errors=open_page(context)
    page.on("dialog",lambda d:d.accept())
    downloads=[]
    def download(d):
        path=ROOT/"results"/f"recovery-{target}-{len(downloads)}.json"
        d.save_as(str(path));downloads.append(path)
    page.on("download",download)
    fixture(page,4,0)
    def js(code):return page.evaluate("async()=>{const T=__test;const assert=(ok,msg)=>{if(!ok)throw Error(msg)};"+code+"}")
    test("A cash sale: exactly one stock deduction, cash receipt and durable save", lambda:js("""
      const product=T.getStock()[0];window.testStartQty=product.qty;
      const row={id:'cash-sale-a',type:'sale_cash',productId:product.id,productName:product.name,
        note:product.name,qty:2,amount:200,unitPrice:100,unitSellingPrice:100,
        costSnapshot:60,domain:'retail',refKind:'product',division:product.division,ts:new Date().toISOString()};
      assert(await T.inventoryCommit(()=>{const e=T.commitSalesLedger([...T.tx,row]);if(e)throw Error(e);return true},'Sales Desk')===true,'commit');
      assert(T.getStock()[0].qty===testStartQty-2,'stock');
      assert(T.calc().expectedCash===100200,'cash');
      assert(T.tx.filter(t=>t.id==='cash-sale-a').length===1,'identity');
      assert((await T.RS.verify()).ok,'database verification');
      return {quantity:T.getStock()[0].qty,cash:T.calc().expectedCash};
    """))
    test("B credit sale: receivable without falsely increasing cash",lambda:js("""
      const C=T.CreditAccounts,customerId='fixture-customer-0';
      await C.purchase({customerId,lines:[{productId:'fixture-product-0',qty:3}],paid:0,id:'credit-sale-b'});
      assert(T.getStock()[0].qty===testStartQty-5,'stock');
      assert(C.balance(customerId)===300,'credit');
      assert(T.calc().expectedCash===100200,'cash unchanged');
      return {credit:C.balance(customerId),cash:T.calc().expectedCash};
    """))
    test("C credit collection: idempotent payment, no inventory effect",lambda:js("""
      const C=T.CreditAccounts,customerId='fixture-customer-0',q=T.getStock()[0].qty;
      await C.pay({customerId,amount:100,method:'cash',id:'collection-c'});
      await C.pay({customerId,amount:100,method:'cash',id:'collection-c'});
      assert(C.balance(customerId)===200,'receivable');
      assert(T.calc().expectedCash===100300,'one cash receipt');
      assert(T.getStock()[0].qty===q,'no stock movement');
      assert(T.tx.filter(t=>t.id==='collection-c').length===1,'single collection');
      return true;
    """))
    test("D credit correction preserves ID, collection, and audit trail",lambda:js("""
      const C=T.CreditAccounts,old=T.tx.find(t=>t.purchaseGroupId==='credit-sale-b'),
        payment=JSON.stringify(T.tx.find(t=>t.id==='collection-c'));
      C.deskOptions();C.beginEdit(old);
      const replacement=C.buildLine({productId:old.productId,qty:4,rule:{price:100}});
      assert(await T.inventoryCommit(()=>{const e=C.editLine(old,replacement);if(e)throw Error(e);return true},'Sales Desk')===true,'edit');
      C.endEdit();
      const now=T.tx.find(t=>t.id===old.id);
      assert(now.qty===4&&now.amount===400,'corrected quantity/value');
      assert(now.creditEditHistory.length===1,'audit');
      assert(C.balance('fixture-customer-0')===300,'receivable');
      assert(JSON.stringify(T.tx.find(t=>t.id==='collection-c'))===payment,'prior payment unchanged');
      assert(T.getStock()[0].qty===testStartQty-6,'inventory difference only');
      return true;
    """))
    test("D invalid credit reduction and customer reassignment are explicit rejections",lambda:js("""
      const C=T.CreditAccounts,old=T.tx.find(t=>t.purchaseGroupId==='credit-sale-b'),before=JSON.stringify(T.tx);
      C.deskOptions();C.beginEdit(old);
      const tooLow=C.buildLine({productId:old.productId,qty:1,rule:{price:50}});
      const error=C.editLine(old,tooLow);
      assert(error&&/collected|payment/i.test(error),'overpayment explicitly rejected');
      document.getElementById('creditDeskCustomer').value='fixture-customer-1';
      assert(/customer|payment|collections/i.test(C.editLine(old,C.buildLine({productId:old.productId,qty:4}))), 'reassignment blocked');
      assert(JSON.stringify(T.tx)===before,'unchanged rejected records');C.endEdit();
      return true;
    """))
    test("E restocking ledger: stock addition and exactly one purchase payment",lambda:js("""
      const p=T.getStock()[0],before=p.qty;
      const row={id:'market-restock-e',type:'purchase_cash',productId:p.id,productName:p.name,
        note:p.name,qty:12,amount:720,unitPrice:60,costSnapshot:60,domain:'retail',
        refKind:'product',division:p.division,ts:new Date().toISOString(),source:'Market Desk'};
      assert(await T.inventoryCommit(()=>{const e=T.commitSalesLedger([...T.tx,row]);if(e)throw Error(e);return true},'Market Desk')===true,'restock');
      assert(T.getStock()[0].qty===before+12,'stock addition');
      assert(T.calc().expectedCash===99580,'one payment');return true;
    """))
    test("Quantity representation and duplicate-name resolution",lambda:js("""
      for(const size of [1,6,12,24])for(const qty of [0,1,11,12,23,24,25,10000]){
        const d=T.packBreakdown(qty,size);assert(d.packs*size+d.loose===qty,'pack arithmetic');
      }
      const a=[{id:'a',name:'Same',division:'pharmacy'},{id:'b',name:'Same',division:'essentials'}];
      assert(T.prodLabel(a[0],a)==='Same (Pharmacy)','label');
      assert(T.findProductByName('Same',a)===null,'ambiguous');
      assert(T.findProductByName('Same (Essentials)',a).id==='b','disambiguation');
      assert(T.findProductByName('Product 00000 tablets 500mg').id==='fixture-product-0','live lookup');
      return true;
    """))
    test("Atomic abort rolls back mutated stock/history and keeps working input",lambda:js("""
      const before=JSON.stringify(T.getStock()),saved=JSON.stringify(T.getSaved()),rows=JSON.stringify(T.tx);
      document.getElementById('note').value='Unfinished sale retained';
      const original=IDBObjectStore.prototype.put;
      IDBObjectStore.prototype.put=function(...a){if(this.name==='stockRecords')throw new DOMException('Synthetic quota failure','QuotaExceededError');return original.apply(this,a)};
      let ok;
      try{ok=await T.inventoryCommit(()=>{
        const p=T.getStock();p[0].name='Must roll back';T.setStock(p,[p[0].id]);
        T.setSaved([{id:'must-rollback-day',date:'2026-01-01',tx:[]}]);return true;
      },'Stock')}finally{IDBObjectStore.prototype.put=original}
      assert(ok===false,'failure surfaced');assert(JSON.stringify(T.getStock())===before,'stock rollback');
      assert(JSON.stringify(T.getSaved())===saved,'history rollback');assert(JSON.stringify(T.tx)===rows,'ledger rollback');
      assert(document.getElementById('note').value==='Unfinished sale retained','form kept');
      assert((await T.RS.verify()).ok,'durable state unchanged');return true;
    """))
    test("H overlapping inventory submissions: explicit busy result and single action",lambda:js("""
      let accepted=0;
      const first=T.inventoryCommit(()=>{accepted++;return true},'Stock');
      const second=await T.inventoryCommit(()=>{accepted++;return true},'Stock');
      assert(second===false,'busy rejected');assert(await first===true,'first saved');assert(accepted===1,'one execution');
      return true;
    """))
    test("Financial PIN and explicit bank approval: collection posts exactly once",lambda:js("""
      T.switchDesk('financial',false);
      for(const id of ['finSetupPassword','finSetupPassword2'])document.getElementById(id).value='2741';
      document.getElementById('finAnchorInput').value='1000';document.getElementById('finAnchorMode').value='day';
      await T.finSetup();assert(!RoseachyFinance.locked(),'synthetic finance initialized');
      const before=T.finLedger().balanceK;
      await T.CreditAccounts.pay({customerId:'fixture-customer-0',amount:50,method:'transfer',id:'bank-collection'});
      assert(T.finLedger().balanceK===before,'claim awaits owner approval');
      assert(T.BankReconciliation.queue().some(t=>t.id==='bank-collection'),'pending claim');
      await T.BankReconciliation.decide('bank-collection','confirm');
      await T.BankReconciliation.decide('bank-collection','confirm');
      assert(T.finLedger().balanceK===before+5000,'bank increases once after approval');
      assert(T.CreditAccounts.balance('fixture-customer-0')===250,'credit decreases');
      T.finLockForDeskExit();assert(RoseachyFinance.locked(),'locked');
      document.getElementById('finUnlockPass').value='0000';await T.finUnlock();
      assert(RoseachyFinance.locked(),'wrong PIN refused');
      document.getElementById('finUnlockPass').value='2741';await T.finUnlock();
      assert(!RoseachyFinance.locked(),'correct PIN works');return true;
    """))
    test("G full backup and verified restoration preserve independent balances",lambda:js("""
      window.__restoreExpected={cash:T.calc().expectedCash,credit:T.CreditAccounts.balance('fixture-customer-0'),stock:T.getStock()[0].qty};
      window.__backup=await T.roseachySafeBackup();
      assert(await T.roseachyVerifyBackupDigest(__backup),'digest');
      assert(await T.restoreFullBackup(__backup,{confirmRestore:false})===true,'verified restore');
      assert(T.calc().expectedCash===__restoreExpected.cash,'cash');
      assert(T.CreditAccounts.balance('fixture-customer-0')===__restoreExpected.credit,'credit');
      assert(T.getStock()[0].qty===__restoreExpected.stock,'stock');
      assert((await T.RS.verify()).ok,'database verification');return __restoreExpected;
    """))
    test("Malformed backup cannot replace valid records",lambda:js("""
      const before=JSON.stringify(T.getStock()),bad=JSON.parse(JSON.stringify(__backup));
      bad.stock[0].qty=-1;
      assert(await T.restoreFullBackup(bad,{confirmRestore:false})===false,'corrupt digest rejected');
      assert(JSON.stringify(T.getStock())===before,'records preserved');
      delete bad.integrity;
      assert(await T.restoreFullBackup(bad,{confirmRestore:false})===false,'invalid quantity rejected');
      assert(JSON.stringify(T.getStock())===before,'records still preserved');return true;
    """))
    test("I supported themes and restored obsolete theme fallback",lambda:js("""
      for(const theme of ['cobalt','ember','pearl','cyanflux','monomint']){
        const a=T.saveAppearanceSettings({...T.getAppearanceSettings(),theme},false);
        assert(a.theme===theme,'supported theme retained');
      }
      const source=await T.roseachySafeBackup();delete source.integrity;
      source.appearanceSettings.theme='lunar-glass';
      const pricing=JSON.stringify(source.appearanceSettings.pricing);
      assert(await T.restoreFullBackup(source,{confirmRestore:false})===true,'old theme backup restored');
      assert(T.getAppearanceSettings().theme==='cobalt','Cobalt fallback');
      assert(JSON.stringify(T.getAppearanceSettings().pricing)===pricing,'pricing unchanged');
      for(const theme of ['acid-ledger','violet-wallet','teal-apricot','unknown','__proto__'])
        assert(T.supportedTheme(theme)==='cobalt','unknown fallback');
      return true;
    """))
    test("Untrusted product/customer text is escaped in rendered HTML",lambda:js("""
      const payload='<img src=x onerror=\"window.__xss=1\">';
      await T.inventoryCommit(()=>{const rows=T.getStock();rows[0].name=payload;T.setStock(rows,[rows[0].id]);return true},'Stock');
      T.renderStock();T.setTab('Stock',false);
      assert(!window.__xss,'not executed');
      assert(!document.querySelector('#stockTable img'),'no injected image');
      assert(document.getElementById('stockTable').textContent.includes(payload),'literal product text');
      await T.inventoryCommit(()=>{const customers=T.CreditAccounts.customers();customers[0].name=payload;T.RS.set('roseachy_credit_customers_v1',JSON.stringify(customers));return true},'Credit Accounts');
      T.CreditAccounts.open('fixture-customer-0');
      assert(!document.querySelector('#creditOverlay img'),'no injected customer image');
      assert(document.getElementById('creditOverlay').textContent.includes(payload),'literal customer text');
      assert(!window.__xss,'customer payload not executed');document.getElementById('creditClose').click();return true;
    """))
    test("Requested navigation cleanup and preserved right-side Credit button",lambda:js("""
      const buttons=[...document.querySelectorAll('button')].filter(x=>x.id==='creditAccountsBtn'||x.id==='creditMenuEntry');
      assert(buttons.some(x=>x.id!=='creditMenuEntry'),'right-side credit entry exists');
      assert(!document.getElementById('creditMenuEntry'),'duplicate top-left entry removed');
      return buttons.map(x=>x.id);
    """))
    test("Fresh reload remains valid",lambda: (page.reload(wait_until="load"),ready(page),page.evaluate("RoseachyStore.status()"))[-1])
    test("No unexpected browser runtime errors",lambda: (_ for _ in ()).throw(AssertionError(errors)) if errors else True)
    context.close();b.close()
failed=sum(x["status"]=="failed" for x in results)
print(f"{len(results)-failed} passed, {failed} failed; {len(downloads)} safety backup downloads preserved",flush=True)
sys.exit(1 if failed else 0)
