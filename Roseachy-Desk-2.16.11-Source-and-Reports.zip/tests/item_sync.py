from sync_support import *
with sync_playwright() as p:
 b=launch(p)
 try:
  pages=enroll(b,['app','original']);a,z=[v[0] for v in pages]
  a.evaluate('''async()=>{const T=__test,$=id=>document.getElementById(id);T.switchDesk('sales');$('type').value='sale_cash';T.resetTxForm();for(let i=0;i<3;i++){T.chooseProductSuggestion(T.getStock()[i]);$('qty').value=2;T.computeTotal();$('holdBtn').click();}$('holdCustPaid').value=600;$('holdCustReturned').value=0;$('addBtn').click();await T.RS.whenSaved()}''');a.wait_for_function('!__test.busy');exchange(a,z,True)
  assert a.evaluate('__test.tx.map(t=>[t.id,t.qty,t.amount])')==z.evaluate('__test.tx.map(t=>[t.id,t.qty,t.amount])')
  record('New cart and stock converge with 2.16.9 peer on duplicate import')
  a.evaluate('''async()=>{const T=__test,$=id=>document.getElementById(id);T.switchDesk('sales');window.middle=JSON.stringify(T.tx[1]);window.id=T.tx[0].purchaseGroupId;T.CartCorrections.open(id);$('cartCorrectionItemQty_0').value=4;$('cartCorrectionItemQty_0').dispatchEvent(new Event('input',{bubbles:true}));$('cartCorrectionPaid').value=800;await T.CartCorrections.save();if(T.tx[0].qty!==4)throw Error($('toast').textContent);if(JSON.stringify(T.tx[1])!==middle)throw Error('Unedited middle item changed')}''')
  exchange(a,z,True)
  assert a.evaluate('__test.tx.map(t=>[t.id,t.qty,t.amount,t.creditEditHistory?.length||0])')==z.evaluate('__test.tx.map(t=>[t.id,t.qty,t.amount,t.creditEditHistory?.length||0])')
  assert a.evaluate('__test.getStock().map(p=>p.qty)')==z.evaluate('__test.getStock().map(p=>p.qty)')==[9996,9998,9998,10000]
  record('Quantity correction and audit arrive once; unedited item remains byte-identical')
  a.evaluate('''async()=>{const T=__test;T.switchDesk('sales');const before=JSON.stringify(T.tx);T.CartCorrections.open(id);await T.CartCorrections.save();if(JSON.stringify(T.tx)!==before)throw Error('No-op edit changed cart')}''')
  record('Opening and saving without edits leaves every transaction and audit unchanged')
  a.evaluate('''async()=>{const T=__test,$=id=>document.getElementById(id);T.CartCorrections.open(id);$('cartCorrectionItemQty_0').value=1;$('cartCorrectionPaid').value=500;await T.CartCorrections.save();if(T.tx[0].qty!==1)throw Error($('toast').textContent)}''');exchange(a,z,True)
  assert a.evaluate('__test.getStock().map(p=>p.qty)')==z.evaluate('__test.getStock().map(p=>p.qty)')==[9999,9998,9998,10000]
  assert a.evaluate('__test.calc().sales')==z.evaluate('__test.calc().sales')==500
  record('Quantity reduction restores stock exactly once across current and earlier peer')
  for pg,errors in pages:assert not errors,errors
  result['status']='passed'
 except Exception as e:result['status']='failed';result['error']=str(e);traceback.print_exc()
 finally:out.write_text(json.dumps(result,indent=2));b.close()
raise SystemExit(0 if result.get('status')=='passed' else 1)
