from visual_support import *
results=[]
SET="""v=>{for(const k of ['roundnessLevel','borderWeightLevel','shadowLevel']){const e=document.querySelector('[data-setting="'+k+'"]');e.value=v;e.dispatchEvent(new Event('input',{bubbles:true}))}}"""
with sync_playwright() as p:
 b=launch(p);c=context_for(b,'app');page,errors=open_page(c);page.on('dialog',lambda d:d.accept());seed(page)
 page.evaluate("()=>{const T=__test;T.chooseProductSuggestion(T.getStock()[0]);document.getElementById('qty').value=2;T.computeTotal();document.getElementById('holdBtn').click()}")
 before=page.evaluate('()=>JSON.stringify({tx:__test.tx,stock:__test.getStock(),cart:__test.heldItems})')
 for width in WIDTHS:
  page.set_viewport_size({'width':width,'height':900})
  for name in THEMES:
   for mode in ['light','dark']:
    theme(page,name,mode)
    for value in [0,100]:
     page.evaluate(SET,value)
     for view in ['sales','market','financial','settings']:
      screen(page,view);m=page.evaluate(MEASURE)
      assert m['scrollWidth']<=m['pageWidth']+2,(width,name,mode,value,view,'page overflow')
      assert not m['failures'],(width,name,mode,value,view,m['failures'])
      if view=='sales':
       page.locator('#note').focus();assert page.locator('#note').evaluate('e=>parseFloat(getComputedStyle(e).outlineWidth)>=2')
       for id in ['note','totalAmount','holdCustPaid']:
        style=page.locator('#'+id).evaluate("e=>({border:getComputedStyle(e).borderStyle,mask:getComputedStyle(e).maskImage,transform:getComputedStyle(e).transform})")
        assert style=={'border':'solid','mask':'none','transform':'none'},(id,style)
       radius=page.locator('#holdPaymentBox').evaluate('e=>parseFloat(getComputedStyle(e).borderTopLeftRadius)');assert abs(radius-(value*.28))<.02,(value,radius)
      if width in [320,1440] and name in ['cobalt','ember','monomint'] and mode=='light' and view in ['financial','sales']:
       if view=='sales':page.locator('#txEntryCard').scroll_into_view_if_needed()
       page.screenshot(path=str(ROOT/'results/screenshots/after'/f'extreme-{width}-{name}-{mode}-{value}-{view}.png'),animations='disabled')
      results.append({'width':width,'theme':name,'mode':mode,'level':value,'view':view,'textSamples':m['tested'],'status':'passed'})
  (ROOT/'results/extreme-appearance.json').write_text(json.dumps({'screens':results,'browserErrors':errors},indent=2));print('EXTREMES',width,len(results),flush=True)
 assert before==page.evaluate('()=>JSON.stringify({tx:__test.tx,stock:__test.getStock(),cart:__test.heldItems})')
 c.close()
 # Real pointer and touch actions on the native range, not custom gesture code.
 for profile in ['desktop','mobile']:
  c=context_for(b,'app',profile);page,err=open_page(c);theme(page,'cobalt','light');screen(page,'settings');page.locator('#appearanceRoundness').evaluate("e=>e.closest('details').open=true")
  trace=[]
  for id in ['appearanceRoundness','appearanceBorder','appearanceShadow']:
   el=page.locator('#'+id);el.evaluate("e=>e.closest('details').open=true");el.scroll_into_view_if_needed();rect=el.bounding_box()
   for frac in [.2,.8,.4]:
    x=rect['x']+rect['width']*frac;y=rect['y']+rect['height']/2
    if profile=='mobile':page.touchscreen.tap(x,y)
    else:page.mouse.click(x,y)
    value=int(el.input_value());out=page.locator('output[for="'+id+'"]').inner_text();assert str(value)==out
    assert abs(value-frac*100)<12,(profile,id,frac,value)
    trace.append([id,frac,value])
  assert not err,err;(ROOT/'results'/f'{profile}-range-input.json').write_text(json.dumps({'status':'passed','positions':trace},indent=2));c.close()
 assert not errors,errors;b.close()
