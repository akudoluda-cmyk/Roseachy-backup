from pathlib import Path
import hashlib,json,subprocess,zipfile,shutil
r=Path(__file__).resolve().parents[1];app=r/'app';dest=r/'deliverables';dest.mkdir(exist_ok=True)
def git(*args):return subprocess.check_output(['git',*args],cwd=app,text=True).strip()
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
commit=git('rev-parse','HEAD');assert not git('status','--porcelain')
v=json.loads((r/'results/final-validation.json').read_text());assert v['passed'] and v['sourceSHA256']==sha(app/'index.html')
m=json.loads((r/'results/responsive-matrix.json').read_text());assert len(m['screens'])==1056 and not m['browserErrors'];assert not any(x['failures'] or x['pageOverflow'] or x['clippedControls'] for x in m['screens'])
remote=git('ls-remote','origin','refs/heads/release-2.16.9').split()[0];assert remote==commit
files=git('ls-files').splitlines();assert len(files)==13
provenance={'version':'2.16.9','sourceCommit':commit,'githubBranch':'release-2.16.9','verifiedRemoteCommit':remote,'sourceFiles':{name:sha(app/name) for name in files},'validation':v,'regressionBrowserGroups':91,'responsiveCases':1056,'modalCases':192,'cloudflareDeployed':False}
(r/'results/release-provenance.json').write_text(json.dumps(provenance,indent=2))
with (r/'PROGRESS.md').open('a') as f:f.write('\nFinal release: 14 validation commands passed, 91 regression browser groups, 1056 responsive cases and 192 modal cases. Source '+commit+' pushed to release-2.16.9 and remote verified. Deployment ZIP and preview prepared; no Cloudflare deployment.\n')
static=dest/'Roseachy-Desk-2.16.9-Cloudflare-Pages.zip'
with zipfile.ZipFile(static,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for name in files:z.write(app/name,name)
with zipfile.ZipFile(static) as z:
 assert z.testzip() is None and set(z.namelist())==set(files)
 for name in files:assert hashlib.sha256(z.read(name)).hexdigest()==sha(app/name)
shutil.copy2(static,r/'checkpoints/04-complete-2.16.9.zip')
source=dest/'Roseachy-Desk-2.16.9-Source-and-Reports.zip';entries={}
for name in ['README.md','REQUEST.md','CONTINUATION.md','PROGRESS.md']:entries[name]=r/name
for name in ['app','baseline','original','tests','results','reports','checkpoints']:
 for p in (r/name).rglob('*'):
  if p.is_file() and '__pycache__' not in p.parts and '.git' not in p.parts:entries[str(Path(name)/p.relative_to(r/name))]=p
for name in ['package.json','package-lock.json']:entries['tools/'+name]=r/'tools'/name
for p in dest.glob('*.html'):entries[p.name]=p
with zipfile.ZipFile(source,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for name,p in sorted(entries.items()):z.write(p,name)
with zipfile.ZipFile(source) as z:
 assert z.testzip() is None
 for name,p in entries.items():assert hashlib.sha256(z.read(name)).hexdigest()==sha(p)
artifacts=[static,source,*dest.glob('*.html'),dest/'VERIFICATION.md']
checks={p.name:{'bytes':p.stat().st_size,'sha256':sha(p),**({'entries':len(zipfile.ZipFile(p).namelist()),'crcVerified':True,'allEntryHashesVerified':True} if p.suffix=='.zip' else {})} for p in artifacts}
(dest/'SHA256SUMS.txt').write_text(''.join(v['sha256']+'  '+name+'\n' for name,v in checks.items()))
(dest/'artifact-verification.json').write_text(json.dumps(checks,indent=2));print(json.dumps(checks,indent=2))
