"""Run the same real UI fixture against immutable original and built React app."""
from pathlib import Path
from http.server import ThreadingHTTPServer, SimpleHTTPRequestHandler
from functools import partial
from threading import Thread
from tempfile import TemporaryDirectory
import json, zipfile, hashlib, sys
from playwright.sync_api import sync_playwright, expect

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'tests/evidence' / (('baseline-mobile' if '--mobile' in sys.argv else 'baseline-desktop')+('-cart' if '--cart' in sys.argv else '-supplier' if '--supplier' in sys.argv else ''))
VIEWPORT = {'width':390,'height':844} if '--mobile' in sys.argv else {'width':1280,'height':900}
class Quiet(SimpleHTTPRequestHandler):
    def log_message(self, *args): pass

def fixture(browser, root, label):
    server = ThreadingHTTPServer(('127.0.0.1', 0), partial(Quiet, directory=str(root)))
    Thread(target=server.serve_forever, daemon=True).start()
    context = browser.new_context(accept_downloads=True, service_workers='block',viewport=VIEWPORT)
    page = context.new_page()
    errors=[]
    page.on('pageerror', lambda e: errors.append(str(e)))
    try:
        page.goto(f'http://127.0.0.1:{server.server_port}')
        page.wait_for_function('window.__roseachyFirstUsableMs !== undefined')
        page.locator('#tabBtnStock').click()
        page.locator('[data-target="stockEntryBody"]').click()
        page.locator('#stockDivision').select_option('essentials')
        for field,value in [('stockName','Parity Product'),('stockQty','12'),('stockCost','200'),('stockPrice','300')]:
            page.locator('#'+field).fill(value)
        page.locator('#stockAddBtn').click()
        expect(page.locator('#stockTable')).to_contain_text('Parity Product')
        page.evaluate('RoseachyStore.whenSaved()')
        if '--cart' in sys.argv:
            page.locator('#stockDivision').select_option('essentials')
            for field,value in [('stockName','Cart Second Product'),('stockQty','6'),('stockCost','80'),('stockPrice','125')]:page.locator('#'+field).fill(value)
            page.locator('#stockAddBtn').click();expect(page.locator('#stockTable')).to_contain_text('Cart Second Product');page.evaluate('RoseachyStore.whenSaved()')
        page.locator('#tabBtnTx').click()
        page.locator('#note').fill('Parity Product')
        page.locator('[data-product-suggest]').click()
        page.locator('#qty').fill('2')
        page.locator('#custPaid').fill('600')
        page.locator('#addBtn').click()
        expect(page.locator('#ledger')).to_contain_text('₦600.00')
        page.evaluate('RoseachyStore.whenSaved()')
        if '--financial' in sys.argv: financial_scenario(page)
        if '--cart' in sys.argv: cart_scenario(page,label)
        if '--supplier' in sys.argv: supplier_scenario(page,label)
        state=page.evaluate('({stock:RoseachyStore.getObject("dsb_stock_v2"), draft:RoseachyStore.getObject("dsb_draft_v2"),creditCustomers:RoseachyStore.getObject("roseachy_credit_customers_v1")})')
        assert next(p for p in state['stock'] if p['name']=='Parity Product')['qty']==(14 if '--supplier' in sys.argv else 7 if '--cart' in sys.argv else 6 if '--credit' in sys.argv else 8 if '--financial' in sys.argv else 10)
        if '--supplier' in sys.argv:state['market']=page.evaluate('RoseachyStore.getObject("roseachy_market_v1")')
        # A real export through the existing download UI, never private test hooks.
        page.locator('#tabBtnStock').click()
        toggle=page.locator('[data-target="stockTransferBody"]')
        if toggle.get_attribute('aria-expanded') != 'true': toggle.click()
        with page.expect_download() as d:
            page.locator('#stockExportJsonBtn').click()
        path=OUT/f'{label}-working-stock.json'; d.value.save_as(path)
        export=json.loads(path.read_text())
        if '--backup' in sys.argv:
            export_full(page,label)
            if label=='react': restore_original_backup(browser,f'http://127.0.0.1:{server.server_port}')
        assert sorted(export['stock'],key=lambda p:p['name'])==sorted(state['stock'],key=lambda p:p['name'])
        page.reload(wait_until='networkidle')
        page.wait_for_function('window.__roseachyFirstUsableMs !== undefined')
        assert sorted(page.evaluate('RoseachyStore.getObject("dsb_stock_v2")'),key=lambda p:p['name'])==sorted(state['stock'],key=lambda p:p['name'])
        assert page.evaluate('RoseachyStore.verify()')['ok']
        assert not errors, errors
        # Compare all persisted stock + working transaction fields, ignoring only
        # generated identities/time and their references. Money/quantity untouched.
        ids={}
        def normalize(value, key=''):
            if isinstance(value,dict):
                for k in [k for k in value if k=='id' or k.endswith('Id')]:
                    if isinstance(value.get(k),str): ids.setdefault(value[k], f'id-{len(ids)}')
                return {ids.get(k,k):normalize(v,k) for k,v in value.items()}
            if isinstance(value,list): return [normalize(v) for v in value]
            if isinstance(value,str):
                if key in ('ts','createdAt','editedAt','updatedAt','completedAt'): return '<time>'
                return ids.get(value,value)
            return value
        state['totals']=page.evaluate('Object.fromEntries(["mSales","mNetSales","mReceived","mCash","mBank","mProfit","mCogs","mRefunds","mExpenses","mDebt","mPayable"].map(id=>[id,document.getElementById(id).textContent]))')
        state['stock'].sort(key=lambda p:p['name'])
        result=normalize(state)
        (OUT/f'{label}-normalized.json').write_text(json.dumps(result,indent=2))
        print('PASS',label,'create, sale, export and reload',flush=True)
        return result
    except Exception:
        page.screenshot(path=str(OUT/f'{label}-failure.png'),full_page=True)
        raise
    finally:
        context.close();server.shutdown();server.server_close()

def export_full(page,label):
    page.locator('#tabBtnTx').click()
    toggle=page.locator('[data-target="dataHistoryBody"]')
    if toggle.get_attribute('aria-expanded')!='true':toggle.click()
    with page.expect_download() as download:page.locator('#backupBtn').click()
    path=OUT/f'{label}-full-backup.json';download.value.save_as(path)
    data=json.loads(path.read_text());assert data['format']=='roseachy-full-backup' and data['integrity']['algorithm']=='SHA-256'
    verified=page.evaluate("""async data=>{const expected=data.integrity.hash;delete data.integrity;const digest=await crypto.subtle.digest('SHA-256',new TextEncoder().encode(JSON.stringify(data)));return Array.from(new Uint8Array(digest),b=>b.toString(16).padStart(2,'0')).join('')===expected}""",data)
    assert verified
    print('PASS',label,'Full Backup exported with verified SHA-256',flush=True)

def restore_original_backup(browser,url):
    context=browser.new_context(accept_downloads=True,service_workers='block',viewport=VIEWPORT)
    page=context.new_page();errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
    page.on('dialog',lambda d:d.accept())
    page.on('download',lambda d:d.save_as(OUT/'restore-safety-backup.json'))
    original=json.loads((OUT/'original-full-backup.json').read_text())
    try:
        page.goto(url);page.wait_for_function('window.__roseachyFirstUsableMs !== undefined')
        assert page.evaluate('RoseachyStore.getObject("dsb_stock_v2").length')==0
        page.locator('#importFile').set_input_files(str(OUT/'original-full-backup.json'))
        expect(page.locator('#toast')).to_contain_text('Full Backup restored and verified',timeout=15000)
        assert (OUT/'restore-safety-backup.json').is_file()
        page.reload(wait_until='networkidle');page.wait_for_function('window.__roseachyFirstUsableMs !== undefined')
        assert page.evaluate('RoseachyStore.getObject("dsb_stock_v2")')==original['stock']
        assert page.evaluate('RoseachyStore.getObject("dsb_draft_v2").tx')==original['draft']['tx']
        if '--supplier' in sys.argv:
            assert page.evaluate('RoseachyStore.getObject("roseachy_market_v1")')==original['market']
        restored=page.evaluate('({draft:RoseachyStore.getObject("dsb_draft_v2"),market:RoseachyStore.getObject("roseachy_market_v1")})')
        assert page.evaluate('RoseachyStore.verify()')['ok']
        changed=json.loads(json.dumps(original));changed['stock'][0]['qty']+=1
        malformed=OUT/'tampered-backup.json';malformed.write_text(json.dumps(changed))
        page.locator('#importFile').set_input_files(str(malformed))
        expect(page.locator('#toast')).to_contain_text('checksum mismatch')
        assert page.evaluate('RoseachyStore.getObject("dsb_stock_v2")')==original['stock']
        assert page.evaluate('({draft:RoseachyStore.getObject("dsb_draft_v2"),market:RoseachyStore.getObject("roseachy_market_v1")})')==restored
        assert not errors,errors
        print('PASS original Full Backup → fresh React profile → reload; tampered backup rejected without changes',flush=True)
    except Exception:
        page.screenshot(path=str(OUT/'restore-failure.png'),full_page=True);raise
    finally:context.close()

def supplier_scenario(page,label):
    page.locator('#type').select_option('purchase_credit');page.locator('#note').fill('Parity Product');page.locator('[data-product-suggest]').click()
    page.locator('#qty').fill('4');page.locator('#amount').fill('200');page.locator('#party').fill('Supplier fixture')
    page.locator('#addBtn').click();page.wait_for_function('RoseachyStore.getObject("dsb_draft_v2").tx.length===2');page.evaluate('RoseachyStore.whenSaved()')
    expect(page.locator('#mPayable')).to_have_text('₦800.00')
    assert page.evaluate('RoseachyStore.getObject("dsb_stock_v2")[0].qty')==14
    page.locator('#deskMenuBtn').click();page.locator('#marketDeskEntry').click();page.locator('#marketDebtSummary').click()
    expect(page.locator('#supplierDebtList')).to_contain_text('₦800.00')
    page.locator('#supplierDebtList [data-debt-pay]').click();page.locator('#supplierPaymentAmount').fill('900');page.locator('#supplierPaymentSave').click()
    expect(page.locator('#supplierPaymentWarn')).to_contain_text('exceeds');assert page.evaluate('RoseachyStore.getObject("dsb_draft_v2").tx.length')==2
    page.locator('#supplierPaymentAmount').fill('300');page.locator('#supplierPaymentNote').fill('First payment')
    page.locator('#supplierPaymentSave').evaluate('(button)=>{button.click();button.click()}')
    expect(page.locator('#supplierPaymentOverlay')).not_to_be_visible();page.evaluate('RoseachyStore.whenSaved()')
    assert page.evaluate('RoseachyStore.getObject("dsb_draft_v2").tx.length')==3
    expect(page.locator('#supplierDebtList')).to_contain_text('₦500.00')
    page.locator('#supplierDebtList [data-debt-pay]').click();page.locator('#supplierPaymentAmount').fill('200');page.locator('#supplierPaymentNote').fill('Second payment')
    before=page.evaluate('({draft:RoseachyStore.getObject("dsb_draft_v2"),market:RoseachyStore.getObject("roseachy_market_v1")})')
    page.evaluate("""()=>{const put=IDBObjectStore.prototype.put;let count=2;IDBObjectStore.prototype.put=function(...args){if(this.name==='draft'&&args[0]?.tx?.length===4&&args[0].tx.at(-1)?.type==='supplier_pay_cash'&&args[0].tx.at(-1)?.amount===200&&count-->0){if(!count)IDBObjectStore.prototype.put=put;throw new DOMException('Supplier write fault','QuotaExceededError')}return put.apply(this,args)}}""")
    page.locator('#supplierPaymentSave').click();expect(page.locator('#supplierPaymentWarn')).to_contain_text('not saved')
    assert page.evaluate('({draft:RoseachyStore.getObject("dsb_draft_v2"),market:RoseachyStore.getObject("roseachy_market_v1")})')==before
    expect(page.locator('#supplierPaymentAmount')).to_have_value('200');page.locator('#supplierPaymentSave').click()
    expect(page.locator('#supplierPaymentOverlay')).not_to_be_visible();page.evaluate('RoseachyStore.whenSaved()')
    expect(page.locator('#supplierDebtList')).to_contain_text('₦300.00')
    rows=page.evaluate('RoseachyStore.getObject("dsb_draft_v2").tx');assert len(rows)==4 and [r['type'] for r in rows[-2:]]==['supplier_pay_cash','supplier_pay_cash']
    assert rows[-2]['amount']==300 and rows[-1]['amount']==200
    purchases=page.evaluate('RoseachyStore.getObject("roseachy_market_v1").marketPurchases');assert len(purchases)==1 and len(purchases[0]['payments'])==2
    assert rows[-1]['supplierPurchaseId']==purchases[0]['id'] and rows[-2]['supplierPurchaseId']==purchases[0]['id']
    page.locator('#supplierOtherPayment').click();expect(page.locator('#supplierPaymentManualWrap')).to_be_visible()
    page.locator('#supplierPaymentName').fill('External Supplier');page.locator('#supplierPaymentAmount').fill('150');page.locator('#supplierPaymentNote').fill('Outside advance')
    day=page.locator('#supplierPaymentDate').input_value();page.locator('#supplierPaymentDate').fill('2000-01-01');page.locator('#supplierPaymentSave').click()
    expect(page.locator('#supplierPaymentWarn')).to_contain_text('payment business day');page.locator('#supplierPaymentDate').fill(day)
    page.locator('#supplierPaymentSave').click();expect(page.locator('#supplierPaymentWarn')).to_contain_text('Insufficient business cash')
    assert page.evaluate('RoseachyStore.getObject("dsb_draft_v2").tx.length')==4
    page.locator('#supplierPaymentFunding').select_option('external')
    expect(page.locator('#supplierPaymentMethodWrap')).to_have_class('hidden')
    if label=='react':expect(page.locator('#supplierPaymentMethodWrap')).not_to_be_visible()
    else:
        expect(page.locator('#supplierPaymentMethodWrap')).to_be_visible()
        print('KNOWN ORIGINAL DEFECT: external supplier funding hides the method logically but CSS keeps it visible',flush=True)
    page.locator('#supplierPaymentAmount').fill('50')
    page.locator('#supplierPaymentSave').click();expect(page.locator('#supplierPaymentOverlay')).not_to_be_visible();page.evaluate('RoseachyStore.whenSaved()')
    external=page.evaluate('RoseachyStore.getObject("dsb_draft_v2").tx.at(-1)')
    assert external['type']=='supplier_advance_cash' and external['paymentFunding']=='external' and external['amount']==50
    page.locator('#deskMenuBtn').click();page.locator('#deskMenu [data-desk="sales"]').click()
    expect(page.locator('#mCash')).to_have_text('₦100.00');expect(page.locator('#mPayable')).to_have_text('₦300.00')
    print('PASS supplier credit purchase, linked partial payments, excess rejection, duplicate submit, failed write/retry, date/cash guards, external advance and reconciled payable',flush=True)

def cart_scenario(page,label):
    def select(name,qty):
        page.locator('#note').fill(name);page.locator('[data-product-suggest]').click();page.locator('#qty').fill(str(qty))
        page.locator('#holdBtn').click()
    select('Parity Product',2);select('Cart Second Product',1)
    page.locator('#holdList [data-hdel]').last.click()
    assert page.locator('#holdList [data-cart-item]').count()==1
    select('Cart Second Product',1)
    expect(page.locator('#holdTotal')).to_have_text('₦725.00')
    assert page.locator('#holdList [data-cart-item]').count()==2
    first=page.locator('#holdList [data-cart-item]').first
    first.locator('summary').click();first.locator('[data-item-qty]').fill('99')
    expect(first.locator('[data-item-error]')).to_contain_text('Not enough stock')
    page.locator('#addBtn').click()
    assert len(page.evaluate('RoseachyStore.getObject("dsb_draft_v2").tx'))==1
    first.locator('[data-item-qty]').fill('3')
    expect(page.locator('#holdTotal')).to_have_text('₦1,025.00')
    page.locator('#holdCustPaid').fill('1025');page.evaluate('RoseachyStore.whenSaved()')
    held=page.evaluate('RoseachyStore.getObject("dsb_hold_v1")')
    assert len(held['heldItems'])==2 and held['heldItems'][0]['qty']==3
    page.reload(wait_until='networkidle');page.wait_for_function('window.__roseachyFirstUsableMs !== undefined')
    expect(page.locator('#holdPanel')).to_be_visible();expect(page.locator('#holdCustPaid')).to_have_value('1025')
    expect(page.locator('#holdTotal')).to_have_text('₦1,025.00')
    assert page.evaluate('RoseachyStore.getObject("dsb_stock_v2").find(p=>p.name==="Parity Product").qty')==10
    product_id=page.evaluate('RoseachyStore.getObject("dsb_stock_v2").find(p=>p.name==="Parity Product").id')
    page.locator('#tabBtnStock').click();page.locator(f'#stockTable [data-sedit="{product_id}"]').click()
    page.locator('#stockPrice').fill('350');page.locator('#stockAddBtn').click();page.evaluate('RoseachyStore.whenSaved()')
    page.locator('#tabBtnTx').click();expect(page.locator('#holdTotal')).to_have_text('₦1,025.00')
    held=page.evaluate('RoseachyStore.getObject("dsb_hold_v1")')
    before=page.evaluate('({stock:RoseachyStore.getObject("dsb_stock_v2"),tx:RoseachyStore.getObject("dsb_draft_v2").tx})')
    page.evaluate('''() => {const put=IDBObjectStore.prototype.put;let remaining=2;IDBObjectStore.prototype.put=function(...args){if(this.name==='stockRecords'&&remaining-- > 0){if(!remaining)IDBObjectStore.prototype.put=put;throw new DOMException('Cart failure test','QuotaExceededError')}return put.apply(this,args)};}''')
    page.locator('#addBtn').click();expect(page.locator('#toast')).to_contain_text('Nothing saved:')
    assert page.evaluate('({stock:RoseachyStore.getObject("dsb_stock_v2"),tx:RoseachyStore.getObject("dsb_draft_v2").tx})')==before
    if label=='original':
        # Characterized baseline defect: data rolls back, but the cart stays hidden until reload.
        expect(page.locator('#holdPanel')).not_to_be_visible()
        assert page.evaluate('RoseachyStore.getObject("dsb_hold_v1")')==held
        page.reload(wait_until='networkidle');page.wait_for_function('window.__roseachyFirstUsableMs !== undefined')
        print('KNOWN ORIGINAL DEFECT: failed cart save hides preserved draft until reload',flush=True)
    expect(page.locator('#holdPanel')).to_be_visible();expect(page.locator('#holdCustPaid')).to_have_value('1025')
    assert page.locator('#holdList [data-cart-item]').count()==2
    page.locator('#addBtn').evaluate('(button)=>{button.click();button.click()}')
    page.wait_for_function('RoseachyStore.getObject("dsb_draft_v2").tx.length===3');page.evaluate('RoseachyStore.whenSaved()')
    rows=page.evaluate('RoseachyStore.getObject("dsb_draft_v2").tx');stock=page.evaluate('RoseachyStore.getObject("dsb_stock_v2")')
    assert rows[1]['purchaseGroupId']==rows[2]['purchaseGroupId'] and rows[1]['purchaseGroupId']
    assert rows[1]['amount']==900 and rows[2]['amount']==125
    assert {p['name']:p['qty'] for p in stock}=={'Parity Product':7,'Cart Second Product':5}
    expect(page.locator('#holdPanel')).not_to_be_visible();expect(page.locator('#mCash')).to_have_text('₦1,625.00')
    assert page.evaluate('RoseachyStore.getObject("dsb_hold_v1")') is None
    print('PASS two-product cart, removal, invalid edit guard, quantity edit, draft reload, captured price, failed-write rollback/retry, double-click completion and reconciliation',flush=True)

def credit_scenario(page):
    page.locator('#creditAccountsBtn').click();page.locator('#creditNew').click()
    page.locator('#creditName').fill('Parity Credit Customer');page.locator('#creditConfirm').click()
    expect(page.locator('#creditAddProducts')).to_be_visible()
    page.locator('#creditAddProducts').click()
    page.locator('[data-product-search]').fill('Parity Product');page.locator('[data-credit-product]').click()
    page.locator('[data-quantity]').fill('2');page.locator('#creditPaid').fill('200');page.locator('#creditConfirm').click()
    expect(page.locator('#creditRecordPayment')).to_be_visible()
    expect(page.locator('#creditContent > .creditSummary')).to_contain_text('₦400.00')
    page.evaluate('RoseachyStore.whenSaved()')
    assert page.evaluate('RoseachyStore.getObject("dsb_stock_v2")[0].qty')==6
    page.locator('#creditRecordPayment').click();page.locator('#creditPaymentAmount').fill('100');page.locator('#creditConfirm').click()
    expect(page.locator('#creditRecordPayment')).to_be_visible()
    expect(page.locator('#creditContent > .creditSummary')).to_contain_text('₦300.00')
    page.locator('#creditClose').click();page.evaluate('RoseachyStore.whenSaved()')
    expect(page.locator('#mCash')).to_have_text('₦850.00')
    rows=page.evaluate('RoseachyStore.getObject("dsb_draft_v2").tx')
    assert len(rows)==6 and rows[-2]['type']=='sale_account' and rows[-1]['type']=='credit_payment_cash'
    assert rows[-2]['splitCredit']==400 and rows[-1]['amount']==100
    print('PASS credit account purchase, partial payment, repayment, stock and cash reconciliation',flush=True)

def financial_scenario(page):
    def records(): return page.evaluate('RoseachyStore.getObject("dsb_draft_v2").tx')
    def commit(count):
        page.locator('#addBtn').click()
        page.wait_for_function('(n)=>RoseachyStore.getObject("dsb_draft_v2").tx.length===n',arg=count)
        page.evaluate('RoseachyStore.whenSaved()')
    def select_product():
        page.locator('#note').fill('Parity Product');page.locator('[data-product-suggest]').click()
    tid=records()[0]['id']
    page.locator('#ledger [data-edit]').click();page.evaluate('RoseachyStore.whenSaved()')
    page.locator('#qty').fill('3');page.locator('#custPaid').fill('900');commit(1)
    page.wait_for_function('RoseachyStore.getObject("dsb_stock_v2")[0].qty===9')
    assert records()[0]['id']==tid and records()[0]['amount']==900
    page.locator('#type').select_option('refund_cash');select_product()
    page.locator('#refundSource').select_option(tid);page.locator('#qty').fill('1');page.locator('#refundReturn').check();commit(2)
    assert records()[1]['amount']==300 and records()[1]['originalSaleId']==tid
    page.locator('#type').select_option('sale_transfer');select_product();page.locator('#qty').fill('2');commit(3)
    page.locator('#type').select_option('expense_cash');page.locator('#note').fill('Shop expense');page.locator('#amount').fill('50');commit(4)
    assert records()[3]['amount']==50
    page.locator('#ledger [data-tog]').first.click()
    expect(page.locator('.txDetail')).to_contain_text('Parity Product')
    expect(page.locator('#mNetSales')).to_have_text('₦1,200.00')
    expect(page.locator('#mCash')).to_have_text('₦550.00')
    expect(page.locator('#mBank')).to_have_text('₦600.00')
    expect(page.locator('#mCogs')).to_have_text('₦800.00')
    print('PASS edit, linked refund, transfer sale, expense, details and exact totals',flush=True)
    if '--credit' in sys.argv: credit_scenario(page)

OUT.mkdir(parents=True,exist_ok=True)
archive=ROOT/'reference/original-2.17.2.zip'
assert hashlib.sha256(archive.read_bytes()).hexdigest()=='55a9a1ba418c910d2065240bffe4a385a449f285f8e973cd335e9722be9e1a04'
with TemporaryDirectory() as temp, sync_playwright() as pw:
    with zipfile.ZipFile(archive) as z: z.extractall(temp)
    browser=pw.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox'])
    try:
        original=fixture(browser,Path(temp),'original')
        react=fixture(browser,ROOT/'dist','react')
        assert original==react, 'Persisted stock/draft parity differs; inspect normalized evidence'
        print('PASS all normalized stock and working-day fields match original 2.17.2',flush=True)
    finally: browser.close()
