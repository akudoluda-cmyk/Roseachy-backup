# ROSEACHY DESK — SEMANTIC COLOUR HIERARCHY, VISUAL DIFFERENTIATION & UI GUIDANCE UPGRADE

## PRIMARY OBJECTIVE

Perform a focused, application-wide user-interface refinement to improve Roseachy Desk's colour hierarchy, section differentiation, visual emphasis, and intuitive navigation.

Some parts of the current interface look overly plain, blended, or visually similar. Important sections, cards, headings, buttons, and status indicators do not always have enough visual distinction. This makes it harder for users to identify their current location, understand which information matters most, and recognize the next appropriate action.

**The goal is to make Roseachy Desk feel premium, professionally organized, visually distinctive, calm, and intuitive through more deliberate use of colour.**

Do not simply add more colours to the interface.

Develop a consistent visual system in which colours have clear purposes and users can immediately distinguish:

- Where they are in the application.
- Which section is active.
- Which information belongs together.
- Which controls are interactive.
- Which action is most important.
- Which records require attention.
- Which operations have succeeded or failed.
- Which information is secondary.

Preserve Roseachy's established visual identity, existing themes, navigation, business functionality, offline capabilities, and application architecture.

**Core principle: Every visual distinction must improve understanding, usability, or navigation. Avoid decorative colour that adds no practical value.**

---

# PART 1 — AUDIT THE EXISTING COLOUR SYSTEM

Before making changes, inspect the actual Roseachy source code and rendered application.

Do not begin by applying arbitrary colours or replacing the current theme.

## 1.1 Inspect the Existing Implementation

Examine:

1. Existing theme definitions and CSS variables.
2. Application backgrounds and surface colours.
3. Main navigation and active navigation indicators.
4. Page headings and section headings.
5. Cards, panels, toolbars, and collapsible sections.
6. Primary, secondary, tertiary, and destructive buttons.
7. Inputs, dropdowns, checkboxes, and date controls.
8. Tables, transaction rows, and expandable records.
9. Status indicators, alerts, and notification badges.
10. Loading, empty, disabled, selected, and error states.
11. Existing hover, focus, and pressed states.
12. Module-specific visual distinctions.
13. Responsive styling and theme-specific overrides.
14. Duplicate or conflicting CSS declarations.
15. Any colour rules that cause text or controls to disappear into their backgrounds.

Identify which elements are currently indistinguishable and why.

For example, a heading, card, and button may share similar backgrounds, borders, and text colours. Determine whether the appropriate fix is a stronger surface contrast, a clearer border, a more distinctive heading, an accent indicator, or a change in spacing.

**Fix the underlying styling rules rather than accumulating unrelated CSS overrides.**

## 1.2 Establish a Visual Hierarchy Map

Create an internal map of the intended hierarchy:

Application shell → Main navigation → Current section → Content group → Individual record → Supporting information.

Also establish the action hierarchy:

Primary action → Secondary action → Tertiary action → Destructive action.

And the information hierarchy:

Critical warning → Important status → Main financial information → Supporting details → Muted metadata.

Every level should be distinguishable without making the entire screen colourful.

---

# PART 2 — ESTABLISH A CONSISTENT SEMANTIC COLOUR SYSTEM

Introduce or refine a small, reusable set of semantic colour roles.

A colour should be selected because of the function it performs, not merely because it looks attractive.

Prefer existing design tokens and theme variables. Extend them only where necessary.

## 2.1 Application Background

Use the existing theme's main background as the foundation.

The background should provide a calm, visually comfortable surface on which content can be organized.

Ensure that:

- The page background is distinguishable from important content surfaces.
- Cards do not disappear into the background.
- Large areas do not contain unnecessary competing colour blocks.
- Dark themes retain sufficient depth and surface separation.
- Light themes do not make the entire interface appear flat or washed out.

Do not change the entire application background merely to make individual cards more noticeable.

## 2.2 Content Surfaces and Cards

Differentiate content containers using a deliberate combination of:

- Surface background.
- Border colour.
- Heading emphasis.
- Internal spacing.
- Section separation.
- Restrained accent indicators where appropriate.

A standard card should remain relatively neutral.

Important or currently active sections may use a subtle theme-derived tint, a more visible border, or a small accent treatment.

Avoid giving every card a different bright background.

Use consistent styling for components that perform the same role across the application.

## 2.3 Navigation and Active Location

Make the user's current location immediately recognizable.

Apply a consistent hierarchy to:

- Active main navigation.
- Selected tabs.
- Active nested sections.
- Current-page headings.
- Selected records.
- Open or expanded panels.

Active elements should have a clearly distinguishable visual treatment using the existing theme accent, such as a filled surface, accent border, underline, or another established indicator.

Inactive elements should remain readable but less prominent.

Do not rely exclusively on a tiny colour change to communicate which tab is selected.

Preserve Roseachy's existing navigation structure, including the current placement of Sales Desk, the top-right Credit Account button, the Market Desk Supplier tab, and the existing three-dot menu.

Do not create duplicate navigation controls.

## 2.4 Primary and Secondary Actions

Create a consistent button hierarchy.

### Primary action

Use the strongest appropriate theme accent for the single most important action in a local workflow.

Examples include:

- Add to Cart.
- Complete Sale.
- Save a supplier payment.
- Confirm a stock purchase.
- Save changes.
- Restore Working Stock, where appropriate after the required validation.

Not every button on a screen should use the primary style.

When two actions are equally important, use the application's established action hierarchy instead of making both overwhelmingly prominent.

### Secondary action

Use a clear but less prominent surface or outlined style.

Examples include:

- Search.
- Refresh.
- View Details.
- Return to Inventory.
- Open a report.
- Edit a non-destructive record.

### Tertiary action

Use a restrained text, icon, or low-emphasis button treatment for supplementary operations.

Do not make tertiary actions invisible or difficult to discover.

### Destructive action

Use a consistent warning or destructive treatment for operations such as permanent deletion or destructive replacement.

Do not use destructive colours for ordinary editing, closing a panel, or navigating backward.

### Disabled action

Disabled buttons must remain visibly disabled without becoming completely unreadable.

Maintain adequate text and icon contrast.

## 2.5 Inputs and Selection Controls

Inputs should remain visually distinct from the surrounding card.

Ensure that:

- Input backgrounds are distinguishable from card backgrounds.
- Labels are clearly readable.
- Placeholders remain secondary to entered values.
- Focused inputs have a visible theme-consistent outline or border.
- Dropdowns clearly display their selected values.
- Selected checkboxes and toggles are easy to recognize.
- Disabled controls remain legible.
- Validation errors are clearly associated with the relevant field.

Do not use the placeholder colour as the primary text colour.

Preserve all existing input functionality, suggestive search, date selection, quantity controls, and keyboard behaviour.

---

# PART 3 — GIVE ROSEACHY A CLEAR ACCENT-COLOUR HIERARCHY

Use colour to guide attention, not to decorate every available space.

## 3.1 Recommended Hierarchy

### Level 1 — Important navigation and primary actions

These elements should be immediately recognizable.

Use the strongest appropriate theme accent for the currently active navigation item and the most important local action.

### Level 2 — Section identity

Use clear section headings, subtle surface contrast, consistent card borders, and restrained accent indicators to define major content areas.

Users should be able to identify where a section begins and ends without reading every line.

### Level 3 — Important information

Give important totals, outstanding balances, selected records, and key results enough visual emphasis to stand out from ordinary descriptions.

Do not turn every numerical value into a highlighted financial card.

### Level 4 — Supporting information

Use quieter text and restrained surfaces for timestamps, secondary descriptions, references, and supporting metadata.

Keep such information readable.

### Level 5 — Status and feedback

Use a consistent semantic colour system for success, warning, error, information, pending work, and disabled states.

These colours must communicate meaning consistently across the entire application.

The hierarchy must remain recognizable across all supported themes.

---

# PART 4 — PRESERVE AND IMPROVE EXISTING THEMES

Roseachy has established themes, including Cobalt Studio, Midnight & Ember, and Pearl & Royal Blue.

Preserve their visual identities.

Do not replace all themes with one generic palette. Do not restore themes that were intentionally removed in previous versions.

Instead, define consistent semantic roles for each supported theme.

For example:

- A primary action must be prominent in every theme.
- An active tab must remain distinguishable in every theme.
- A warning must look like a warning regardless of the selected theme.
- A successful operation must have a recognizable success treatment.
- A card must remain distinguishable from the page background.
- Disabled controls must remain identifiable.
- Important text must retain sufficient contrast.

Theme-specific colours may differ, but the meaning of each colour role must remain consistent.

Do not introduce theme-specific behaviour that makes the same action look primary in one theme but insignificant in another.

## 4.1 Light Themes

Avoid excessive white-on-white surfaces.

Where several cards appear on a light background, use restrained differences in surface shade, borders, headings, and spacing to distinguish them.

Prevent low-contrast grey text, nearly invisible borders, and washed-out active states.

## 4.2 Dark Themes

Avoid excessive black-on-black or similarly dark surfaces.

Maintain clear separation between:

- Main background.
- Cards.
- Elevated panels.
- Inputs.
- Selected tabs.
- Active buttons.
- Modal overlays.

Do not rely entirely on shadows, which may be difficult to perceive on dark backgrounds.

## 4.3 Theme Switching

Switching themes must update the semantic colour roles consistently.

Do not require a page reload or lose application state merely to update styling.

Verify that saved theme preferences persist according to existing behaviour.

---

# PART 5 — APPLY THE HIERARCHY TO REAL ROSEACHY SCREENS

Do not stop after refining a few buttons.

Audit and improve the actual screens where visual blending creates confusion.

## 5.1 Sales Desk

Establish an intuitive visual sequence:

Product search → Product selection → Quantity and pricing → Cart → Purchase total → Payment → Completion.

Ensure that:

- The selected product is easy to identify.
- Price and quantity information is visually grouped.
- The cart is clearly distinguishable from product selection.
- Cart totals receive suitable emphasis.
- The main next action is easy to recognize.
- Secondary controls do not compete with checkout.
- Validation messages stand out without dominating the screen.
- Incomplete payments and outstanding balances remain distinguishable from actual receipts.

Preserve the existing multi-item purchasing workflow, held purchases, transaction editing, payment methods, and automatic debt recording.

Do not change transaction behaviour as part of this styling task.

## 5.2 Market Desk

The Market Desk should clearly distinguish its major sections and actions.

Improve the visual relationships between:

- Market Desk heading.
- Descriptive text.
- Smart Sync & Merge.
- Active Lists.
- Supplier Management.
- Supplier Debt Payment.
- Customer Requests.
- Purchase History.
- Restocking and repricing controls.

The primary section heading should not visually merge with descriptive text.

Cards should be distinguishable from the surrounding page without using unrelated bright colours.

Use restrained accents to help users identify selected tabs, important list states, and active workflows.

Preserve the existing supplier search, supplier creation, stock purchase, budget, export, restore, and synchronization behaviour.

## 5.3 Supplier Management and Supplier Debt Payment

Differentiate:

- Supplier search controls.
- Supplier summary information.
- Outstanding debts.
- Partially paid purchases.
- Fully settled purchases.
- Payment actions.
- Supplier payment history.

A debt that requires attention should be easy to locate, while a fully settled historical purchase should appear calmer.

Ensure status colours are consistent.

Do not make every outstanding debt flash or pulse. Existing notification rules should remain unchanged.

Keep the single supplier search, clickable debt records, and simplified payment workflow.

## 5.4 Inventory and Stock Adjustment

Make it easy to distinguish the product being edited from the controls used to update it.

Provide appropriate hierarchy for:

- Product identity.
- Available stock.
- Quantity entry.
- Unit cost.
- Total cost.
- Selling price.
- Markup.
- Expiry information.
- Stock thresholds.
- Save and adjustment actions.

Important stock alerts must be visible without making normal products look like warnings.

Preserve existing pack conversion, unit calculations, product editing, restocking, and inventory valuation logic.

## 5.5 Credit Account and Credit History

Use a calm, privacy-conscious hierarchy.

Clearly distinguish:

- Account identity.
- Transaction history.
- Outstanding balance.
- Recorded payments.
- Available actions.
- Settled and unsettled transactions.

Preserve the rule that the aggregate Credit Account outstanding total remains hidden until the user checks the existing visibility checkbox.

Do not reveal confidential Credit Account purchase details through general Sales Desk styling.

Regular Credit History must remain separate from exclusive Credit Accounts and supplier liabilities.

Use clear status treatments for unpaid, partially settled, and settled records.

## 5.6 Financial Desk

The Financial Desk must look precise, trustworthy, and easy to reconcile.

Distinguish:

- Account balances.
- Actual receipts.
- Payments and outflows.
- Internal transfers.
- Expenses.
- Outstanding liabilities.
- Pending owner confirmation.
- Completed transactions.

Do not use the same visual treatment for money received, money paid, and money moved between internal accounts.

However, colour must not replace clear labels or correct accounting classifications.

Bank-to-POS transfers must not visually or functionally appear as new sales or profit.

Preserve Financial Desk security, owner confirmation, PIN protection, and balance calculations.

## 5.7 Reports and Analytics

Use restrained visual emphasis to distinguish:

- Report titles.
- Date ranges.
- Main metrics.
- Supporting figures.
- Filters.
- Table headings.
- Trend indicators.
- Empty states.
- Warnings and anomalies.

Avoid creating excessive colourful cards for every metric.

Charts must remain readable across themes.

Do not change report calculations, data sources, or chart definitions.

## 5.8 Saved Days, Recycle Bin, and Backup

Clearly differentiate the Saved Days / Credit History toggle from the Recycle Bin & Backup section below it.

Selected toggles, active filters, saved-day rows, and expanded records should be identifiable.

Destructive restoration or deletion operations must remain visually distinct from ordinary viewing actions.

Do not make the interface alarming or overuse warning colours.

Preserve all existing backup, restore, Saved Days, Credit History, and historical access rules.

## 5.9 Modals, Menus, and Notifications

Apply consistent styling to:

- Modal headers.
- Modal content.
- Primary and secondary actions.
- Confirmation controls.
- Validation errors.
- Toast messages.
- Menu items.
- Active menu items.
- Notifications.
- Empty states.
- Loading states.

Ensure modals remain clearly separated from their background.

Do not introduce excessive glows, gradients, animations, shadows, or bright status panels.

---

# PART 6 — MODULE COLOURS AND BUSINESS DIVISIONS

Preserve the existing distinction between Pharmacy and Essentials.

The pharmacy division currently uses its established green identity, while Essentials uses its existing purple or burnt-orange distinction.

Keep these identifiers consistent where they already appear, such as product labels, inventory groups, or division indicators.

Do not turn every element within a division into a large coloured panel.

Prefer restrained, consistent identifiers that communicate the division without overwhelming price information, stock controls, and primary actions.

Do not confuse a division's identity colour with universal status meanings.

For example, a product's division colour should not cause a debt warning, successful payment, or destructive action to change meaning.

---

# PART 7 — STATUS COLOURS AND FEEDBACK

Create or refine a consistent semantic system for application feedback.

Use the existing theme palette wherever possible.

### Success

For completed saves, successful payments, valid restorations, and completed operations.

### Warning

For low stock, outstanding supplier debt, incomplete reconciliation, and other conditions requiring attention.

### Error or destructive state

For failed operations, invalid values, destructive actions, and serious validation problems.

### Informational state

For helpful notes, explanations, non-critical notifications, and neutral system information.

### Pending state

For operations awaiting completion, review, authorization, or another required action.

### Disabled state

For unavailable actions, without making labels impossible to read.

Each status must have a consistent visual treatment.

Do not rely on colour alone. Pair colour with an appropriate label, icon, or other clear visual signal.

Avoid using green for unrelated positive-looking decorations when it could create confusion with an actual success state.

---

# PART 8 — BUTTONS, INTERACTION STATES, AND FOCUS

Every interactive control should communicate its current state.

Define consistent appearances for:

- Default.
- Hover.
- Focus.
- Pressed.
- Selected.
- Disabled.
- Loading.
- Success.
- Error.

Use subtle effects consistent with Roseachy's existing design.

Do not add animation merely because an element is interactive.

The active or focused state must be visible without requiring the user to guess whether a button has been selected.

Preserve existing ripple, press feedback, reduced-motion settings, and other supported interaction preferences.

Ensure keyboard focus is visible.

Ensure touch targets remain usable on small screens.

Do not remove accessible focus outlines without providing a better replacement.

---

# PART 9 — CONTRAST AND ACCESSIBILITY

Maintain readable text in all existing themes.

Use WCAG AA as a practical contrast target:

- Normal text: at least 4.5:1 contrast where applicable.
- Large text: at least 3:1 contrast.
- Important interface boundaries, control states, and graphical indicators should retain sufficient contrast to be distinguishable.

Check the actual foreground and background combinations rather than assuming a colour is accessible because it looks bright.

Pay particular attention to:

- Muted text on cards.
- White text on light accent backgrounds.
- Dark text on deep accent colours.
- Placeholder text.
- Selected menu items.
- Disabled buttons.
- Status badges.
- Focus outlines.
- Table rows.
- Hover and pressed states.

Test both light and dark themes.

Do not communicate important financial status using colour alone.

---

# PART 10 — IMPLEMENTATION REQUIREMENTS

## 10.1 Reuse Existing Design Tokens

Prefer existing CSS variables and established styling conventions.

Where useful, organize semantic roles using a small, consistent set of variables, such as:

- `--page-background`
- `--surface-primary`
- `--surface-secondary`
- `--surface-elevated`
- `--border-subtle`
- `--border-strong`
- `--text-primary`
- `--text-secondary`
- `--accent-primary`
- `--accent-soft`
- `--accent-contrast`
- `--status-success`
- `--status-warning`
- `--status-danger`
- `--status-info`
- `--focus-ring`

These are examples, not a requirement to duplicate an existing token system.

Inspect the current implementation first. Extend existing variables rather than introducing a competing design system.

## 10.2 Avoid Fragile CSS

Do not:

- Append endless override rules to the end of the stylesheet.
- Introduce arbitrary negative margins.
- Use fixed positioning to simulate normal layout hierarchy.
- Apply the same strong accent indiscriminately to every card.
- Hard-code different colour meanings in individual components.
- Duplicate theme definitions.
- Introduce unnecessary CSS specificity conflicts.
- Change financial component behaviour to achieve a visual effect.

Prefer reusable component classes, CSS variables, existing Flexbox or Grid layouts, and clearly scoped styling rules.

## 10.3 Preserve State and Behaviour

Colour and styling changes must not cause:

- Forms to reset.
- Data to disappear.
- Buttons to stop working.
- Navigation to break.
- Dropdowns to become inaccessible.
- Tables to stop scrolling.
- Modals to lose their controls.
- Search suggestions to disappear.
- Day transitions to behave differently.
- Credit calculations to change.
- Inventory or financial balances to change.

Do not rewrite working business logic as part of this task.

---

# PART 11 — RESPONSIVE AND THEME VERIFICATION

Test the real application at these viewport widths:

- 320px.
- 375px.
- 390px.
- 425px.
- 768px.
- 1024px.
- 1280px.
- 1440px.

Verify:

- Clear active navigation.
- Distinguishable cards and sections.
- Readable headings and descriptions.
- Consistent button hierarchy.
- Correct contrast.
- Legible financial figures.
- Clearly visible status indicators.
- No clipped text.
- No overlapping controls.
- No unnecessary horizontal page scrolling.
- No theme-specific disappearance of important elements.
- No unintended styling changes to unrelated screens.

Test representative light and dark themes, including Cobalt Studio, Midnight & Ember, and Pearl & Royal Blue.

Where a visual test environment is available, capture screenshots of the same screens before and after the changes.

Review the screenshots for actual visual improvement rather than assuming that CSS changes automatically produce a better design.

---

# PART 12 — FUNCTIONAL REGRESSION TESTING

This task is primarily about visual presentation. Nevertheless, the following regression checks are mandatory.

Verify that:

1. Navigation buttons still open the correct sections.
2. Active tabs update correctly.
3. Primary and secondary buttons still perform their intended actions.
4. Form controls retain their values and validation.
5. Search and filtering remain functional.
6. Supplier debt status remains accurate.
7. Credit Account privacy remains intact.
8. Outstanding balance visibility remains controlled by its checkbox.
9. Sales totals and payment amounts remain correct.
10. Market Desk purchasing and restocking remain functional.
11. Financial Desk balances remain unchanged by visual styling.
12. Saved Days and Credit History still switch correctly.
13. Backup and Restore remain functional.
14. Smart Sync controls retain their established behaviour.
15. Reduced-motion settings remain effective.
16. The existing theme selector continues working.
17. No new JavaScript errors are introduced.
18. No CSS change hides a necessary control at narrow widths.

Inspect the actual application code and use real interaction tests wherever possible.

Do not mark tests as passed merely because the source code appears correct.

Clearly distinguish actual browser tests from source inspection and any tests blocked by the environment.

---

# PART 13 — FINAL QUALITY STANDARD

The result should have:

- A clearer visual hierarchy.
- Stronger section differentiation.
- More intentional accent colours.
- Distinguishable cards and content groups.
- Recognizable primary and secondary actions.
- Consistent active navigation states.
- Consistent status indicators.
- Better visual guidance.
- Readable information in every theme.
- A premium, calm, professional appearance.
- No unnecessary colour clutter.
- No regression in business functionality.

The objective is not to make Roseachy more colourful everywhere.

**The objective is to make the right elements stand out, the related elements look connected, the unrelated elements look distinct, and the next action feel obvious.**

---

# PART 14 — REQUIRED DELIVERABLES

After implementation, provide:

1. Updated Roseachy Desk source code.
2. A working standalone HTML preview using the corrected source.
3. A complete Cloudflare Pages deployment ZIP.
4. A concise implementation summary.
5. Before-and-after screenshots of representative affected screens, where available.
6. A test report covering responsive layouts, theme contrast, interaction states, and regression checks.
7. A clear list of any unresolved issues or tests that could not be performed.

Do not deliver only a mockup or screenshot. Implement the styling changes in the real application.

Preserve existing storage, backups, business records, and application configuration.

Do not declare functionality verified unless it was actually tested.

---

# FINAL EXECUTION INSTRUCTION

Begin by examining the actual Roseachy source code and identifying where its current styling produces insufficient visual differentiation.

Map the existing themes and colour variables.

Define the semantic hierarchy.

Implement the smallest coherent set of changes that makes the application clearer and more intuitive.

Apply the improved system consistently across the relevant screens without forcing all screens to look identical.

Verify the results in real rendered interfaces and retest the affected controls.

**Preserve Roseachy's visual identity while giving its interface clearer direction, stronger hierarchy, and more purposeful use of accent colour.**

The finished application should feel like a refined version of Roseachy, not a different product.