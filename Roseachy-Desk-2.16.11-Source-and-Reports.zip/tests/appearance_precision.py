from visual_support import *
import re
checks=[]
def record(name,detail):
 checks.append({'name':name,'status':'passed','detail':detail});(ROOT/'results/appearance-precision.json').write_text(json.dumps(checks,indent=2));print('PASS',name,flush=True)
controls=[('roundnessLevel','appearanceRoundness'),('borderWeightLevel','appearanceBorder'),('shadowLevel','appearanceShadow')]
with sync_playwright() as p:
 b=launch(p);c=context_for(b,'app');page,errors=open_page(c);page.on('dialog',lambda d:d.accept());seed(page);theme(page,'cobalt','light');screen(page,'settings')
 for key,id in controls:page.locator('#'+id).evaluate("e=>e.closest('details').open=true")
 page.wait_for_timeout(150)
 for key,id in controls:
  el=page.locator('#'+id);assert [el.get_attribute(x) for x in ['min','max','step']]==['0','100','1']
  trace=page.evaluate('''({key,id})=>{const e=document.getElementById(id),r=document.documentElement,rows=[],before=__test.getAppearanceSettings(),preview=document.querySelector('.studioPreview'),savedNode=preview.firstElementChild;for(const v of [...Array(101).keys(),...Array.from({length:101},(_,i)=>100-i)]){e.value=v;e.dispatchEvent(new Event('input',{bubbles:true}));const s=getComputedStyle(r),bs=getComputedStyle(document.querySelector('#previewReplay'));rows.push({v,output:document.querySelector('[data-range-value="'+key+'"]').textContent,stored:__test.getAppearanceSettings()[key],independent:['roundnessLevel','borderWeightLevel','shadowLevel'].filter(k=>k!==key).every(k=>__test.getAppearanceSettings()[k]===before[k]),radius:parseFloat(s.getPropertyValue('--rs-radius-control')),card:parseFloat(s.getPropertyValue('--rs-radius-lg')),border:parseFloat(s.getPropertyValue('--rs-border-width')),shadow:parseFloat(s.getPropertyValue('--rs-shadow-level')),y:parseFloat(s.getPropertyValue('--rs-shadow-y')),blur:parseFloat(s.getPropertyValue('--rs-shadow-blur')),opacity:parseFloat(s.getPropertyValue('--rs-shadow-opacity')),renderedCard:parseFloat(getComputedStyle(preview).borderTopLeftRadius),renderedButton:parseFloat(bs.borderTopLeftRadius),buttonHalf:parseFloat(bs.getPropertyValue('--rs-control-half')),renderedEdge:getComputedStyle(preview).boxShadow,previewNotRebuilt:savedNode===preview.firstElementChild})}return rows}''',{'key':key,'id':id})
  for row in trace:
   v=row['v'];assert row['stored']==v and int(row['output'])==v and row['independent'] and row['previewNotRebuilt'],row
   if key=='roundnessLevel':
    assert abs(row['card']-v*.4)<1e-8 and abs(row['renderedCard']-v*.4)<.02,row
    assert abs(row['renderedButton']-row['buttonHalf']*v/100)<.02,row
   elif key=='borderWeightLevel':
    assert abs(row['border']-v*.03)<1e-8,row
    assert abs(float(re.search(r'([\d.]+)px inset',row['renderedEdge']).group(1))-v*.03)<.001,row
   else:
    assert abs(row['shadow']-v/100)<1e-8 and abs(row['y']-v*.14)<1e-8 and abs(row['blur']-v*.32)<1e-8 and abs(row['opacity']-v*.0018)<1e-8,row
  if key=='shadowLevel':assert len(set(x['renderedEdge'] for x in trace[:101]))==101
  record(key+': 101 increments in both directions, independent, immediate, no preview rebuild',trace)
 for key,id in controls:
  el=page.locator('#'+id);el.focus();page.keyboard.press('Home');page.keyboard.press('ArrowRight');assert el.input_value()=='1';page.keyboard.press('End');assert el.input_value()=='100'
 page.evaluate('()=>RoseachyStore.whenSaved()');page.reload();ready(page);screen(page,'settings')
 for key,id in controls:assert page.locator('#'+id).input_value()=='100'
 record('All three native keyboard endpoints, single steps and refresh persistence',True)
 # Theme switching must not reset either stored intensity or rendered geometry.
 for name in THEMES:
  for mode in ['light','dark']:
   theme(page,name,mode)
   assert page.evaluate("()=>['roundnessLevel','borderWeightLevel','shadowLevel'].every(k=>__test.getAppearanceSettings()[k]===100)")
 record('Every theme and mode preserves all three preferences',True)
 stable=page.evaluate('''()=>{const input=document.querySelector('[data-setting="borderWeightLevel"]'),els=[document.querySelector('.studioPreview'),document.querySelector('.themeCard'),document.querySelector('.themeCard b'),document.querySelector('.settingsGroup')];return [0,1,10,25,50,75,90,99,100].map(v=>{input.value=v;input.dispatchEvent(new Event('input',{bubbles:true}));return {v,rects:els.map(e=>e.getBoundingClientRect().toJSON())}})}''')
 assert all(x['rects']==stable[0]['rects'] for x in stable),stable;record('Border values cause no card, button or text layout shifts',stable)
 migration=page.evaluate("()=>['compact','refined','rounded','soft'].map(shape=>[shape,__test.appearanceSafe({version:15,shape}).roundnessLevel])")
 assert migration==[['compact',25],['refined',40],['rounded',55],['soft',75]],migration
 assert page.evaluate("()=>__test.appearanceSafe({version:16,shape:'soft',roundnessLevel:0,borderWeightLevel:0,shadowLevel:0})")==page.evaluate("()=>__test.appearanceSafe({version:17,shape:'soft',roundnessLevel:0,borderWeightLevel:0,shadowLevel:0})")
 record('Legacy shape preferences migrate and explicit zero values survive',migration)
 # At zero, border ink, elevation and inner lighting are all independently absent.
 page.evaluate("()=>__test.saveAppearanceSettings({...__test.getAppearanceSettings(),roundnessLevel:0,borderWeightLevel:0,shadowLevel:0},true)")
 zero=page.locator('.studioPreview').evaluate("e=>({radius:getComputedStyle(e).borderRadius,shadow:getComputedStyle(e).boxShadow})")
 assert zero['radius']=='0px',zero
 layers=re.findall(r'(?:rgba?\([^)]+\)) ([^,]+)',zero['shadow']);assert all(all(float(v)==0 for v in re.findall(r'(-?[\d.]+)px',layer)) for layer in layers[1:-1]),zero
 assert 'rgba(255, 255, 255, 0)' in zero['shadow'],zero
 record('Zero decorative radius, borders, elevation and inset lighting',zero)
 for key,id in controls:page.locator('#'+id).evaluate("e=>e.closest('details').open=true")
 page.locator('[data-reset-section="shape"]').click();assert page.locator('#appearanceRoundness').input_value()=='80';assert page.locator('#appearanceBorder').input_value()=='30'
 page.locator('[data-reset-section="effects"]').click();assert page.locator('#appearanceShadow').input_value()=='50'
 record('Section resets use the new defaults without affecting business data',True)
 assert not errors,errors;b.close()
