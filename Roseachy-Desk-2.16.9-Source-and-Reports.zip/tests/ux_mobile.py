from common import *
results=[];shots=ROOT/'results/screenshots';shots.mkdir(exist_ok=True)
with sync_playwright() as p:
 b=launch(p)
 try:
  for profile in ['desktop','mobile']:
   c=context_for(b,'app',profile);page,errors=open_page(c);page.on('dialog',lambda d:d.accept());fixture(page,3,0)
   page.evaluate('''()=>{const T=__test,$=id=>document.getElementById(id);T.switchDesk('sales');$('type').value='sale_cash';T.resetTxForm();for(let i=0;i<2;i++){T.chooseProductSuggestion(T.getStock()[i]);$('qty').value=2;T.computeTotal();$('holdBtn').click();}}''')
   for theme in ['cobalt','ember','pearl','cyanflux','coralbank','monomint']:
    for mode in ['light','dark']:
     page.evaluate('v=>__test.saveAppearanceSettings({...__test.getAppearanceSettings(),theme:v.theme,colorMode:v.mode},false)',{'theme':theme,'mode':mode})
     page.locator('#holdList summary').first.click()
     page.locator('#heldItemQty_0').fill('3')
     assert page.evaluate('__test.heldItems[0].qty')==3
     assert not page.locator('#holdList').evaluate('(el)=>el.scrollWidth>el.clientWidth+2')
     page.locator('#holdPanel').screenshot(path=str(shots/f'{profile}-{theme}-{mode}-open-cart.png'),animations='disabled')
     page.locator('#holdList summary').first.click()
   page.locator('#holdCustPaid').fill('500');page.locator('#holdCustReturned').fill('0');page.locator('#addBtn').click();page.wait_for_function('!__test.busy')
   for theme in ['cobalt','ember','pearl','cyanflux','coralbank','monomint']:
    for mode in ['light','dark']:
     page.evaluate('v=>{__test.saveAppearanceSettings({...__test.getAppearanceSettings(),theme:v.theme,colorMode:v.mode},false);__test.CartCorrections.open(__test.tx[0].purchaseGroupId)}',{'theme':theme,'mode':mode})
     page.locator('#cartCorrectionLines summary').first.click()
     page.locator('#cartCorrectionItemQty_0').fill('4')
     assert not page.locator('#cartCorrectionOverlay .marketPanel').evaluate('(el)=>el.scrollWidth>el.clientWidth+2')
     assert page.locator('#cartCorrectionSummary').inner_text().endswith('₦600.00')
     page.locator('#cartCorrectionOverlay .marketPanel').screenshot(path=str(shots/f'{profile}-{theme}-{mode}-item-editor.png'),animations='disabled')
     page.locator('#cartCorrectionClose').click()
   page.evaluate('()=>__test.CartCorrections.open(__test.tx[0].purchaseGroupId)');page.locator('#cartCorrectionLines summary').first.click();page.locator('#cartCorrectionItemQty_0').fill('4');page.locator('#cartCorrectionPaid').fill('600');page.locator('#cartCorrectionSave').click();page.wait_for_function('!__test.busy');assert page.evaluate('__test.tx[0].qty')==4
   results.append({'name':profile+' expanded cart editors fit all 6 themes and both color modes','status':'passed','cases':24})
   page.locator('#tabBtnNotes').click();page.locator('#noteText').fill('Editable note\nSecond line');page.locator('#noteSaveBtn').click();page.wait_for_function('!__test.noteSaving');page.locator('#notesList summary').click();page.locator('#notesList textarea').fill('Revised note\nContent preserved');page.get_by_role('button',name='Save changes',exact=True).click();page.wait_for_function('!__test.noteSaving');assert page.evaluate('__test.getNotes()[0].text')=='Revised note\nContent preserved'
   page.locator('#notesList').screenshot(path=str(shots/f'{profile}-notes.png'),animations='disabled')
   results.append({'name':profile+' note editing works with actual clicks and typing','status':'passed'})
   page.evaluate('''()=>{const T=__test,m=T.getMarketState(),p=T.getStock()[0];m.requests.push({id:'mobile-request',name:p.name,count:1,status:'requested',purchase:{productId:p.id,name:p.name,division:p.division,totalUnits:1,totalCost:60,cost:60,sell:100,priceMode:'manual',markupMode:'custom',markupPercent:0,payment:'purchase_cash',marketPurchaseId:'mobile-market'}});m.requestAmountPaid=null;m.requestAmountPaidExplicit=false;T.setMarketState(m);T.switchDesk('market');T.openMarketReview('requests')}''')
   page.locator('#marketApplyAll').click();assert page.locator('#marketAmountPaid').evaluate('(el)=>document.activeElement===el')
   page.emulate_media(reduced_motion='reduce');assert page.locator('#marketAmountPaid').evaluate('(el)=>getComputedStyle(el).animationName')=='none'
   for value in ['-1','1.001','61']:
    page.locator('#marketAmountPaid').fill(value);assert page.locator('#marketApplyAll').is_disabled(),value
   page.locator('#marketAmountPaid').fill('60');assert not page.locator('#marketApplyAll').is_disabled();assert not page.locator('#marketAmountPaid').evaluate('(el)=>el.classList.contains("paymentPrompt")')
   page.locator('#marketReviewOverlay').screenshot(path=str(shots/f'{profile}-supplier-payment.png'),animations='disabled')
   page.locator('#marketApplyAll').click();page.wait_for_function('!__test.busy');assert page.evaluate('__test.tx.filter(t=>t.marketPurchaseId==="mobile-market").length')==1
   results.append({'name':profile+' supplier input rejects empty, negative, precision and excess; reduced motion respected','status':'passed'})
   assert not errors,errors;c.close()
 except Exception as e:
  results.append({'name':'UI validation','status':'failed','error':str(e)});raise
 finally:
  (ROOT/'results/ux-mobile.json').write_text(json.dumps(results,indent=2));b.close()
print(json.dumps(results,indent=2))
