from common import *
from http.server import ThreadingHTTPServer,SimpleHTTPRequestHandler
from functools import partial
from threading import Thread
class Handler(SimpleHTTPRequestHandler):
 def log_message(self,*args):pass
server=ThreadingHTTPServer(('127.0.0.1',0),partial(Handler,directory=str(APP)));Thread(target=server.serve_forever,daemon=True).start()
try:
 with sync_playwright() as p:
  b=launch(p);c=b.new_context();c.add_init_script("window.__ready=false;addEventListener('roseachy:ready',()=>window.__ready=true)");page=c.new_page();errors=[];page.on('console',lambda m:errors.append(m.text) if m.type=='error' else None);page.on('pageerror',lambda e:errors.append(str(e)))
  page.goto(f'http://127.0.0.1:{server.server_port}',wait_until='networkidle');page.wait_for_function('window.__ready')
  for id in ['tabBtnStock','tabBtnReport','tabBtnNotes','tabBtnAnalytics','tabBtnTx']:page.locator('#'+id).click()
  for desk in ['market','financial','settings']:
   page.locator('#deskMenuBtn').click();page.locator('[data-desk="'+desk+'"]').click()
  for name in ['cobalt','ember','pearl','cyanflux','coralbank','monomint']:page.locator('[data-theme-choice="'+name+'"]').click()
  page.locator('#appearanceRoundness').evaluate("e=>e.closest('details').open=true")
  for id in ['appearanceRoundness','appearanceBorder']:
   page.locator('#'+id).focus();page.keyboard.press('Home');page.keyboard.press('ArrowRight');page.keyboard.press('End')
  page.evaluate('()=>RoseachyStore.whenSaved()');page.reload(wait_until='networkidle');page.wait_for_function('window.__ready');assert not errors,errors
  result={'status':'passed','productionHTTP':True,'testHooksAbsent':page.evaluate('typeof window.__test===\"undefined\"'),'consoleErrors':errors,'serviceWorkerActive':page.evaluate('!!navigator.serviceWorker.controller')};(ROOT/'results/production-console.json').write_text(json.dumps(result,indent=2));b.close();print(result)
finally:server.shutdown();server.server_close()
