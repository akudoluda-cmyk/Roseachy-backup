from visual_support import *
rows=[]
with sync_playwright() as p:
 b=launch(p)
 for target in ['original','app']:
  c=context_for(b,target);page,errors=open_page(c);seed(page);page.set_viewport_size({'width':390,'height':900})
  for name in THEMES:
   for mode in ['light','dark']:
    theme(page,name,mode);screen(page,'sales');page.locator('#txEntryCard').scroll_into_view_if_needed()
    for state in ['rest','hover','focus','typing','selection']:
     el=page.locator('#note');el.fill('')
     if state=='rest':page.mouse.move(0,0);el.evaluate('e=>e.blur()')
     elif state=='hover':el.hover()
     elif state=='focus':el.focus()
     else:el.fill('Product search');el.press('Control+A') if state=='selection' else None
     props=el.evaluate("e=>{const s=getComputedStyle(e);return {border:s.borderStyle,appearance:s.appearance,mask:s.maskImage,transform:s.transform,backgroundImage:s.backgroundImage}}")
     if target=='app':assert props=={'border':'solid','appearance':'none','mask':'none','transform':'none','backgroundImage':'none'},props
     rows.append({'target':target,'theme':name,'mode':mode,'state':state,'style':props})
     if name in ['ember','pearl'] and mode=='light':
      el.screenshot(path=str(ROOT/'results/screenshots'/('after' if target=='app' else 'before')/f'input-{name}-{state}.png'))
    el.fill('');page.locator('.saleTotalField').screenshot(path=str(ROOT/'results/screenshots'/('after' if target=='app' else 'before')/f'total-{name}-{mode}.png'))
    if target=='app':
     assert page.locator('.saleTotalField').evaluate('e=>getComputedStyle(e).backgroundColor')=='rgba(0, 0, 0, 0)'
     assert page.locator('#totalAmount').get_attribute('readonly') is not None
  assert not errors,errors;c.close()
 (ROOT/'results/field-states.json').write_text(json.dumps({'checks':rows,'status':'passed','note':'Actual fields rendered in resting, hover, focus, typing and text-selection states; no gradients/masks/transforms/native appearance remain on the tested fields.'},indent=2));b.close()
