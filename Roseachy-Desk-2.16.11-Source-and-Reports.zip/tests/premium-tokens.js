 // Gradient stops share the selected palette; each is contrast guarded before paint.
 // Opaque stops keep contrast predictable and remove backdrop-dependent legibility.
 const heroText='#ffffff',heroHi=rsContrastGuard(rsMixHex(p.contrast,p.buttons,.18),heroText,7),heroLo=rsMixHex(heroHi,'#000000',.32);
 const btnHi=rsContrastGuard(rsMixHex(p.buttons,'#ffffff',.10),buttonText,5),btnLo=rsContrastGuard(rsMixHex(p.buttons,'#000000',.10),buttonText,5);
 const cardHi=p.card,cardLo=rsMixHex(p.card,p.buttons,isDark?.035:.025),shellHi=rsMixHex(p.shell,p.buttons,isDark?.055:.035);
 roles['--hero-bg']=heroHi;roles['--hero-text']=heroText;
 roles['--hero-paint']=`radial-gradient(ellipse at 100% 0,${heroHi},transparent 72%),linear-gradient(125deg,${heroHi},${heroLo})`;
 roles['--btn-paint']=`linear-gradient(155deg,${btnHi},${p.buttons} 48%,${btnLo})`;
 roles['--surface-paint']=`linear-gradient(145deg,${cardHi},${cardLo})`;
 roles['--page-paint']=`radial-gradient(ellipse at 90% 0,${shellHi},transparent 65%),linear-gradient(155deg,${p.shell},${shellHi})`;
 roles['--rs-shadow-rgb']=rsHex(rsMixHex(p.buttons,'#000000',.66)).join(' ');
 roles['--rs-highlight']=isDark?'255 255 255':'255 255 255';
 Object.entries(roles).forEach(([k,v])=>set(k,v));
