const fs=require('fs'),path=require('path'),crypto=require('crypto'),acorn=require('../tools/node_modules/acorn');
const r=path.resolve(__dirname,'..'),app=path.join(r,'app'),old=fs.readFileSync(path.join(r,'baseline/index.html'),'utf8'),html=fs.readFileSync(path.join(app,'index.html'),'utf8');
let parsed=0;for(const m of html.matchAll(/<script\b[^>]*>([\s\S]*?)<\/script>/gi))if(m[1].trim()){acorn.parse(m[1],{ecmaVersion:'latest'});parsed++;}
for(const f of ['sw.js','js/pwa.js','js/android-sync-files.js']){acorn.parse(fs.readFileSync(path.join(app,f),'utf8'),{ecmaVersion:'latest'});parsed++;}
const originalStyle=s=>[...s.matchAll(/<style\b[^>]*>([\s\S]*?)<\/style>/gi)].map(x=>x[1]);
const isolated=html.replace(/<style id="ux-refinements-2168">[\s\S]*?<\/style>/,'');if(JSON.stringify(originalStyle(old))!==JSON.stringify(originalStyle(isolated)))throw Error('Unrelated style block changed');
if(/window\.__test\s*=|window\.__roseachyDebug\s*=/.test(html))throw Error('Production test hooks');
const result={status:'passed',parsedJavaScriptUnits:parsed,existingStyleBlocksUnchanged:true,newStylesIsolated:true,productionTestHooksAbsent:true,source_sha256:crypto.createHash('sha256').update(html).digest('hex')};
fs.writeFileSync(path.join(r,'results/static.json'),JSON.stringify(result,null,2));console.log(result);
