# ROSEACHY DESK — COMPLETE PREMIUM UI REDESIGN

## PRIMARY OBJECTIVE

Completely redesign the Roseachy Desk user interface to closely replicate the premium visual aesthetics of the uploaded reference image.

The reference image must be treated as the **primary visual design authority** for the entire application.

Recreate its sophisticated gradients, soft dimensional cards, glossy buttons, elegant shadows, rounded corners, layered surfaces, refined typography, ambient lighting, and polished visual hierarchy.

**CRITICAL:** The colors in the reference image are for illustration only. Roseachy Desk must use whichever primary color or theme the user selects in Settings. Do not hardcode burgundy, pink, or any other reference color.

The objective is to achieve the same premium appearance regardless of the selected theme color.

## 1. DYNAMIC COLOR SYSTEM

Use the currently selected primary color in Roseachy Desk's existing Settings as the foundation for the entire interface.

Automatically generate coordinated variations of that color, including:

- Deep and rich shades for featured cards.
- Medium shades for primary actions and highlights.
- Light pastel tints for supporting surfaces.
- Soft tinted backgrounds.
- Harmonious gradients.
- Theme-colored shadows.
- Delicate borders and highlights.
- Hover, focus, pressed, and active states.

Use perceptually consistent color calculations such as OKLCH wherever appropriate.

For example, selecting blue should produce premium blue gradients, subtle pale-blue surfaces, and soft blue shadows. Selecting green, purple, orange, or any custom color should produce the same sophisticated visual effect in that color family.

Do not simply apply one flat color everywhere.

Use intelligent color distribution and automatically maintain accessible text contrast.

Integrate with the existing theme system rather than introducing a separate or conflicting color system.

All visual elements must update consistently when the active theme changes.

## 2. PREMIUM CARD DESIGN

Redesign all dashboard cards, statistical panels, transaction containers, summaries, and content sections to closely match the reference.

Use:

- Generously rounded corners.
- Soft white or lightly tinted surfaces.
- Delicate borders.
- Smooth gradients.
- Subtle ambient shadows.
- Gentle inner highlights.
- Layered visual depth.
- Comfortable internal padding.
- Refined spacing between elements.

Important cards should feature rich gradients derived from the currently selected primary color.

Supporting cards should use neutral or softly tinted backgrounds.

Some cards should visually stand out through their gradient treatment, subtle elevation, and dimensional lighting.

Avoid making every card identical.

Avoid monotonous grids of flat white rectangles.

## 3. DASHBOARD VISUAL HIERARCHY

Redesign the dashboard using the reference image's middle and right screens as the main inspiration.

Make important business statistics visually prominent.

Apply the strongest visual treatment to selected key metrics such as total sales, revenue, or other existing primary business indicators.

Use a balanced combination of:

- Premium gradient-filled featured cards.
- Soft elevated secondary cards.
- Clean transaction containers.
- Elegant statistics panels.
- Refined data tables.
- Well-organized information sections.

Maintain clear hierarchy through card size, background treatment, typography, spacing, and elevation.

Ensure every dashboard component feels part of the same cohesive premium design system.

Do not create fake values or change the underlying business logic.

## 4. BUTTONS & INTERACTIVE CONTROLS

Recreate the reference's glossy, dimensional button styling.

Primary buttons should feature rich theme-colored gradients, soft shadows, subtle highlights, white or appropriately contrasting text, and beautifully rounded shapes.

Secondary buttons should have soft tinted backgrounds and understated borders.

Icon buttons should feel like refined, slightly raised controls.

Introduce subtle interactions:

- Smooth hover elevation.
- Gentle pressed states.
- Soft focus highlights.
- Refined transitions.
- Clear disabled states.

Buttons should look tactile and premium without excessive glowing or exaggerated 3D effects.

## 5. NAVIGATION SYSTEM

Upgrade Roseachy Desk's existing navigation to match the reference's elegant, minimal visual language.

Apply:

- Soft neutral or tinted navigation surfaces.
- Rounded active indicators.
- Theme-colored selection highlights.
- Consistent icon styling.
- Comfortable spacing.
- Subtle hover effects.
- Smooth transitions.
- Carefully controlled shadows.

Maintain the existing navigation structure and functionality.

For mobile layouts, adapt the reference's rounded floating navigation aesthetic where appropriate.

For desktop layouts, retain an efficient desktop navigation arrangement while applying the same premium styling.

## 6. TYPOGRAPHY & SPACING

Use clean, contemporary typography with strong visual hierarchy.

Important monetary figures and dashboard metrics should appear prominent and confident.

Section headings should be clear and well-spaced.

Supporting descriptions should use softer text colors without sacrificing readability.

Correct all cramped layouts.

Ensure text, icons, placeholders, and controls never sit too close to card borders.

Use consistent spacing between headings, labels, inputs, buttons, and content.

Increase internal padding where necessary while avoiding excessive whitespace.

Maintain excellent alignment and readable information density across desktop, tablet, and mobile.

## 7. INPUT FIELDS, SEARCH & FORMS

Apply the same sophisticated styling to every form component.

Redesign:

- Text inputs.
- Search fields.
- Dropdown menus.
- Date selectors.
- Checkboxes.
- Toggles.
- Number inputs.
- Modal forms.
- Transaction entry fields.
- Settings controls.

Use soft rounded corners, delicate tinted borders, subtle inset or ambient shadows, comfortable padding, and theme-colored focus states.

Remove unwanted zigzag patterns, rendering artifacts, inconsistent shadows, unusual background patches, and accidental outlines.

Ensure inputs remain usable and properly aligned at every screen size.

## 8. SHADOWS, LIGHTING & DIMENSIONAL DEPTH

Recreate the reference's beautiful soft dimensional appearance.

Use carefully balanced combinations of:

- Diffused ambient shadows.
- Theme-tinted shadow colors.
- Gentle inner shadows.
- Subtle glossy highlights.
- Smooth surface gradients.
- Soft lighting transitions.
- Slightly raised surfaces.
- Delicate dimensional accents.

Featured cards may have stronger elevation and richer shadows.

Ordinary cards should use gentler shadows.

Avoid harsh dark shadows, excessive glow, overwhelming glassmorphism, or overly exaggerated neumorphism.

The overall effect should be elegant, refined, and professional.

## 9. APPEARANCE SETTINGS — FULLY RESPONSIVE CUSTOMIZATION

Preserve and improve the existing appearance customization settings.

**Corner rounding:** The 0–100 control must produce smooth, continuous, proportional changes to component corner radii. Values must not jump between a small number of fixed presets.

**Border thickness:** The 0–100 control must continuously and predictably adjust border thickness. Each numerical adjustment should produce a corresponding change without sudden jumps.

**Shadow effects:** Apply the same smooth customization behavior to shadow intensity, blur, spread, and other existing shadow parameters. Respect the settings that are already available rather than introducing unnecessary new controls.

All supported appearance controls must remain synchronized with their actual rendered components.

Theme color changes must not reset preferred border, rounding, or shadow settings.

Respect zero values when effects are meant to be disabled.

Ensure extreme settings do not cause clipped content, broken buttons, distorted cards, or layout overflow.

## 10. CONSISTENT DESIGN THROUGHOUT THE APPLICATION

The redesign must extend beyond the main dashboard.

Apply the premium visual system consistently to every existing page and component, including:

- Dashboard.
- Sales and transactions.
- Inventory and stock management.
- Customers and suppliers.
- Debt and payment records.
- Reports and analytics.
- Settings and customization.
- Dialogs and confirmation windows.
- Notifications and alerts.
- Tables, tabs, menus, and overlays.

Preserve clear distinctions between success, warning, error, and informational states. Do not replace every functional status color with the selected primary color.

No page should appear visually disconnected from the rest of the application.

## 11. RESPONSIVENESS & PERFORMANCE

The reference is a mobile design, but Roseachy Desk must maintain a polished experience across desktop, tablet, and mobile.

Translate its aesthetic into the appropriate layout for each device.

Do not simply enlarge the mobile interface on desktop.

Ensure responsive card grids, balanced spacing, readable tables, touch-friendly controls, and properly adapting navigation.

Prevent overflow, overlapping elements, excessive scrolling, distorted gradients, and clipped shadows.

Keep transitions efficient and avoid unnecessary rendering work.

Respect reduced-motion preferences where supported.

## 12. PRESERVE EXISTING FUNCTIONALITY

This is a comprehensive visual redesign, not a rebuild of the application's business logic.

Do not remove or disrupt existing features.

Preserve:

- All business workflows.
- Sales and financial calculations.
- Inventory operations.
- Customer and supplier records.
- Debt management.
- Reporting functionality.
- Stored application data.
- Navigation and event handlers.
- Settings persistence.
- Existing integrations.

Do not introduce decorative elements that interfere with controls, responsiveness, or accessibility.

Reuse existing components and design tokens wherever appropriate.

Refactor duplicated or conflicting styling safely without changing functionality.

## 13. FINAL QUALITY ASSURANCE

Before completion, thoroughly review the redesigned application against the uploaded reference.

Verify that:

1. The visual language closely resembles the reference.
2. Cards have the same premium softness and dimensional depth.
3. Primary buttons have rich gradients and elegant highlights.
4. The interface uses the currently selected theme color rather than hardcoded reference colors.
5. Switching themes updates all relevant gradients, surfaces, borders, highlights, and shadows.
6. Text and icons remain readable across light, dark, and saturated selected colors.
7. Border thickness, corner rounding, and shadow customization respond smoothly across their supported numerical ranges.
8. All application pages share the same visual quality.
9. Layouts remain polished across desktop, tablet, and mobile.
10. All existing business functionality continues to work correctly.

## FINAL DESIGN DIRECTIVE

**Recreate the reference image's visual sophistication as closely as possible, but make the design completely color-adaptive.**

The reference determines the interface's shapes, shadows, gradients, lighting, depth, proportions, component styling, and overall premium aesthetic.

**Roseachy Desk's existing Settings determine the colors.**

Do not deliver a generic colored dashboard with ordinary white cards.

The finished product should feel like the uploaded premium UI concept has been professionally adapted into a complete, functional, responsive business management application, with its full visual identity dynamically transforming to match any selected theme color.