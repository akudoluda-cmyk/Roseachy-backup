// Test-only closure access. Injected by Playwright into HTTP responses, never shipped.
window.__test = {
  renderNotes, ...(typeof addCurrentToCart==='function'?{addCurrentToCart}:{}), get heldItems(){return heldItems}, get noteSaving(){return noteSaving},
  chooseProductSuggestion, refreshTypeUI, refreshProductHint, computeTotal, validateAndBuildTx, resetTxForm, txPricingRule, finalizeHold, buildCreditHistory, renderCreditHistory, anaRecords, anaAggregate, anaTrendData, anaPeriodBounds, finConfirmDay, updateLocks,
  ...(typeof CartCorrections!=="undefined"?{CartCorrections,DailySetup,creditHistoryObligations}:{}), filterCreditHistory, anaRenderProductTrends, runManualDaySave, startNewBusinessDay,
  
  RS, KEY, CreditAccounts, SmartSync, SyncPrivacy, BankReconciliation,
  getStock, setStock, getSaved, setSaved, getNotes, setNotes, getMarketState, setMarketState,
  renderWeekly, recordCalc, txRecordDetailsHtml,
  calc, supplierOpeningFor, currentSupplierOpening, render, renderStock, renderSaved, renderAnalytics, renderMarket, renderLedger,
  setTab, switchDesk, saveDraft, recordObject, normalizeProduct, stockSnapshot,
  inventoryCommit, commitSalesLedger, applyInventoryAdjustment,
  smartProductMatches, smartProductScore, findProductByName, prodLabel,
  normalizeTxIds, getAppearanceSettings, saveAppearanceSettings, appearanceSafe, supportedTheme,
  openMarketReview, supplierPurchaseOutstanding, supplierPurchasePaid, supplierPurchaseClaimed, openSupplierPayment, marketTxEdited, marketTxDeleted, syncSupplierPaymentRecordForTx,
  ...(typeof supplierDebtModel==='function'?{supplierDebtModel,refreshSupplierDebtAlert}:{}),
  getPricingSettings, salePricing, packBreakdown, validateInventoryBackup,
  roseachySafeBackup, restoreFullBackup, validateFullBackup, roseachyVerifyBackupDigest,
  stableBackupText, roundMoney, fmt, validateSystemIntegrity, getTrash,
  finSetup, finUnlock, finLockForDeskExit, finPublic, finStored, finRender, finReviewExpected, finLedger,
  get tx() { return tx; }, get opening() { return openingStock; },
  get busy() { return inventoryBusy; },
  setTx(v) { tx = v; },
  setOpening(v) { openingStock = v; },
  get perf() { return PERF; }
};
