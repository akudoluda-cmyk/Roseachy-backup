# Roseachy Desk 2.16.10

The existing Roseachy Desk application, refined from 2.16.9 with primary-colour financial cards, cleaner typography, consistent spacing, clean field edges and precise live appearance controls. No added runtime dependencies, mockup, replacement architecture or business-data migration.

## Downloads and deployment

- Cloudflare Pages ZIP: complete 13-file static application. Upload using Pages Direct Upload, keeping `index.html`, `sw.js`, `js/` and `icons/` at the deployment root. No build step.
- Standalone HTML preview: actual app with scripts and icons embedded. Download and open it. If local-file storage is restricted by your browser, serve its directory with `python -m http.server 8000`. Use the full ZIP for PWA installation and service-worker caching.
- Visual report HTML: selected actual before/after screenshots, field states and appearance extremes.
- Source-and-reports ZIP: `app/`, unchanged `baseline/` (2.16.9), reproducible transformation/test scripts, detailed JSON evidence and recoverable checkpoints. `original/` mirrors baseline for compatibility tests.

Preview storage belongs to its browser origin; it does not automatically contain data from your deployed app. Synthetic fixture records exist only in tests, never in production output.

## Appearance behavior

Corner Roundness and Border Thickness both support 0–100 in steps of one, with live number outputs, native keyboard/mouse/touch input and saved preferences. Existing named shapes migrate to a matching intensity. Reset Shape resets both precise controls.

Roundness uses proportional component mappings: small 0–16px, medium 0–28px, large cards 0–40px, normal button corners 0–22px, and single-line fields up to half their configured height. Borders use 0–3px fractional inset edges, independent of layout dimensions. At zero, applicable edges disappear while keyboard focus remains visible. CSS values are continuous; physical screen pixels and browser rasterization still have finite precision.

## Reproduction

Python 3 with Playwright and Chromium; Node with Acorn, Acorn Walk and PostCSS. Parser versions are fixed in `tools/package-lock.json`. Install these development tools in `tools/`; no parser or test code ships in the app. The test harness uses `/usr/bin/chromium` and synthetic records.

- `node tests/patch_upgrade.cjs`: apply the audited source transformation to the unchanged baseline.
- `python tests/validate.py`: static checks and the existing business/PWA regression suite.
- `python tests/appearance_precision.py`: every slider value, rendered edges/radii, keyboard, persistence, stable geometry and legacy migration.
- `python tests/responsive_matrix.py`: all themes, modes and eight widths.
- `python tests/extreme_appearance.py`: appearance extremes plus native mouse/touch.
- `python tests/field_states.py`, `python tests/extra_states.py`: field interaction states and additional dialogs.
- `python tests/build_preview.py`, `python tests/preview_check.py`: standalone build and verification.
- `python tests/production_console.py`: uninstrumented production HTTP app, navigation, settings, reload and console errors.

See `reports/VERIFICATION.md` for executed results and limitations. Cloudflare deployment and physical-device/Safari/Firefox testing were not performed.
