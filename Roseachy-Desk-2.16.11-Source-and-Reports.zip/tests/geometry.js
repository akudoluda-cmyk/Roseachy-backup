/* Appearance geometry is independent of palette and persisted through the existing store.
   Inset edges preserve layout; fractional shadows avoid browser border-width snapping. */
function rsApplyGeometry(a,key){
 const root=document.documentElement,s=root.style,set=(k,v)=>s.setProperty(k,v);
 if(!key||key==='roundnessLevel'){
  const q=a.roundnessLevel/100,R=radiusSet(a.roundnessLevel);
  ['sm','md','lg'].forEach((n,i)=>set('--rs-radius-'+n,R[i]+'px'));
  set('--r',R[2]+'px');set('--rs-roundness',q);set('--rs-radius-control',22*q+'px');
 }
 if(!key||key==='borderWeightLevel'){
  set('--rs-border-width',a.borderWeightLevel*.03+'px');set('--rs-border-opacity','1');
  root.classList.remove('rs-border-none','rs-hairline','rs-border-fine','rs-border-standard');
 }
 if(!key||key==='shadowLevel'){
  const q=a.shadowLevel/100;set('--rs-shadow-level',q);
  // Zero-valued layers compose with the independently controlled decorative edge.
  const layer=(y,blur,spread,opacity)=>`0 ${y*q}px ${blur*q}px ${spread*q}px rgb(var(--rs-shadow-rgb,20 25 35) / ${opacity*q})`;
  set('--shadow',layer(14,32,-6,.18)+','+layer(3,9,0,.07));
  set('--shadow-sm',layer(5,14,-2,.12));
  set('--shadow-lg',layer(24,56,-10,.24)+','+layer(5,16,0,.10));
  set('--rs-shadow-y',14*q+'px');set('--rs-shadow-blur',32*q+'px');set('--rs-shadow-opacity',.18*q);
  root.classList.toggle('rs-flat',q===0);root.classList.toggle('rs-soft-elevation',q>0);
 }
}
let rsGeometryObserver;
function rsObserveControlGeometry(){
 if(rsGeometryObserver||!window.ResizeObserver)return;
 // Measure only when component size changes, never during slider input. A control's
 // actual half-height gives a true capsule at 100 even for large text or multiline labels.
 const selector='button,.primaryBtn,input:not([type="checkbox"]):not([type="radio"]):not([type="range"]):not([type="color"]),select,.tabs,.seg,.segChoice,.marketCalcTabs,.previewTabs,.tabInd';
 rsGeometryObserver=new ResizeObserver(entries=>{for(const entry of entries){const target=entry.target,h=entry.borderBoxSize?.[0]?.blockSize||target.offsetHeight;if(h>0)target.style.setProperty('--rs-control-half',h/2+'px')}});
 const visit=(e,observe)=>{if(e.nodeType!==1)return;const els=[...(e.matches(selector)?[e]:[]),...e.querySelectorAll(selector)];for(const el of els)rsGeometryObserver[observe?'observe':'unobserve'](el)};
 visit(document.documentElement,true);
 new MutationObserver(records=>{for(const record of records)for(const node of record.removedNodes)visit(node,false);for(const record of records)for(const node of record.addedNodes)visit(node,true)}).observe(document.body,{childList:true,subtree:true});
}
