from visual_support import *
import traceback
out=[]
with sync_playwright() as p:
 b=launch(p);c=context_for(b,'app');page,errors=open_page(c);page.on('dialog',lambda d:d.accept());seed(page)
 for width in [390,1280]:
  page.set_viewport_size({'width':width,'height':900})
  for name in ['cobalt','ember','pearl']:
   for mode in ['light','dark']:
    theme(page,name,mode)
    for view in ['sales','stock','market','financial','reports']:
     screen(page,view);metrics=page.evaluate(MEASURE);out.append({'width':width,'theme':name,'mode':mode,'view':view,**metrics})
     page.screenshot(path=str(ROOT/'results/screenshots/after'/f'{width}-{name}-{mode}-{view}.png'),animations='disabled')
    print('AUDIT',width,name,mode,flush=True)
 (ROOT/'results/after-visual.json').write_text(json.dumps({'screens':out,'browserErrors':errors},indent=2));b.close()
 print('Screens:',len(out),'text measurements:',sum(x['tested'] for x in out),'below target:',sum(len(x['failures']) for x in out))
 if errors:raise SystemExit(errors)
