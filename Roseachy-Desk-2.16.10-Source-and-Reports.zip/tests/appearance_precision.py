from visual_support import *
import re
checks=[]
def record(name,detail):
 checks.append({'name':name,'status':'passed','detail':detail});(ROOT/'results/appearance-precision.json').write_text(json.dumps(checks,indent=2));print('PASS',name,flush=True)
with sync_playwright() as p:
 b=launch(p);c=context_for(b,'app');page,errors=open_page(c);page.on('dialog',lambda d:d.accept());seed(page);theme(page,'cobalt','light')
 screen(page,'settings');page.locator('#appearanceRoundness').evaluate("e=>e.closest('details').open=true")
 for key,id in [('roundnessLevel','appearanceRoundness'),('borderWeightLevel','appearanceBorder')]:
  el=page.locator('#'+id);assert [el.get_attribute(x) for x in ['min','max','step']]==['0','100','1']
  trace=page.evaluate('''({key,id})=>{const e=document.getElementById(id),r=document.documentElement,rows=[];for(const v of [...Array(101).keys(),...Array.from({length:101},(_,i)=>100-i)]){e.value=v;e.dispatchEvent(new Event('input',{bubbles:true}));const s=getComputedStyle(r);rows.push({v,output:document.querySelector('[data-range-value="'+key+'"]').textContent,stored:__test.getAppearanceSettings()[key],radius:parseFloat(s.getPropertyValue('--rs-radius-control')),card:parseFloat(s.getPropertyValue('--rs-radius-lg')),border:parseFloat(s.getPropertyValue('--rs-border-width')),renderedCard:parseFloat(getComputedStyle(document.querySelector('.studioPreview')).borderTopLeftRadius),renderedButton:parseFloat(getComputedStyle(document.querySelector('#restoreAppearanceDefaults')).borderTopLeftRadius),renderedEdge:getComputedStyle(document.querySelector('.studioPreview')).boxShadow})}return rows}''',{'key':key,'id':id})
  for row in trace:
   assert row['stored']==row['v'] and int(row['output'])==row['v'],row
   if key=='roundnessLevel':assert abs(row['radius']-row['v']*.22)<1e-8 and abs(row['card']-row['v']*.4)<1e-8,row
   if key=='roundnessLevel':assert abs(row['renderedCard']-row['v']*.4)<.02 and abs(row['renderedButton']-row['v']*.22)<.02,row
   else:
    assert abs(row['border']-row['v']*.03)<1e-8,row
    assert abs(float(re.search(r'([\d.]+)px inset',row['renderedEdge']).group(1))-row['v']*.03)<1e-8,row
  record(key+' all 101 ascending and descending positions map without dead zones',trace)
 # Native keyboard and pointer/touch handling, with persistence through reload.
 el=page.locator('#appearanceRoundness');el.focus();page.keyboard.press('Home');page.keyboard.press('ArrowRight');assert el.input_value()=='1';page.keyboard.press('End');assert el.input_value()=='100'
 el=page.locator('#appearanceBorder');el.focus();page.keyboard.press('Home');page.keyboard.press('ArrowRight');assert el.input_value()=='1';page.keyboard.press('End');assert el.input_value()=='100'
 page.evaluate('()=>RoseachyStore.whenSaved()');page.reload();ready(page);screen(page,'settings');assert page.locator('#appearanceRoundness').input_value()=='100' and page.locator('#appearanceBorder').input_value()=='100'
 record('Native keyboard endpoints, single steps and refresh persistence',True)
 # Border width must not move text or resize fields/cards, including max intensity.
 stable=page.evaluate('''()=>{const input=document.querySelector('[data-setting="borderWeightLevel"]'),els=[document.querySelector('.studioPreview'),document.querySelector('.themeCard'),document.querySelector('.themeCard b'),document.querySelector('.settingsGroup')];return [0,1,25,50,75,100].map(v=>{input.value=v;input.dispatchEvent(new Event('input',{bubbles:true}));return {v,rects:els.map(e=>e.getBoundingClientRect().toJSON()),shadow:getComputedStyle(els[0]).boxShadow}})}''')
 assert all(x['rects']==stable[0]['rects'] for x in stable),stable
 assert stable[0]['shadow']!=stable[-1]['shadow']
 record('Inset border changes leave card, button and text dimensions stable',stable)
 # Migration preserves old named appearance preferences without adding presets to the new slider.
 migration=page.evaluate("()=>['compact','refined','rounded','soft'].map(shape=>[shape,__test.appearanceSafe({version:15,shape}).roundnessLevel])")
 assert migration==[['compact',25],['refined',40],['rounded',55],['soft',75]],migration
 assert page.evaluate("()=>__test.appearanceSafe({version:16,shape:'soft',roundnessLevel:0}).roundnessLevel")==0
 record('Previous settings migrate; explicit zero survives normalization',migration)
 page.locator('#appearanceRoundness').evaluate("e=>e.closest('details').open=true");page.locator('[data-reset-section="shape"]').click();assert page.locator('#appearanceRoundness').input_value()=='55';assert page.locator('#appearanceBorder').input_value()=='30';record('Reset Shape restores both precise defaults',True)
 assert not errors,errors;b.close()
