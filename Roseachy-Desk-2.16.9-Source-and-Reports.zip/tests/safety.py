from common import *
import traceback
out=ROOT/'results/safety.json';results=[]
def run(name,code):
 try:
  page.wait_for_function('!__test.busy');detail=page.evaluate('async()=>{const T=__test,$=id=>document.getElementById(id);const assert=(x,m)=>{if(!x)throw Error(m)};'+code+'}');results.append({'name':name,'status':'passed','detail':detail});print('PASS',name,flush=True)
 except Exception as e:results.append({'name':name,'status':'failed','error':str(e)});print('FAIL',name,str(e)[:700],flush=True)
 out.write_text(json.dumps(results,indent=2))
with sync_playwright() as p:
 b=launch(p);c=context_for(b,'app');page,errors=open_page(c);page.on('dialog',lambda d:d.accept());fixture(page,4,0)
 page.on('download',lambda d:d.save_as(str(ROOT/'results'/d.suggested_filename)))
 run('Duplicate display names select stable product IDs and capture independent prices', '''
 const products=T.getStock();products[0].name=products[1].name='Same product';products[0].division=products[1].division='essentials';products[0].price=125;products[1].price=280;T.setStock(products);T.setOpening(T.stockSnapshot());
 $('type').value='sale_cash';T.chooseProductSuggestion(products[1]);$('qty').value=2;T.computeTotal();let item=T.validateAndBuildTx().obj;assert(item.productId===products[1].id&&item.unitPrice===280&&item.amount===560,'explicit ID');T.chooseProductSuggestion(products[0]);T.computeTotal();item=T.validateAndBuildTx().obj;assert(item.productId===products[0].id&&item.amount===250,'second ID');T.resetTxForm();return true;
 ''')
 run('Create two carts and standalone sale; save whole day', '''
 const base=(id,p,q,g)=>({id,type:'sale_transfer',domain:'retail',refKind:'product',productId:'fixture-product-'+p,productName:T.getStock()[p].name,note:T.getStock()[p].name,amount:q*T.getStock()[p].price,unitPrice:T.getStock()[p].price,unitSellingPrice:T.getStock()[p].price,qty:q,costSnapshot:60,division:'essentials',ts:new Date().toISOString(),...(g?{purchaseGroupId:g}:{})});
 const a=base('a0',0,2,'a'),a2=base('a1',1,1,'a'),other=base('b0',2,1,'b'),single=base('single',3,1);a2.basketTotal=a.amount+a2.amount;a2.customerPaid=a2.basketTotal+100;a2.changeReturned=50;a2.changeOwed=50;a2.paymentReconciliationV2=true;
 assert(await T.inventoryCommit(()=>{const e=T.commitSalesLedger([a,a2,other,single]);if(e)throw Error(e);return true},'Sales Desk'),'seed');await T.runManualDaySave();window.untouched=JSON.stringify(T.tx.slice(2));window.beforeStock=JSON.stringify(T.getStock());return true;
 ''')
 run('Injected draft write failure rolls back cart, saved copies, bank claim and audit', '''
 const before=JSON.stringify({tx:T.tx,saved:T.getSaved(),stock:T.getStock(),backup:localStorage.getItem('roseachy_bank_claim_provenance_v3')});
 T.CartCorrections.open('a');$('cartCorrectionType').value='sale_cash';window.originalPut=IDBObjectStore.prototype.put;IDBObjectStore.prototype.put=function(...args){if(this.name==='draft')throw new DOMException('Synthetic cart failure','QuotaExceededError');return originalPut.apply(this,args)};
 try{await T.CartCorrections.save();}finally{IDBObjectStore.prototype.put=originalPut;}
 assert(JSON.stringify({tx:T.tx,saved:T.getSaved(),stock:T.getStock(),backup:localStorage.getItem('roseachy_bank_claim_provenance_v3')})===before,'rollback');assert($('cartCorrectionType').value==='sale_cash','input retained');assert(!$('cartCorrectionOverlay').classList.contains('hidden'),'editor retained');return true;
 ''')
 run('Retry atomically updates saved-day payment while unrelated carts remain byte-identical', '''
 await T.CartCorrections.save();assert(T.tx.slice(0,2).every(t=>t.type==='sale_cash'),'corrected');assert(JSON.stringify(T.tx.slice(2))===untouched,'unrelated');assert(JSON.stringify(T.getStock())===beforeStock,'stock');assert(T.getSaved()[0].tx.slice(0,2).every(t=>t.type==='sale_cash'),'saved copy');assert(T.tx[0].creditEditHistory.length===1,'one audit after retry');return true;
 ''')
 run('Historical product price stays captured after current configured price change', '''
 const stock=T.getStock();stock[0].price=900;T.setStock(stock);T.render();document.querySelector('[data-edit="0"]').click();for(let i=0;i<100&&T.busy;i++)await new Promise(r=>setTimeout(r,10));assert(!$('cartCorrectionOverlay').classList.contains('hidden'),'item launches whole cart');assert($('cartCorrectionLines').textContent.includes('250'),'original line total');assert(T.tx[0].unitSellingPrice===125,'history price');$('cartCorrectionClose').click();return true;
 ''')
 run('Saved setup rejects corrections that would rewrite archived opening totals', '''
 T.finConfirmDay();await T.RS.whenSaved();T.switchDesk('settings');T.DailySetup.open();$('setupEdit_openingCash').value=999;const before=JSON.stringify(T.getSaved());await T.DailySetup.save();assert($('setupCorrectionError').textContent.includes('saved financial record'),'reason');assert(JSON.stringify(T.getSaved())===before&&Number($('openingCash').value)===100000,'history intact');$('setupCorrectionClose').click();T.switchDesk('sales');return true;
 ''')
 run('Backup restores cart correction, quantities, audit and setup lock', '''
 window.snapshot=await T.roseachySafeBackup();const before=JSON.stringify({tx:T.tx,stock:T.getStock(),debts:T.creditHistoryObligations().map(d=>[d.id,d.balance])});assert(await T.restoreFullBackup(snapshot,{confirmRestore:false}),'restored');assert(JSON.stringify({tx:T.tx,stock:T.getStock(),debts:T.creditHistoryObligations().map(d=>[d.id,d.balance])})===before,'data');assert($('openingCash').disabled,'lock restored');assert((await T.RS.verify()).ok,'db');return true;
 ''')
 run('New day transition preserves old confirmed setup and allows new confirmation', '''
 const oldDate=$('date').value;T.resetTxForm();await T.startNewBusinessDay();assert($('date').value>oldDate,'date advances');assert(T.tx.length===0,'empty new day');assert(!T.DailySetup.confirmed()&&!$('openingCash').disabled,'new day editable');assert(T.getSaved().some(d=>d.date===oldDate&&d.tx.length===4),'closed transactions preserved');return true;
 ''')
 page.reload();ready(page)
 run('Reload verifies durable data and no stale correction session', '''assert((await T.RS.verify()).ok,'db');assert(T.tx.length===0,'new day persisted');return true;''')
 print('Browser errors:',errors);b.close()
 if any(r['status']!='passed' for r in results) or errors:raise SystemExit(1)
