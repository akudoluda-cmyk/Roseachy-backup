const fs=require('fs'),path=require('path'),crypto=require('crypto'),acorn=require('../tools/node_modules/acorn'),walk=require('../tools/node_modules/acorn-walk'),postcss=require('../tools/node_modules/postcss');
const r=path.resolve(__dirname,'..'),app=path.join(r,'app'),old=fs.readFileSync(path.join(r,'baseline/index.html'),'utf8'),html=fs.readFileSync(path.join(app,'index.html'),'utf8');
let parsed=0,css=0;
const functions=s=>{const out=[];for(const m of s.matchAll(/<script\b[^>]*>([\s\S]*?)<\/script>/gi)){if(!m[1].trim())continue;const ast=acorn.parse(m[1],{ecmaVersion:'latest'});walk.simple(ast,{FunctionDeclaration(n){out.push({name:n.id.name,source:m[1].slice(n.start,n.end)})}});}return out;};
const normalize=s=>s.replace(/style\.textContent=(?:'(?:[^'\\]|\\.)*'|"(?:[^"\\]|\\.)*"|`[^`]*`)/g,'style.textContent=/* audited component CSS */');
const before=functions(old),after=functions(html),allowed=['rsApplyAuditContrast','showToast','finRowHtml','renderSupplierDebtBoard','renderMarketHistory'];
if(before.length!==after.length)throw Error('Unexpected function count change');let identical=0;for(let i=0;i<before.length;i++){if(before[i].name!==after[i].name)throw Error('Function ordering changed');if(!allowed.includes(before[i].name)){if(normalize(before[i].source)!==normalize(after[i].source))throw Error('Unexpected non-presentation change: '+before[i].name);identical++;}}
for(const m of html.matchAll(/<script\b[^>]*>([\s\S]*?)<\/script>/gi))if(m[1].trim()){acorn.parse(m[1],{ecmaVersion:'latest'});parsed++;}
for(const f of ['sw.js','js/pwa.js','js/android-sync-files.js']){acorn.parse(fs.readFileSync(path.join(app,f),'utf8'),{ecmaVersion:'latest'});parsed++;}
for(const m of html.matchAll(/<style\b[^>]*>([\s\S]*?)<\/style>/gi)){postcss.parse(m[1]);css++;}
if(/window\.__test\s*=|window\.__roseachyDebug\s*=/.test(html))throw Error('Production test hooks');
const result={status:'passed',parsedJavaScriptUnits:parsed,parsedStyleBlocks:css,unchangedFunctions:identical,allowedPresentationFunctions:allowed,productionTestHooksAbsent:true,source_sha256:crypto.createHash('sha256').update(html).digest('hex')};fs.writeFileSync(path.join(r,'results/static.json'),JSON.stringify(result,null,2));console.log(result);
