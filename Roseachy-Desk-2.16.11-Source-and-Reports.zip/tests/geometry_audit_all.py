from visual_support import *
SEL='.card,.marketSection,.settingsGroup,.marketPanel,.finBalanceCard,.metric,.themeCard,.productSuggestDrop,.tabs,.tabBtn,.segChoice,button,input:not([type=checkbox]):not([type=radio]):not([type=range]):not([type=color]):not([type=hidden]),select,textarea'
with sync_playwright() as p:
 b=launch(p);c=context_for(b,'app');page,errors=open_page(c);page.on('dialog',lambda d:d.accept());seed(page);theme(page,'cobalt','light')
 page.evaluate('''()=>{for(const key of ['roundnessLevel','borderWeightLevel']){const e=document.querySelector('[data-setting="'+key+'"]');e.value=0;e.dispatchEvent(new Event('input',{bubbles:true}))}}''')
 out=[]
 SEL='div,section,details,summary,button,input,select,textarea'
 for view in ['sales','stock','market','suppliers','financial','reports','settings','analytics']:
  screen(page,view)
  a=page.evaluate('''sel=>[...document.querySelectorAll(sel)].filter(e=>e.checkVisibility({checkVisibilityCSS:true,checkOpacity:true})&&e.getBoundingClientRect().width&&!e.closest('.hidden')).map(e=>({id:e.id,cls:e.className,radius:getComputedStyle(e).borderTopLeftRadius,border:getComputedStyle(e).borderWidth,style:e.getAttribute('style'),text:e.textContent.slice(0,50)})).filter(x=>parseFloat(x.radius)>0)''',SEL)
  out.append({'view':view,'nonzero':a})
 print(json.dumps(out,indent=2));(ROOT/'results/geometry-audit-all.json').write_text(json.dumps(out,indent=2));b.close()
