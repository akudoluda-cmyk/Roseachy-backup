from visual_support import *
with sync_playwright() as p:
 b=launch(p);c=context_for(b,'app');page,errors=open_page(c);page.on('dialog',lambda d:d.accept());seed(page);theme(page,'cobalt','light');page.set_viewport_size({'width':390,'height':900});screen(page,'financial')
 for v in [0,25,50,75,100]:
  page.evaluate('''v=>{for(const k of ['roundnessLevel','borderWeightLevel','shadowLevel']){const e=document.querySelector('[data-setting="'+k+'"]');e.value=v;e.dispatchEvent(new Event('input',{bubbles:true}))}document.getElementById('toast').classList.remove('show')}''',v)
  page.screenshot(path=str(ROOT/'results/screenshots/after'/f'appearance-stop-{v}.png'),animations='disabled')
 screen(page,'settings');panel=page.locator('.settingsGroup').filter(has=page.locator('#appearanceRoundness'));panel.evaluate('e=>e.open=true');panel.screenshot(path=str(ROOT/'results/screenshots/after/precise-settings.png'),animations='disabled');panel=page.locator('.settingsGroup').filter(has=page.locator('#appearanceShadow'));panel.evaluate('e=>e.open=true');panel.screenshot(path=str(ROOT/'results/screenshots/after/precise-shadows.png'),animations='disabled');assert not errors,errors;b.close()
