from common import *
checks=[]
with sync_playwright() as p:
 b=launch(p)
 for width in [320,1280,1440]:
  c=context_for(b,'app',hooks=False);page,errors=open_page(c);page.set_viewport_size({'width':width,'height':720})
  for id in ['tabBtnStock','tabBtnReport','tabBtnNotes','tabBtnAnalytics','tabBtnTx']:page.locator('#'+id).click()
  for desk in ['market','financial','settings']:
   page.locator('#deskMenuBtn').click();page.locator('[data-desk="'+desk+'"]').click()
  for name in ['cobalt','ember','pearl','cyanflux','coralbank','monomint']:
   page.locator('[data-theme-choice="'+name+'"]').click(timeout=15000);assert page.locator('body').get_attribute('data-theme')==name
  for id in ['appearanceRoundness','appearanceBorder','appearanceShadow']:
   e=page.locator('#'+id);e.evaluate("e=>e.closest('details').open=true");e.focus();page.keyboard.press('End');assert e.input_value()=='100'
  assert not errors,errors;checks.append({'width':width,'nativeThemeClicks':6,'nativeKeyboardSliders':3,'normalMotion':True,'testHooksAbsent':page.evaluate("typeof __test==='undefined'"),'status':'passed'});c.close();print('PASS normal-motion navigation',width,flush=True)
 b.close();(ROOT/'results/settings-navigation.json').write_text(json.dumps(checks,indent=2))
