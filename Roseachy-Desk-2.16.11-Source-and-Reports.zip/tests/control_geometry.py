from visual_support import *
checks=[]
with sync_playwright() as p:
 b=launch(p);c=context_for(b,'app')
 c.add_init_script('''(()=>{const Original=ResizeObserver;window.__controlObserverLog=[];window.ResizeObserver=class extends Original{observe(e,o){if(e.id==='precision-dynamic')__controlObserverLog.push('observe');return super.observe(e,o)}unobserve(e){if(e.id==='precision-dynamic')__controlObserverLog.push('unobserve');return super.unobserve(e)}}})()''')
 page,errors=open_page(c);page.on('dialog',lambda d:d.accept());seed(page)
 for width in [320,390,768,1440]:
  page.set_viewport_size({'width':width,'height':900})
  for density in ['compact','balanced','comfortable']:
   page.evaluate("density=>__test.saveAppearanceSettings({...__test.getAppearanceSettings(),roundnessLevel:100,density,fontScale:'large',animation:'off'},true)",density);screen(page,'sales');page.wait_for_timeout(120)
   rows=page.evaluate('''()=>[...document.querySelectorAll('button,input:not([type=range]):not([type=checkbox]):not([type=radio]):not([type=hidden]),select')].filter(e=>e.checkVisibility()&&e.offsetHeight&&!e.closest('.hidden')&&!e.matches('.collapseHead,.themeCard')).map(e=>({id:e.id,cls:e.className,inline:e.getAttribute("style"),height:e.getBoundingClientRect().height,radius:parseFloat(getComputedStyle(e).borderTopLeftRadius)}))''')
   assert all(abs(x['height']/2-x['radius'])<.03 for x in rows),[x for x in rows if abs(x['height']/2-x['radius'])>=.03]
   checks.append({'width':width,'density':density,'largeText':True,'pillControls':len(rows),'status':'passed'})
 page.evaluate("()=>{const e=document.createElement('button');e.id='precision-dynamic';e.textContent='Large multiline control to verify proportional corners';e.style.cssText='width:150px;padding:16px;font-size:22px';document.querySelector('#txEntryCard').append(e)}")
 page.wait_for_timeout(150)
 v=page.locator('#precision-dynamic').evaluate('e=>({radius:parseFloat(getComputedStyle(e).borderTopLeftRadius),height:e.getBoundingClientRect().height})');assert abs(v['radius']-v['height']/2)<.03,v
 page.locator('#precision-dynamic').evaluate('e=>e.remove()');page.wait_for_timeout(100)
 assert page.evaluate('__controlObserverLog')==['observe','unobserve']
 (ROOT/'results/control-geometry.json').write_text(json.dumps({'checks':checks,'dynamicMultilinePill':v,'removedControlsUnobserved':True,'browserErrors':errors},indent=2));assert not errors,errors;b.close();print('PASS',len(checks),'viewport/density combinations; dynamic multiline pill; observer cleanup')
