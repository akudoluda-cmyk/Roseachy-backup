from pathlib import Path
import base64,re
r=Path(__file__).resolve().parents[1];app=r/'app';s=(app/'index.html').read_text()
s=s.replace('<link rel="manifest" href="/manifest.json">','<script>window.RoseachyPortablePreview=true;</script>')
for m in list(re.finditer(r'<script src="([^"]+)"[^>]*></script>',s)):
 content=(app/m[1].lstrip('./')).read_text();assert '</script' not in content.lower();s=s.replace(m[0],'<script>\n'+content+'\n</script>')
for m in list(re.finditer(r'href="((?:\./|/)?icons/[^"]+)"',s)):
 data=base64.b64encode((app/m[1].lstrip('./')).read_bytes()).decode();s=s.replace(m[0],'href="data:image/png;base64,'+data+'"')
assert not re.search(r'<script[^>]+src=',s)
p=r/'deliverables/Roseachy-Desk-2.16.11-Preview.html';p.write_text(s);print(p,p.stat().st_size)
