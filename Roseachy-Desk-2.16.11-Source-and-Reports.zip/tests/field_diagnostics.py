from visual_support import *
with sync_playwright() as p:
 b=launch(p);c=context_for(b,'app');page,err=open_page(c);seed(page);theme(page,'ember','light');page.set_viewport_size({'width':390,'height':900})
 page.evaluate("()=>{for(const key of ['roundnessLevel','borderWeightLevel']){const e=document.querySelector('[data-setting='+key+']');e.value=100;e.dispatchEvent(new Event('input',{bubbles:true}))}}")
 page.locator('#qty').scroll_into_view_if_needed();print(page.locator('#qty').evaluate("e=>{const s=getComputedStyle(e);return Object.fromEntries(['borderStyle','borderWidth','borderColor','borderRadius','outline','boxShadow','background','backgroundClip','backgroundImage','filter','transform','maskImage','appearance'].map(k=>[k,s[k]]))}"))
 page.locator('#qty').screenshot(path=str(ROOT/'results/screenshots/after/field-diagnostic.png'),scale='css');b.close()
