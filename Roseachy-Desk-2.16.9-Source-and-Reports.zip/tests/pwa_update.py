from common import *
from http.server import ThreadingHTTPServer,SimpleHTTPRequestHandler
from functools import partial
from threading import Thread
from zipfile import ZipFile
from PIL import Image,ImageChops
import tempfile,shutil,traceback
result={'checks':[]};out=ROOT/'results/pwa-update.json';shots=ROOT/'results/screenshots';shots.mkdir(exist_ok=True)
def record(name,detail=True):
 result['checks'].append({'name':name,'status':'passed','detail':detail});out.write_text(json.dumps(result,indent=2));print('PASS',name,flush=True)
class Handler(SimpleHTTPRequestHandler):
 def log_message(self,*args):pass
 def end_headers(self):self.send_header('Cache-Control','no-store');super().end_headers()
with sync_playwright() as p:
 b=launch(p)
 try:
  with tempfile.TemporaryDirectory(prefix='pwa-update-',dir=ROOT) as tmp:
   temp=Path(tmp);shutil.copytree(ROOT/'original',temp,dirs_exist_ok=True)
   server=ThreadingHTTPServer(('127.0.0.1',0),partial(Handler,directory=str(temp)));Thread(target=server.serve_forever,daemon=True).start()
   try:
    c=b.new_context();c.add_init_script("window.__ready=false;window.addEventListener('roseachy:ready',()=>window.__ready=true)")
    page=c.new_page();errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
    origin=f'http://127.0.0.1:{server.server_port}'
    page.goto(origin,wait_until='networkidle');page.wait_for_function('__ready')
    page.locator('#tabBtnNotes').click();page.locator('#noteText').fill('PWA update must preserve this synthetic note');page.locator('#noteSaveBtn').click()
    page.evaluate('async()=>{await RoseachyStore.whenSaved();await navigator.serviceWorker.ready;}');page.wait_for_function('navigator.serviceWorker.controller')
    c.set_offline(True);page.reload(wait_until='load');page.wait_for_function('__ready');page.locator('#tabBtnNotes').click()
    assert 'PWA update must preserve' in page.locator('#notesList').inner_text()
    c.set_offline(False)
    for src in (ROOT/'original').rglob('*'):
     if src.is_file():shutil.copyfile(APP/src.relative_to(ROOT/'original'),temp/src.relative_to(ROOT/'original'))
    page.evaluate('async()=>{const r=await navigator.serviceWorker.getRegistration();await r.update();}')
    page.wait_for_function('async()=>!!(await navigator.serviceWorker.getRegistration())?.waiting')
    assert 'PWA update must preserve' in page.locator('#notesList').inner_text()
    page.locator('#updateBar').get_by_role('button',name='Update now').click()
    page.wait_for_function("document.querySelector('meta[name=roseachy-version]').content.includes('2.16.9') && window.__ready")
    page.locator('#tabBtnNotes').click();assert 'PWA update must preserve' in page.locator('#notesList').inner_text()
    c.set_offline(True);page.reload(wait_until='load');page.wait_for_function('__ready');page.locator('#tabBtnNotes').click()
    assert 'PWA update must preserve' in page.locator('#notesList').inner_text()
    caches=page.evaluate('()=>caches.keys()');assert len([x for x in caches if x.startswith('roseachy-')])==1,caches
    assert (page.evaluate('()=>RoseachyStore.verify()'))['ok'];assert not errors,errors
    record('Original-to-optimized service worker update, old-cache removal, and offline note persistence',{'caches':caches})
    c.close()
   finally:server.shutdown();server.server_close()
  result['status']='passed'
 except Exception as e:result['status']='failed';result['error']=str(e);traceback.print_exc()
 finally:out.write_text(json.dumps(result,indent=2));b.close()
raise SystemExit(0 if result.get('status')=='passed' else 1)
