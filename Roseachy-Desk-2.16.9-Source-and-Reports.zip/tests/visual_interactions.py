from visual_support import *
checks=[]
def record(name,detail=True):
 checks.append({'name':name,'status':'passed','detail':detail});print('PASS',name,flush=True);(ROOT/'results/visual-interactions.json').write_text(json.dumps(checks,indent=2))
with sync_playwright() as p:
 b=launch(p);c=context_for(b,'app');page,errors=open_page(c);page.on('dialog',lambda d:d.accept());seed(page)
 page.evaluate('''()=>{const T=__test,$=id=>document.getElementById(id);T.switchDesk('sales');$('type').value='sale_cash';T.resetTxForm();T.chooseProductSuggestion(T.getStock()[0]);$('qty').value=2;T.computeTotal()}''')
 initial=page.evaluate('()=>JSON.stringify({tx:__test.tx,stock:__test.getStock(),market:__test.getMarketState()})')
 for n in THEMES:
  for m in ['light','dark']:
   theme(page,n,m)
   state=page.evaluate('''()=>{const c=e=>getComputedStyle(document.getElementById(e)).backgroundColor;return {hold:c('holdBtn'),add:c('addBtn'),primary:getComputedStyle(document.documentElement).getPropertyValue('--btn-bg').trim(),note:document.getElementById('note').value}}''')
   assert state['hold']!=state['add'],state
   assert state['note']=='Paracetamol 500mg',state
 assert initial==page.evaluate('()=>JSON.stringify({tx:__test.tx,stock:__test.getStock(),market:__test.getMarketState()})')
 record('All twelve theme/mode combinations preserve entered product and financial/inventory state; Add to Cart has primary treatment')
 page.locator('#holdBtn').click();page.wait_for_timeout(100)
 state=page.evaluate("()=>['holdBtn','addBtn'].map(id=>getComputedStyle(document.getElementById(id)).backgroundColor)");assert state[0]!=state[1],state
 record('Open cart gives Complete Sale primary treatment and Add to Cart secondary treatment')
 for width in [320,1440]:
  page.set_viewport_size({'width':width,'height':900})
  for n in THEMES:
   for m in ['light','dark']:
    theme(page,n,m);page.locator('#holdList summary').first.click()
    metrics=page.evaluate(MEASURE);assert not metrics['failures'],(n,m,metrics['failures'])
    page.locator('#holdPanel').screenshot(path=str(ROOT/'results/screenshots/after'/f'cart-{width}-{n}-{m}.png'),animations='disabled')
    page.locator('#holdList summary').first.click()
    page.locator('#holdCustPaid').focus();assert page.locator('#holdCustPaid').evaluate("e=>parseFloat(getComputedStyle(e).outlineWidth)>=2")
 record('Expanded carts and input focus rendered at 320/1440 across all themes; measured text contrast passes')
 # Browser interaction states and status labels on the actual page.
 for n in THEMES:
  for m in ['light','dark']:
   theme(page,n,m);page.locator('#holdBtn').hover();assert not page.evaluate(MEASURE)['failures'];page.mouse.move(0,0)
   for msg,tone in [('Saved','success'),('Enter Amount Paid','warning'),('Save failed','danger'),('Ready to review','info')]:
    page.evaluate('m=>__test.showToast(m)',msg);assert page.locator('#toast').get_attribute('data-tone')==tone
    failures=page.evaluate(MEASURE)['failures'];assert not failures,(n,m,msg,failures)
 record('Hover and labelled success/warning/error/information notifications retain contrast in all themes')
 # Existing financial directions keep textual signs; internal movement is not income.
 html=page.evaluate("()=>['bank_pos_transfer','sale_transfer','expense'].map(type=>__test.finRowHtml({type,k:type==='expense'?-500:500,date:'2026-10-27',description:type,id:type}))")
 assert 'finTransfer' in html[0] and 'finPlus' in html[1] and 'finMinus' in html[2],html
 record('Internal transfer, receipt and outflow presentation follows existing ledger types')
 page.emulate_media(reduced_motion='reduce');page.evaluate("()=>__test.showToast('Enter Amount Paid')")
 assert page.locator('#holdCustPaid').is_visible();record('Reduced-motion mode keeps controls accessible')
 assert not errors,errors;b.close()
