/* Contextual colour roles derived from the existing six palettes.
   Storage, layout preferences, motion and all financial data are untouched. */
function rsApplyAuditContrast(a,dark){
 const style=document.documentElement.style,t=(dark?RS_DARK_THEMES:RS_THEMES)[a.theme],p=t.exact||{shell:t.background,card:t.surface,input:rsMixHex(t.surface,t.background,.18),buttons:t.accent,contrast:t.primary,onCard:t.text,onInput:t.text,onButton:rsOn(t.accent),muted:t.muted,border:t.border};
 const set=(k,v)=>style.setProperty(k,v),on=rsOn(p.card),isDark=rsLum(p.card)<.2;
 const secondary=rsMixHex(p.card,on,.055),elevated=rsMixHex(p.card,on,.035),soft=rsMixHex(p.card,p.buttons,.11);
 const surfaces=[p.card,secondary,elevated,soft];
 const ink=(c,backs=surfaces,target=5.2)=>backs.reduce((fg,bg)=>rsContrastGuard(fg,bg,target),c);
 const text=ink(p.onCard),muted=ink(rsMixHex(text,p.card,.26)),page=rsContrastGuard(t.exact?.onInput||t.text,p.shell,7);
 const line=rsMixHex(p.card,text,.27),boundary=rsContrastGuard(p.border,p.card,3.1),fieldLine=rsContrastGuard(p.border,p.input,3.1);
 const buttonText=rsContrastGuard(p.onButton||rsOn(p.buttons),p.buttons,4.7),focus=rsContrastGuard(p.buttons,p.input,3.2),accent=ink(p.buttons);
 const roles={'--page-background':p.shell,'--page-text':page,'--page-muted':rsContrastGuard(rsMixHex(page,p.shell,.22),p.shell,4.7),
  '--surface-primary':p.card,'--surface-secondary':secondary,'--surface-elevated':elevated,'--surface-paint':p.card,
  '--text-primary':text,'--text-secondary':muted,'--text-muted':muted,'--muted':muted,'--text':text,
  '--field-bg':p.input,'--field-text':rsContrastGuard(p.onInput,p.input,7),'--text-placeholder':rsContrastGuard(rsMixHex(p.onInput,p.input,.35),p.input,4.7),
  '--border-subtle':line,'--border-strong':boundary,'--field-border':fieldLine,'--line':line,'--line2':line,
  '--accent-primary':p.buttons,'--accent-contrast':buttonText,'--accent-text':accent,'--accent-deep':accent,'--accent-soft':soft,
  '--btn-bg':p.buttons,'--btn-text':buttonText,'--tab-active-bg':p.buttons,'--tab-active-text':buttonText,'--focus-ring':focus,
  '--focus-on-surface':rsContrastGuard(p.buttons,p.card,3.2),'--focus-on-page':rsContrastGuard(p.buttons,p.shell,3.2),
  '--disabled-bg':secondary,'--text-disabled':muted,'--hero-bg':secondary,'--hero-text':text};
 set('--field-chevron',"url(\"data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='8' fill='none' stroke='"+roles['--field-text'].replace('#','%23')+"' stroke-width='1.8' stroke-linecap='round' stroke-linejoin='round'%3E%3Cpath d='M1 1.5l5 5 5-5'/%3E%3C/svg%3E\")");
 Object.entries(roles).forEach(([k,v])=>set(k,v));
 const tones={success:muted,warning:isDark?'#f1bc76':'#89500a',danger:isDark?'#ff9f9f':'#a52932',info:accent,pending:accent};
 for(const [name,seed]of Object.entries(tones)){const bg=rsMixHex(p.card,seed,.11),fg=rsContrastGuard(seed,bg,4.8);set('--status-'+name,fg);set('--status-'+name+'-soft',bg);set('--status-'+name+'-text',ink(seed));}
 for(const [legacy,role]of [['green','success'],['amber','warning'],['red','danger']]){set('--'+legacy,style.getPropertyValue('--status-'+role));set('--'+legacy+'-soft',style.getPropertyValue('--status-'+role+'-soft'));}
 set('--division-pharmacy',muted);set('--division-essentials',muted);
 // Compatibility aliases for existing components and exported reports.
 for(const [key,value]of Object.entries({'card-bg':p.card,'card-text':text,'card-muted':muted,'field-text':roles['--field-text'],'accent':accent,'history-text':buttonText,'warning-bg':style.getPropertyValue('--status-warning-soft'),'warning':style.getPropertyValue('--status-warning'),'danger-bg':style.getPropertyValue('--status-danger-soft'),'danger':style.getPropertyValue('--status-danger')}))set('--audit-'+key,value);
}
