from common import *
results=[]
def run(name,code):
 try:
  page.wait_for_function('!__test.busy && !__test.noteSaving')
  detail=page.evaluate('async()=>{const T=__test,$=id=>document.getElementById(id);const assert=(v,m)=>{if(!v)throw Error(m)};'+code+'}')
  results.append(dict(name=name,status='passed',detail=detail));print('PASS',name,flush=True)
 except Exception as e:
  results.append(dict(name=name,status='failed',error=str(e)));print('FAIL',name,str(e)[:800],flush=True)
 (ROOT/'results/ux-workflows.json').write_text(json.dumps(results,indent=2))
with sync_playwright() as p:
 b=launch(p);c=context_for(b,'app');page,errors=open_page(c);page.on('dialog',lambda d:d.accept());fixture(page,5,0)
 run('Unified first add, repeated quantity with bundle discount, subsequent product', '''
 const stock=T.getStock();Object.assign(stock[0],{quantityPricingEnabled:true,quantityPricingQuantity:3,quantityPricingPrice:250});T.setStock(stock);T.render();
 assert(!$('nextBtn'),'redundant button removed');$('type').value='sale_cash';T.resetTxForm();
 T.chooseProductSuggestion(stock[0]);$('qty').value=2;T.computeTotal();$('holdBtn').click();
 assert(T.heldItems.length===1&&T.heldItems[0].qty===2,'first click adds immediately');assert($('note').value==='','selection cleared after add');
 T.chooseProductSuggestion(stock[0]);$('qty').value=2;T.computeTotal();$('holdBtn').click();
 assert(T.heldItems.length===1&&T.heldItems[0].qty===4&&T.heldItems[0].amount===350,'same row repriced by saved bundle rule');
 T.chooseProductSuggestion(stock[1]);$('qty').value=3;T.computeTotal();$('holdBtn').click();assert(T.heldItems.length===2,'second product');
 const before=JSON.stringify(T.heldItems);$('editOpenCartBtn').click();assert(JSON.stringify(T.heldItems)===before,'review does not add');$('holdBtn').click();assert(JSON.stringify(T.heldItems)===before,'empty add only reviews');return true;
 ''')
 run('Clear selected product and remove cart product immediately', '''
 const before=JSON.stringify(T.heldItems);T.chooseProductSuggestion(T.getStock()[2]);$('qty').value=4;T.computeTotal();assert(!$('clearProductSelection').classList.contains('hidden'),'clear visible');$('clearProductSelection').click();assert(!$('note').value&&!$('qty').value&&!$('amount').value,'cleared input state');assert(JSON.stringify(T.heldItems)===before,'cart preserved');
 document.querySelector('[data-hdel="1"]').click();assert(T.heldItems.length===1,'removed');assert($('holdTotal').textContent===T.fmt(350),'total immediate');T.chooseProductSuggestion(T.getStock()[1]);$('qty').value=3;T.computeTotal();$('holdBtn').click();
 $('holdCustPaid').value=650;$('holdCustReturned').value=0;$('addBtn').click();await T.RS.whenSaved();return true;
 ''')
 run('Completed cart amounts, record tint, friendly heading and IDs retained', '''
 assert(T.tx.length===2&&T.tx.reduce((a,t)=>a+t.amount,0)===650,'one complete sale');assert(T.tx.every(t=>t.purchaseGroupId===T.tx[0].purchaseGroupId),'same original relationship');T.renderLedger();assert(document.querySelectorAll('#ledger tr.heldGroupRow').length===2,'subtle grouped rows');T.CartCorrections.open(T.tx[0].purchaseGroupId);assert(!$('cartCorrectionSummary').textContent.includes(T.tx[0].purchaseGroupId),'no raw group ID');$('cartCorrectionClose').click();return T.tx.map(t=>({id:t.id,qty:t.qty,amount:t.amount}));
 ''')
 run('Notes collapse, directly edit, preserve creation date and refresh Last Saved', '''
 T.setNotes([{id:'old-note',text:'First line\\nOriginal content <safe>',savedAt:'2025-01-02T12:00:00.000Z'}]);T.renderNotes();const card=document.querySelector('.editableNote');assert(!card.open,'collapsed by default');card.querySelector('summary').click();assert(card.open,'expands');card.querySelector('textarea').value='Updated content\\nsecond line';card.querySelector('[data-nsave]').click();await T.RS.whenSaved();return true;
 ''')
 run('Updated note persists without duplicate and Credit total visibility only', '''
 const notes=T.getNotes();assert(notes.length===1&&notes[0].text==='Updated content\\nsecond line','content saved');assert(notes[0].createdAt==='2025-01-02T12:00:00.000Z','creation retained');assert(Date.now()-Date.parse(notes[0].savedAt)<60000,'last saved now');assert(document.querySelector('.editableNote summary').textContent.includes('Last Saved'),'label');
 document.querySelector('[data-history-view="credit"]').click();const before=JSON.stringify(T.calc());assert($('regularCreditOutstanding').textContent==='••••','hidden default');$('showCreditOutstanding').click();assert($('regularCreditOutstanding').textContent===T.fmt(0),'revealed');$('showCreditOutstanding').click();assert($('regularCreditOutstanding').textContent==='••••','masked again');assert(JSON.stringify(T.calc())===before,'no financial mutation');assert(document.querySelector('[data-private-credit]').classList.contains('iconbtn'),'secondary link');return true;
 ''')
 run('Market empty amount blocks purchase and prompts explicit input', '''
 const m=T.getMarketState(),p=T.getStock()[0];m.suppliers.push({id:'ux-supplier',name:'UX supplier',createdAt:new Date().toISOString()});m.requests.push({id:'ux-request',name:p.name,count:1,status:'requested',purchase:{productId:p.id,name:p.name,division:p.division,totalUnits:10,totalCost:600,cost:60,sell:100,priceMode:'manual',markupMode:'custom',markupPercent:0,payment:'purchase_credit',marketPurchaseId:'ux-market'}});m.requestSupplierId='ux-supplier';m.requestAmountPaid=null;m.requestAmountPaidExplicit=false;T.setMarketState(m);T.switchDesk('market',false);T.openMarketReview('requests');
 assert($('marketAmountPaid').value==='','credit purchase not silently zero');window.marketBefore=JSON.stringify({tx:T.tx,stock:T.getStock(),market:T.getMarketState()});$('marketApplyAll').click();assert(JSON.stringify({tx:T.tx,stock:T.getStock(),market:T.getMarketState()})===marketBefore,'empty input changes nothing');assert(document.activeElement===$('marketAmountPaid'),'focus');assert($('marketAmountPaid').classList.contains('paymentPrompt'),'brief prompt');assert($('marketPaymentWarn').textContent.includes('Enter Amount Paid'),'clear message');return true;
 ''')
 run('Explicit zero stops prompt and records fully credit purchase once', '''
 $('marketAmountPaid').value='0';$('marketAmountPaid').dispatchEvent(new Event('input'));assert(!$('marketAmountPaid').classList.contains('paymentPrompt'),'prompt stops');assert(!$('marketApplyAll').disabled,'explicit zero valid');$('marketApplyAll').click();await T.RS.whenSaved();return true;
 ''')
 run('Supplier balances and persisted record integrity', '''
 const m=T.getMarketState(),purchase=m.marketPurchases.find(x=>x.supplierId==='ux-supplier');assert(purchase&&purchase.initialPaid===0&&T.supplierPurchaseOutstanding(purchase)===600,'supplier balance');assert(T.tx.filter(t=>t.marketPurchaseId==='ux-market').length===1,'one purchase');assert((await T.RS.verify()).ok,'database verifies');return true;
 ''')
 print('Browser errors:',errors);b.close()
 if errors or any(x['status']!='passed' for x in results):raise SystemExit(1)
