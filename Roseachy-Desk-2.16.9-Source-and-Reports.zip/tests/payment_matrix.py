from common import *
results=[]
def run(name,code):
 try:
  page.wait_for_function('!__test.busy');detail=page.evaluate('async()=>{const T=__test,$=id=>document.getElementById(id);const assert=(x,m)=>{if(!x)throw Error(m)};'+code+'}');results.append({'name':name,'status':'passed','detail':detail});print('PASS',name,flush=True)
 except Exception as e:results.append({'name':name,'status':'failed','error':str(e)});print('FAIL',name,str(e)[:600],flush=True)
 (ROOT/'results/payment-matrix.json').write_text(json.dumps(results,indent=2))
with sync_playwright() as p:
 b=launch(p);c=context_for(b,'app');page,errors=open_page(c);page.on('dialog',lambda d:d.accept());fixture(page,3,0)
 run('Legacy pack-form units normalize before clearing hidden fields; quantity discount persists', '''
 const stock=T.getStock();stock[0].quantityPricingEnabled=true;stock[0].quantityPricingQuantity=3;stock[0].quantityPricingPrice=250;T.setStock(stock);T.setOpening(T.stockSnapshot());$('type').value='sale_transfer';T.resetTxForm();$('holdBtn').click();T.chooseProductSuggestion(stock[0]);$('txPackEnabled').checked=true;$('txUnitsPerPack').value=12;$('txPacks').value=2;$('qty').value=1;T.computeTotal();assert(Number($('totalAmount').value)===2100,'25 units = 8 bundles plus remainder');$('holdBtn').click();T.chooseProductSuggestion(stock[1]);$('qty').value=2;T.computeTotal();$('holdBtn').click();$('holdCustPaid').value=2400;$('holdCustReturned').value=100;$('addBtn').click();await T.RS.whenSaved();return true;
 ''')
 run('Cart, daily summaries, saved weekly totals, and analytics agree', '''
 window.id=T.tx[0].purchaseGroupId;window.stock=JSON.stringify(T.getStock());assert(T.tx.length===2&&T.tx[0].qty===25&&T.tx[0].unitPrice===100&&T.tx[0].amount===2100,'stored price '+JSON.stringify(T.tx.map(t=>({id:t.id,type:t.type,qty:t.qty,amount:t.amount,unitPrice:t.unitPrice,basketTotal:t.basketTotal,paid:t.customerPaid})))+' / '+$('stockWarn').textContent);assert(T.tx.reduce((s,t)=>s+t.amount,0)===2300,'cart');assert(T.calc().sales===2300&&T.calc().expectedBank===2400,'daily');await T.runManualDaySave();$('weekFrom').value=$('weekTo').value=$('date').value;T.renderWeekly();assert($('wSales').textContent===T.fmt(2300),'weekly');const records=T.anaRecords(),data=T.anaAggregate(records,$('date').value,$('date').value,'all');assert(data.sales===2300&&data.units===27,'analytics');return {sales:data.sales,units:data.units};
 ''')
 run('Transfer to Sale + Cash Out preserves one electronic receipt and returns exact cash', '''
 T.CartCorrections.open(id);$('cartCorrectionType').value='sale_cashout';$('cartCorrectionPaid').value=2500;$('cartCorrectionReturned').value=200;$('cartCorrectionDestination').value='pos';await T.CartCorrections.save();assert(T.tx.every(t=>t.type==='sale_cashout'),'type '+$('toast').textContent);const c=T.calc();assert(c.sales===2300&&c.expectedCash===99800&&c.pos.expectedElectronic===2500,'cashout ledger');assert(JSON.stringify(T.getStock())===stock,'stock unchanged');return {retailCash:c.expectedCash,posElectronic:c.pos.expectedElectronic};
 ''')
 run('Invalid cash out and excess-change entry preserve original cart', '''
 const before=JSON.stringify(T.tx);T.CartCorrections.open(id);$('cartCorrectionReturned').value=201;await T.CartCorrections.save();assert(JSON.stringify(T.tx)===before,'invalid cashout');$('cartCorrectionClose').click();T.CartCorrections.open(id);$('cartCorrectionType').value='sale_cash';$('cartCorrectionPaid').value=2300;$('cartCorrectionReturned').value=1;$('cartCorrectionRecover').checked=false;await T.CartCorrections.save();assert(JSON.stringify(T.tx)===before,'unconfirmed excess');$('cartCorrectionClose').click();return true;
 ''')
 run('Split cash/bank/credit shares total; one outstanding cart obligation', '''
 T.CartCorrections.open(id);$('cartCorrectionType').value='sale_split';$('cartCorrectionPaid').value=1000;$('cartCorrectionBank').value=600;$('cartCorrectionReturned').value=0;await T.CartCorrections.save();assert(T.tx.every(t=>t.type==='sale_split'),'split '+$('toast').textContent);const c=T.calc(),d=T.creditHistoryObligations()[0];assert(c.expectedCash===100400&&c.expectedBank===600&&c.closingDebt===1300,'split ledger');assert(d.total===2300&&d.initialPaid===1000&&d.original===1300,'one group');assert(JSON.stringify(T.getStock())===stock,'no inventory');return {cash:c.expectedCash,bank:c.expectedBank,debt:c.closingDebt};
 ''')
 run('Incomplete cart correction is blocked at ledger boundary', '''
 const before=JSON.stringify(T.tx);const error=T.commitSalesLedger(T.tx.slice(1));assert(error&&error.includes('Edit Cart'),'whole cart guard');assert(JSON.stringify(T.tx)===before,'unchanged');return error;
 ''')
 print('Browser errors:',errors);b.close()
 if any(r['status']!='passed' for r in results) or errors:raise SystemExit(1)
