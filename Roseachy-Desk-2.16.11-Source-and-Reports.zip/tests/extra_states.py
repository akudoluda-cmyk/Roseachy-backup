from visual_support import *
checks=[]
LEVEL=int(os.environ.get('EXTRA_LEVEL','-1'));SUFFIX='-max' if LEVEL==100 else '';TEST_WIDTHS=[320,1440] if LEVEL==100 else WIDTHS
with sync_playwright() as p:
 b=launch(p);c=context_for(b,'app');page,errors=open_page(c);page.on('dialog',lambda d:d.accept());seed(page)
 if LEVEL>=0:page.evaluate('v=>{for(const key of [\'roundnessLevel\',\'borderWeightLevel\',\'shadowLevel\']){const e=document.querySelector(\'[data-setting="\'+key+\'"]\');e.value=v;e.dispatchEvent(new Event(\'input\',{bubbles:true}))}}',LEVEL)
 for width in TEST_WIDTHS:
  page.set_viewport_size({'width':width,'height':900})
  for n in THEMES:
   for m in ['light','dark']:
    theme(page,n,m)
    for kind in ['supplier','credit']:
     page.evaluate("kind=>{if(kind==='supplier'){__test.switchDesk('market',false);__test.openSupplierPayment(null,'visual-supplier')}else{__test.switchDesk('sales',false);__test.CreditAccounts.open()}}",kind)
     id='supplierPaymentOverlay' if kind=='supplier' else 'creditOverlay'
     panel=page.locator('#'+id+' .marketPanel');panel.wait_for(state='visible');metrics=page.evaluate(MEASURE)
     assert not metrics['failures'],(width,n,m,kind,metrics['failures']);assert not panel.evaluate('e=>e.scrollWidth>e.clientWidth+2'),(width,n,m,kind,'overflow')
     if width==320 and m=='dark':panel.screenshot(path=str(ROOT/'results/screenshots/after'/f'{kind}{SUFFIX}-{width}-{n}-{m}.png'),animations='disabled')
     page.locator('#'+('supplierPaymentCancelTop' if kind=='supplier' else 'creditClose')).click()
     checks.append({'width':width,'theme':n,'mode':m,'view':kind,'status':'passed','textSamples':metrics['tested']})
  print('MODALS',width,flush=True)
 (ROOT/f'results/modal-matrix{SUFFIX}.json').write_text(json.dumps({'screens':checks,'browserErrors':errors},indent=2))
 screen(page,'financial');page.locator('#finAdd').click();page.locator('#finEditAmount').fill('987654321.12');page.locator('#finEditReason').fill('Synthetic visual verification of large value');page.locator('#finEditSave').click();page.locator('#finOverview').wait_for(state='visible');assert '987,854,321.12' in page.locator('#finBalance').inner_text()
 for width in TEST_WIDTHS:
  page.set_viewport_size({'width':width,'height':900});assert page.evaluate('document.documentElement.scrollWidth<=innerWidth+2')
  assert not page.locator('#finBalance').evaluate('e=>e.scrollWidth>e.clientWidth+2')
  assert not page.evaluate(MEASURE)['failures']
 page.set_viewport_size({'width':320,'height':900});page.screenshot(path=str(ROOT/'results/screenshots/after/large-bank-balance.png'))
 (ROOT/f'results/large-values{SUFFIX}.json').write_text(json.dumps({'status':'passed','widths':TEST_WIDTHS,'displayedBankBalance':page.locator('#finBalance').inner_text(),'browserErrors':errors},indent=2));assert not errors,errors;b.close()
