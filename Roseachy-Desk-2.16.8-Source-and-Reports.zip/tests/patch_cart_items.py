from pathlib import Path
p=Path('/workspace/Roseachy-backup/index.html');s=p.read_text()
def rep(a,b,count=1):
 global s
 assert s.count(a)==count,(a[:100],s.count(a),count)
 s=s.replace(a,b)

helpers='''/* Item edits reuse each sale's captured price rule, never today's stock price. */
function reviseCartItem(old,qty,unit){
 const q=Number(qty),price=Number(unit);
 if(!String(qty).trim()||!Number.isSafeInteger(q)||q<0||(old.productId&&q<1)||(!old.productId&&q!==n(old.qty)))throw Error('Enter a positive whole-unit quantity.');
 if(!String(unit).trim()||!Number.isFinite(price)||price<=0||price>1e12||Math.abs(price*100-Math.round(price*100))>1e-6)throw Error('Enter a positive unit amount with at most two decimal places.');
 if(old.productId&&price!==n(old.unitSellingPrice??old.unitPrice))throw Error('This product uses its recorded selling price.');
 if(q===n(old.qty)&&price===n(old.unitSellingPrice??old.unitPrice))return clone(old);
 const rule=ruleFromSaleRecord(old),pricing=old.productId?salePricing(null,q,rule):{total:roundMoney(price*(q||1)),applied:false};
 if(!(pricing.total>0)||pricing.total>1e12)throw Error('The revised item total is invalid or too large.');
 return {...old,qty:q,totalUnits:q,looseUnitsEntered:q,packSelected:false,packsEntered:0,unitPrice:price,unitSellingPrice:price,amount:pricing.total,actualSaleTotal:pricing.total,quantityPricingApplied:!!pricing.applied};
}
function cartItemEditor(t,index,scope){
 return '<details class="cartItemEditor" data-cart-item="'+index+'"><summary><span>'+esc(t.productName||t.note||'Item')+' <small data-item-quantity>× '+n(t.qty)+'</small></span><b data-item-total>'+fmt(t.amount)+'</b></summary><div class="split"><label>Quantity<input id="'+scope+'Qty_'+index+'" data-item-qty type="number" min="'+(t.productId?1:0)+'" step="1" value="'+n(t.qty)+'"'+(!t.productId?' readonly':'')+'></label><label>Unit amount<input id="'+scope+'Price_'+index+'" data-item-price type="number" min="0.01" step="0.01" value="'+n(t.unitSellingPrice??t.unitPrice)+'"'+(t.productId?' readonly':'')+'></label></div>'+(t.productId?'<p class="help">Recorded selling price'+(t.quantityPricingEnabledAtSale?' · quantity discount recalculates automatically':'')+'</p>':'')+'<p class="help" data-item-error role="alert"></p></details>';
}
function readCartItemEditor(card,old){return reviseCartItem(old,card.querySelector('[data-item-qty]').value,card.querySelector('[data-item-price]').value);}
function updateCartItemSummary(card,item){card.querySelector('[data-item-quantity]').textContent='× '+n(item.qty);card.querySelector('[data-item-total]').textContent=fmt(item.amount);card.querySelector('[data-item-error]').textContent='';}
'''
rep('function heldQtyFor(pid)',helpers+'\nfunction heldQtyFor(pid)')

# Existing open cart: directly expand an item, edit in place, immediate totals.
rep('function renderHoldPanel(){', 'function renderHoldPanel(keepItems=false){')
rep("const b=$('holdList');b.innerHTML=", "if(keepItems){saveHoldState();return;}const b=$('holdList');b.innerHTML=")
start=s.index("heldItems.forEach((o,i)=>{const d=document.createElement('div');d.className='savedItem';",s.index('function renderHoldPanel'))
end=s.index('if(holdMode&&currentItemHasInput())',start)
s=s[:start]+'''heldItems.forEach((o,i)=>{const d=document.createElement('div');d.className='savedItem cartEditableRow';d.innerHTML=cartItemEditor(o,i,'heldItem')+'<button type="button" class="iconbtn del" data-hdel="'+i+'" aria-label="Remove '+esc(o.note||'item')+' from cart" title="Remove from cart">×</button>';b.appendChild(d)});'''+s[end:]
rep("$('editOpenCartBtn').addEventListener('click',()=>{$('type').scrollIntoView({block:'center'});$('type').focus();toast('Sales-type changes apply to every item in this cart')});", "$('editOpenCartBtn').addEventListener('click',()=>{$('holdPanel').scrollIntoView({block:'center'});$('holdList').querySelector('summary')?.focus();toast('Select a cart item to edit its quantity')});")
rep("$('holdList').addEventListener('click',", """$('holdList').addEventListener('input',e=>{
 const card=e.target.closest('[data-cart-item]');if(!card)return;const i=Number(card.dataset.cartItem),old=heldItems[i];if(!old)return;
 try{const revised=readCartItemEditor(card,old),reserved=heldItems.filter((t,j)=>j!==i&&t.productId===old.productId).reduce((sum,t)=>sum+n(t.qty),0);
  if(old.productId&&revised.qty+reserved>n(getStock().find(p=>p.id===old.productId)?.qty))throw Error('Not enough stock for this quantity.');
  heldItems[i]=revised;updateCartItemSummary(card,revised);renderHoldPanel(true);
 }catch(error){card.querySelector('[data-item-error]').textContent=error.message;}
});
function validOpenCartEditors(){for(const card of $('holdList').querySelectorAll('[data-cart-item]')){try{const i=Number(card.dataset.cartItem),item=readCartItemEditor(card,heldItems[i]);if(stableBackupText(item)!==stableBackupText(heldItems[i]))throw Error('Review this item quantity before completing the sale.');}catch(e){card.open=true;card.querySelector('[data-item-error]').textContent=e.message;card.querySelector('input').focus();return false;}}return true;}
$('holdList').addEventListener('click',""")
rep("if(holdMode){if(!currentItemHasInput()){finalizeHold(null);return}", "if(holdMode){if(!validOpenCartEditors())return;if(!currentItemHasInput()){finalizeHold(null);return}")

# Completed cart keeps its existing modal and atomic save.
rep("const unchanged=t=>Object.fromEntries(Object.entries(t).filter(([k])=>!fields.includes(k)));", "const itemFields=['qty','totalUnits','looseUnitsEntered','packSelected','packsEntered','unitPrice','unitSellingPrice','amount','actualSaleTotal','quantityPricingApplied'];\n const unchanged=t=>Object.fromEntries(Object.entries(t).filter(([k])=>![...fields,...itemFields].includes(k)));")
rep("return 'Cart identity, quantities and captured prices must remain unchanged.';", "return 'Cart identity and unrelated item properties must remain unchanged.';\n   try{const expected=reviseCartItem(t,r.qty,r.unitSellingPrice??r.unitPrice);for(const key of itemFields)if(stableBackupText(expected[key]??null)!==stableBackupText(r[key]??null))return 'Review the item quantity and recorded pricing.';}catch(e){return e.message;}")
rep("session={id:String(id),fingerprint:stableBackupText(rows)};", "session={id:String(id),fingerprint:stableBackupText(rows),rows:clone(rows)};")
start=s.index("  $('cartCorrectionSummary').textContent=",s.index('const CartCorrections'))
end=s.index("  $('cartCorrectionError').textContent",start)
s=s[:start]+"  $('cartCorrectionLines').innerHTML=rows.map((t,i)=>cartItemEditor(t,i,'cartCorrectionItem')).join('');\n  updateItemTotals();\n"+s[end:]
rep(" function update(){const method=$('cartCorrectionType')", """ function editedRows(){if(!session)throw Error('Reopen this cart before editing.');return [...$('cartCorrectionLines').querySelectorAll('[data-cart-item]')].map(card=>readCartItemEditor(card,session.rows[Number(card.dataset.cartItem)]));}
 function updateItemTotals(){try{const rows=editedRows();$('cartCorrectionSummary').textContent='Cart Purchase · '+rows.length+' item(s) · '+fmt(rows.reduce((sum,t)=>sum+n(t.amount),0));return true;}catch{$('cartCorrectionSummary').textContent='Cart Purchase · Check item quantities and amounts';return false;}}
 function update(){const method=$('cartCorrectionType')""")
rep("function prepare(rows){\n  const type=", "function prepare(original){\n  const rows=editedRows();\n  const type=")
rep("before:snapshot(rows[i]),after:snapshot(t)","before:snapshot(original[i]),after:snapshot(t)")
rep('Sales-type changes apply to every item in this cart. Quantities and recorded selling prices are preserved.', 'Select a product to edit its quantity. Sales-type and payment changes apply to the entire cart.')
rep("$('cartCorrectionClose').onclick=", """$('cartCorrectionLines').addEventListener('input',e=>{const card=e.target.closest('[data-cart-item]');if(!card||!session)return;try{updateCartItemSummary(card,readCartItemEditor(card,session.rows[Number(card.dataset.cartItem)]));}catch(error){card.querySelector('[data-item-error]').textContent=error.message;}updateItemTotals();});
 $('cartCorrectionClose').onclick=""")

# Reuse the stock replay already used by transaction corrections, only on quantity edits.
rep("  tx=next;\n  for(const d of affected)", """  const products=new Set(next.filter(t=>t.productId&&n(t.qty)!==n(before.find(x=>x.id===t.id)?.qty)).map(t=>t.productId));
  const stockBefore=products.size?clone(getStock()):null;
  tx=next;
  if(products.size){
   if(!rebuildStockFromOpening()){tx=before;return 'Not enough stock for this correction. Original cart and stock were kept.';}
   // Replay derives changed-product allocations; unrelated products and records stay exact.
   const unchangedRows=new Map(next.filter(t=>!products.has(t.productId)).map(t=>[t.id,t]));tx=tx.map(t=>unchangedRows.get(t.id)||t);
   const stockMap=new Map(stockBefore.map(p=>[p.id,p]));setStock(getStock().map(p=>products.has(p.id)?p:(stockMap.get(p.id)||p)));
  }
  for(const d of affected)""")

# The entered payment value is authoritative inside the same purchase transaction.
rep("paidInput=active?l?.amountPaid:m.requestAmountPaid,applied=[],selectedTotal=", "paidInput=selectedMarketReviewItems().some(x=>!x.purchase.updateOnly)?inventoryPayment($('marketAmountPaid').value,'Amount paid'):0,applied=[],selectedTotal=")
rep("if($('marketAmountPaid').value!=='')inventoryPayment($('marketAmountPaid').value,'Amount paid');if(marketReviewMixedPayment())", "if(active&&l){l.amountPaid=paidInput;l.amountPaidExplicit=true}else{m.requestAmountPaid=paidInput;m.requestAmountPaidExplicit=true}if(marketReviewMixedPayment())")
rep("}catch(error){renderNotes();showToast('Notes were not changed:", "}catch(error){showToast('Notes were not changed:")
rep('#recordsTable tr.heldGroupRow>td{border-left-width:0;border-right-width:0}', '''#recordsTable tr.heldGroupRow>td{border-left-width:0;border-right-width:0}
#recordsTable #ledger tr.heldGroupRow>td:first-child{box-shadow:none}
#recordsTable #ledger tr.heldGroupStart>td,#recordsTable #ledger tr.heldGroupEnd>td{border-top-width:1px;border-bottom-width:1px}
.cartEditableRow{align-items:flex-start;gap:8px}
.cartItemEditor{flex:1;min-width:0;margin:6px 0;padding:8px;border-bottom:1px solid var(--line)}
.cartItemEditor summary{cursor:pointer;display:list-item;font-size:14px;overflow-wrap:anywhere}
.cartItemEditor summary b{float:right;margin-left:8px}
.cartItemEditor summary small{color:var(--muted)}
.cartItemEditor .split{margin-top:12px;grid-template-columns:repeat(2,minmax(0,1fr))}
.cartItemEditor input{width:100%;min-width:0}
.cartItemEditor input[readonly]{opacity:.8}
.cartItemEditor [data-item-error]:empty{display:none}''')
p.write_text(s)
