from visual_support import *
import traceback
views=['sales','stock','market','suppliers','financial','reports','notes','analytics','history','credit','settings']
checks=[];out=ROOT/'results/responsive-matrix.json'
with sync_playwright() as p:
 b=launch(p);c=context_for(b,'app');page,errors=open_page(c);page.on('dialog',lambda d:d.accept());seed(page)
 # Long labels and large values use the same real purchase and ledger workflow.
 page.evaluate('''async()=>{const T=__test,$=id=>document.getElementById(id),s=T.getStock();s[0].name='Paracetamol 500mg extended family pack — long product name with batch details';T.setStock(s);const m=T.getMarketState();m.suppliers[0].name='Ade Wholesale Pharmaceutical and Household Supplies Limited — Lagos';m.requests=[{id:'matrix-request',name:s[0].name,count:1,status:'requested',purchase:{productId:s[0].id,name:s[0].name,division:s[0].division,totalUnits:10,totalCost:600,cost:60,sell:100,priceMode:'manual',markupMode:'custom',markupPercent:0,payment:'purchase_credit',marketPurchaseId:'matrix-market'}}];m.requestSupplierId='visual-supplier';m.requestAmountPaid=null;m.requestAmountPaidExplicit=false;T.setMarketState(m);T.switchDesk('market',false);T.openMarketReview('requests');$('marketAmountPaid').value='0';$('marketAmountPaid').dispatchEvent(new Event('input'));$('marketApplyAll').click();await T.RS.whenSaved();}''')
 page.wait_for_function('!__test.busy')
 for width in [int(x) for x in os.environ.get('MATRIX_WIDTHS',','.join(map(str,WIDTHS))).split(',')]:
  page.set_viewport_size({'width':width,'height':900})
  for name in THEMES:
   for mode in ['light','dark']:
    theme(page,name,mode)
    for view in views:
     screen(page,view);page.evaluate('v=>{if(v==="settings")document.querySelectorAll(".settingsGroup").forEach(e=>e.open=true);if(v==="analytics")document.querySelectorAll(".rsTrendCard").forEach(e=>e.open=true)}',view);assert page.evaluate('document.body.dataset.theme')==name;assert page.evaluate('document.body.dataset.colorMode')==mode;m=page.evaluate(MEASURE)
     clips=page.evaluate('''()=>[...document.querySelectorAll('button,input,select,textarea')].filter(e=>{const r=e.getBoundingClientRect(),s=getComputedStyle(e);if(!r.width||!r.height||s.visibility==='hidden'||e.closest('.hidden'))return false;if(e.closest('.tablewrap,.recordsTableWrap,.productHistoryTableWrap,.tabs,.marketViewTabs,.seg,.segChoice'))return false;if(e.id==='deskMenuBtn')return false;return e.scrollWidth>e.clientWidth+3&&s.overflowX==='hidden'}).map(e=>({id:e.id,text:e.textContent.slice(0,60),client:e.clientWidth,scroll:e.scrollWidth}))''')
     checks.append({'width':width,'theme':name,'mode':mode,'view':view,'tested':m['tested'],'failures':m['failures'],'pageOverflow':m['scrollWidth']>m['pageWidth']+2,'clippedControls':clips})
     if width in [320,1440] and mode=='light' and view in ['suppliers','analytics','settings']:
      page.screenshot(path=str(ROOT/'results/screenshots/after'/f'matrix-{width}-{name}-{mode}-{view}.png'),animations='disabled')
  print('WIDTH',width,'screens',len(checks),'contrastFailures',sum(len(x['failures']) for x in checks),'overflow',sum(x['pageOverflow'] for x in checks),'clippedControls',sum(len(x['clippedControls']) for x in checks),flush=True)
  out.write_text(json.dumps({'screens':checks,'browserErrors':errors},indent=2))
 b.close()
print('DONE',len(checks),'checks',sum(x['tested'] for x in checks),'text samples','errors',errors)
