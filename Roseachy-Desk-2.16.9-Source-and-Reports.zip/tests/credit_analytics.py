from common import *
results=[]
def run(name,code):
 try:
  page.wait_for_function('!__test.busy')
  detail=page.evaluate('async()=>{const T=__test,$=id=>document.getElementById(id);const assert=(x,m)=>{if(!x)throw Error(m)};'+code+'}')
  results.append({'name':name,'status':'passed','detail':detail});print('PASS',name,flush=True)
 except Exception as e:
  results.append({'name':name,'status':'failed','error':str(e)});print('FAIL',name,str(e)[:700],flush=True)
 (ROOT/'results/credit-analytics.json').write_text(json.dumps(results,indent=2))
with sync_playwright() as p:
 b=launch(p);c=context_for(b,'app');page,errors=open_page(c);page.on('dialog',lambda d:d.accept());fixture(page,6,0)
 run('Complete multi-product partial cart; one displayed obligation', '''
 $('type').value='sale_cash';T.resetTxForm();$('holdBtn').click();
 for(const [i,q] of [[0,2],[1,3]]){T.chooseProductSuggestion(T.getStock()[i]);$('qty').value=q;T.computeTotal();$('holdBtn').click();}
 $('party').value='Ada';$('party').dispatchEvent(new Event('input'));$('holdCustPaid').value=150;$('holdCustReturned').value=0;$('addBtn').click();await T.RS.whenSaved();
 const debts=T.creditHistoryObligations();assert(debts.length===1,'one cart');assert(debts[0].total===500&&debts[0].original===350&&debts[0].initialPaid===150,'amounts');window.debtId=debts[0].id;return {total:debts[0].total,credit:debts[0].original,paidAtPurchase:debts[0].initialPaid};
 ''')
 run('Partial repayment to cart as one receipt; no stock or sale duplication', '''
 window.beforeStock=JSON.stringify(T.getStock());window.beforeSales=T.calc().sales;
 document.querySelector('[data-history-view="credit"]').click();document.querySelector('[data-credit-open]').click();$('creditSettleAmount').value=100;document.querySelector('[data-credit-settle]').click();await T.RS.whenSaved();
 return true;
 ''')
 run('Verify partial repayment and settle remaining cart balance', '''
 let d=T.creditHistoryObligations().find(d=>d.id===debtId);assert(d.paid===100&&d.balance===250,'partial totals');assert(d.repayments.length===1,'one receipt');assert(JSON.stringify(T.getStock())===beforeStock,'stock unchanged');assert(T.calc().sales===beforeSales,'repayment is not sale');$('creditSettleAmount').value=250;document.querySelector('[data-credit-settle]').click();await T.RS.whenSaved();return true;
 ''')
 run('Fully settled cart; related correction blocked; unrelated sale unchanged', '''
 const d=T.creditHistoryObligations().find(d=>d.id===debtId);assert(d.status==='settled'&&d.balance===0&&d.paid===350,'settled');assert(d.repayments.length===2,'two receipt events');const before=JSON.stringify(T.tx);T.CartCorrections.open(T.tx[0].purchaseGroupId);$('cartCorrectionType').value='sale_cash';$('cartCorrectionPaid').value=500;$('cartCorrectionReturned').value=0;await T.CartCorrections.save();assert(JSON.stringify(T.tx)===before,'cannot erase repaid obligation');$('cartCorrectionClose').click();return {balance:d.balance,payments:d.paid};
 ''')
 run('Change payable integrated with explicit opposite direction and human-readable search', '''
 const stock=T.getStock()[2];const t={id:'change-sale',type:'sale_cash',amount:100,qty:1,unitPrice:100,unitSellingPrice:100,productId:stock.id,productName:stock.name,note:stock.name,party:'Bola',division:stock.division,costSnapshot:60,customerPaid:200,changeReturned:40,changeOwed:60,ts:new Date().toISOString()};
 assert(await T.inventoryCommit(()=>{const e=T.commitSalesLedger([...T.tx,t]);if(e)throw Error(e);return true},'Sales Desk'),'commit');
 const rows=T.creditHistoryObligations(),owed=rows.find(d=>d.direction==='payable');assert(owed&&owed.original===100&&owed.paid===40&&owed.balance===60,'payable direction');
 T.renderCreditHistory();$('creditHistorySearch').value='Bola';$('creditHistorySearch').focus();T.renderCreditHistory();assert($('creditHistoryResults').textContent.includes('Business owes customer'),'direction label');const suggestion=document.querySelector('[data-credit-suggestion]');assert(suggestion&&suggestion.textContent.includes('Bola'),'human result');suggestion.click();assert($('creditHistorySearch').value==='','raw ID not entered as search');assert(document.querySelector('[data-credit-open="payable:change-sale"]').getAttribute('aria-expanded')==='true','correct detail');return {owed:owed.balance};
 ''')
 run('Private Credit Accounts remain private and show cart-level current balance', '''
 const C=T.CreditAccounts;await C.purchase({customerId:'fixture-customer-0',lines:[{productId:'fixture-product-4',qty:2},{productId:'fixture-product-5',qty:3}],paid:100,id:'private-cart'});await C.pay({customerId:'fixture-customer-0',amount:150,method:'cash',id:'private-payment'});
 assert(C.balance('fixture-customer-0')===250,'private balance');assert(!T.creditHistoryObligations().some(d=>d.origins.some(t=>t.creditCustomerId)),'confidential records excluded');C.open();document.querySelector('[data-credit-account="fixture-customer-0"]').click();assert($('creditHistory').textContent.includes('Repayments received')&&$('creditHistory').textContent.includes('Outstanding'),'private cart metrics');$('creditClose').click();return true;
 ''')
 run('Approved metric labels, data preserved and formulas unchanged', '''
 const s=T.CreditAccounts.summaries(),html=T.CreditAccounts.reportHTML();assert(s.paid===100&&s.collections===150,'original values retained');for(const label of ['Cash Sales','Credit Sales','Credit Repayments Received'])assert(html.includes(label),label);assert(!html.toLowerCase().includes('received at credit purchase'),'removed presentation');assert(html.includes('cash, card and transfer'),'scope tooltip');return s;
 ''')
 run('Seven-day demand dataset: consistency differs from volume and deduplicates IDs', '''
 const stock=T.getStock(),names=['Bottled water','Coke','Old bulk','Frequent small','Returned product','No recent sale'];stock.forEach((p,i)=>p.name=names[i]);T.setStock(stock);
 const from='2026-10-19',to='2026-10-25';const rows=[];
 const sale=(id,p,qty,date,extra={})=>({id,type:'sale_cash',productId:stock[p].id,productName:names[p],note:names[p],division:stock[p].division,amount:qty*100,qty,unitPrice:100,unitSellingPrice:100,costSnapshot:60,ts:date+'T12:00:00.000Z',...extra});
 for(let i=0;i<7;i++){const date='2026-10-'+(19+i),r={id:'analytics-day-'+i,date,business:'Demand Test',fields:{},tx:[sale('water-'+i,0,5,date),sale('small-'+i,3,1,date)],openingStock:T.stockSnapshot(),closingStock:T.stockSnapshot()};if(!i)r.tx.push(sale('coke',1,40,date),sale('oldbulk',2,60,date));if(i===2){r.tx.push(sale('returned',4,5,date),sale('return',4,5,date,{type:'refund_cash',originalSaleId:'returned',returnToStock:true}),sale('cancelled',1,1000,date,{cancelled:true}),sale('supplier',1,500,date,{type:'purchase_cash'}));}rows.push(r);}
 rows.push({id:'duplicate',date:to,business:'Duplicate copy',tx:[{...rows[0].tx[0]}]});
 const bounds={from,to,days:7,prevFrom:'2026-10-12',prevTo:'2026-10-18'};$('anaPeriod').value='custom';
 const trends=T.anaTrendData(rows,bounds,'all'),agg=T.anaAggregate(rows,from,to,'all'),water=trends.products.find(p=>p.name==='Bottled water'),coke=trends.products.find(p=>p.name==='Coke');
 assert(water.currentQty===35&&coke.currentQty===40,'cumulative units');assert(coke.currentEvents===1,'bulk is one transaction');assert(water.currentEvents===7,'seven transactions');
 // Duplicate record carries a different record date; its stable transaction timestamp determines no fabricated extra event.
 $('anaDemandMode').value='consistent';let ranked=T.anaRenderProductTrends(rows,bounds,'all');assert(ranked.top[0].name==='Bottled water','consistent first');$('anaDemandMode').value='units';ranked=T.anaRenderProductTrends(rows,bounds,'all');assert(ranked.top.findIndex(p=>p.name==='Coke')<ranked.top.findIndex(p=>p.name==='Bottled water'),'units differs');$('anaDemandMode').value='velocity';ranked=T.anaRenderProductTrends(rows,bounds,'all');assert(!ranked.top.some(p=>p.name==='Coke'),'bulk not repeated demand');assert(agg.products.get(stock[4].id).units===0,'return net zero');assert(agg.products.get(stock[1].id).units===40,'supplier and cancelled excluded');return {waterUnits:water.currentQty,cokeUnits:coke.currentQty,waterSales:water.currentEvents,cokeSales:coke.currentEvents};
 ''')
 print('Browser errors:',errors);b.close()
 if any(x['status']!='passed' for x in results) or errors:raise SystemExit(1)
