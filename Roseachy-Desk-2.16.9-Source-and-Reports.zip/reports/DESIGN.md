# Restrained colour system

Each theme keeps its original foundation and dominant accent. Cards, totals and financial summaries use the foundation and slight tonal shifts. There is no additional decorative secondary hue; success and category labels are neutral, information/partial states share the main accent. Small amber warnings and red errors/destructive controls are semantic exceptions, paired with text.

| Theme | Foundation | Dominant accent |
| --- | --- | --- |
| Cobalt Studio | Ice / midnight navy | Cobalt blue |
| Pearl & Royal Blue | Pearl / midnight blue | Royal blue |
| Midnight & Ember | Cream / midnight navy | Ember orange |
| Cyan Flux | Graphite / blue charcoal | Clear blue |
| Coral Carbon | Carbon charcoal | Soft coral |
| Mono Mint | Porcelain / green charcoal | Charcoal in light mode, mint in dark mode |

Theme names, registry, selection and light/dark variants remain intact. Conflicting multi-hue gradient paint is replaced at the component layer with the original solid theme tokens. The final interface uses consistent titles, spacing, neutral boundaries and numerical weight rather than giving sections separate colours.

Two decorative day-action glyphs were removed. Existing cart, clear, menu, back and close controls remain functional and named. The source did not contain a system of colourful icon tiles to remove; none was added. Functional icons and the select chevron use the current text colour. The original monochrome brand remains.

Add to Cart is primary before a basket is open; Complete Sale becomes primary once the basket is open. Routine row actions, links, privacy controls and secondary actions remain restrained. Selected tabs and themes have consistent accent/border signals. Charts retain the existing single-accent line/bar palette and original calculations.

Supplier status labels and amounts remain explicit. Routine supplier rows are neutral; partial states use the principal accent; warnings remain small. Positive and negative financial movements retain their numeric signs and descriptions instead of making every row red or green. Internal transfers retain their own ledger-type presentation class.

Legacy layout and motion styles are isolated in one CSS cascade layer. Sixteen superseded theme-paint blocks have redundant declarations removed. One canonical semantic component stylesheet defines paint. Contextual foreground/background roles fix the mixed dark-card/light-input Ember palette without replacing its identity. Existing display preferences remain available.
