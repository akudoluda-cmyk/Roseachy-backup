from pathlib import Path
from playwright.sync_api import sync_playwright
import json, time, os

ROOT = Path(__file__).resolve().parents[1]
APP = Path(os.environ.get("ROSEACHY_APP", str(ROOT/"app"))).resolve()
INSTRUMENT = """
window.__ready = false;
window.__storageOps = {get:0,getAll:0,put:0,delete:0,clear:0,openCursor:0,openKeyCursor:0,transactions:0,localGet:0,localSet:0};
for (const name of ['get','getAll','put','delete','clear','openCursor','openKeyCursor']) {
  const original=IDBObjectStore.prototype[name];
  IDBObjectStore.prototype[name]=function(...args){window.__storageOps[name]++;return original.apply(this,args);};
}
const originalTx=IDBDatabase.prototype.transaction;
IDBDatabase.prototype.transaction=function(...args){window.__storageOps.transactions++;return originalTx.apply(this,args);};
for(const [method,counter] of [['getItem','localGet'],['setItem','localSet']]){
 const original=Storage.prototype[method];
 Storage.prototype[method]=function(...args){window.__storageOps[counter]++;return original.apply(this,args)};
}
window.addEventListener('roseachy:ready',()=>{window.__ready=true;window.__readyAt=performance.now();});
"""

def context_for(browser, target="original", profile="desktop", hooks=True):
    context = browser.new_context(viewport={"width": 1440, "height": 1000} if profile == "desktop"
        else {"width":390,"height":844}, is_mobile=profile=="mobile", has_touch=profile=="mobile",
        device_scale_factor=1 if profile=="desktop" else 3,
        timezone_id="Africa/Lagos", service_workers="block")
    context.add_init_script(INSTRUMENT)
    source = (ROOT/"original").resolve() if target=="original" else APP
    def route(req):
        from urllib.parse import urlsplit, unquote
        path = unquote(urlsplit(req.request.url).path).lstrip("/") or "index.html"
        f = (source/path).resolve()
        if not f.is_relative_to(source) or not f.is_file():
            req.fulfill(status=404,body="Not found")
            return
        data=f.read_bytes()
        mime = {".html":"text/html",".js":"application/javascript",".json":"application/json",
                ".png":"image/png",".svg":"image/svg+xml"}.get(f.suffix,"text/plain")
        if path=="index.html" and hooks:
            text=data.decode()
            marker="init().then(()=>"
            assert text.count(marker)==1
            text=text.replace(marker,(ROOT/"tests/hooks.js").read_text()+"\n"+marker)
            data=text.encode()
        req.fulfill(status=200,body=data,content_type=mime)
    context.route("http://127.0.0.1:8000/**",route)
    return context

def open_page(context):
    page=context.new_page()
    page.set_default_timeout(60000)
    errors=[]
    page.on("pageerror",lambda e:errors.append(str(e)))
    page.goto("http://127.0.0.1:8000/",wait_until="load",timeout=180000)
    page.wait_for_function("window.__ready || document.querySelector('#loadErrorOverlay')",timeout=180000)
    assert page.evaluate("window.__ready"), page.locator("#loadErrorOverlay").inner_text()
    assert not errors, errors
    return page,errors

def ready(page):
    page.wait_for_function("window.__ready",timeout=180000)
    page.evaluate("async()=>{await RoseachyStore.whenSaved();}")

def fixture(page, products=100, transactions=1000):
    # Synthetics only, generated deterministically with stable identifiers.
    page.evaluate("""async ({products,transactions})=>{
      const T=__test,R=RoseachyStore;
      await R.whenSaved();
      R.setCommitObserver(null); // Fixture setup must not manufacture sync events.
      const date=document.getElementById('date').value;
      const stock=Array.from({length:products},(_,i)=>T.normalizeProduct({
        id:'fixture-product-'+i,name:'Product '+String(i).padStart(5,'0')+' tablets 500mg',
        division:i%2?'pharmacy':'essentials',qty:10000,costPrice:60,currentCostPrice:60,price:100,
        packEnabled:true,unitsPerPack:12,packRepresentationVersion:1,
        batches:[{id:'fixture-batch-'+i,qty:10000,costPrice:60,createdAt:'2026-01-01T00:00:00.000Z'}]
      }));
      const customers=Array.from({length:20},(_,i)=>({id:'fixture-customer-'+i,name:'Customer '+i,
        phone:'',startingBalance:0,startingConfirmed:false,creditLimit:null,createdAt:'2026-01-01T00:00:00.000Z'}));
      const saved=[];
      for(let day=0;day<Math.ceil(transactions/100);day++){
        const d=new Date(Date.UTC(2024,0,1+day)).toISOString().slice(0,10);
        const rows=Array.from({length:Math.min(100,transactions-day*100)},(_,j)=>{
          const i=day*100+j,p=stock[i%products],credit=i%10===0;
          return {id:'fixture-tx-'+i,type:credit?'sale_account':'sale_cash',domain:'retail',refKind:'product',
            productId:p.id,productName:p.name,note:p.name,party:'',qty:1,amount:100,unitPrice:100,
            unitSellingPrice:100,costSnapshot:60,costTotal:60,division:p.division,
            ts:d+'T12:00:'+String(j%60).padStart(2,'0')+'.000Z',
            ...(credit?{creditCustomerId:customers[i%20].id,purchaseGroupId:'fixture-group-'+i,
              creditPaymentMethod:'cash',splitCash:0,splitBank:0,splitCredit:100}:{})};
        });
        saved.push({id:'fixture-day-'+day,date:d,business:'Fixture Store',tx:rows,archived:false,
          openingCash:0,posOpeningCash:0,posOpeningElectronic:0,openingDebt:0,
          openingSupplierPayable:0,openingStock:{},closingStock:{},savedAt:d+'T23:00:00.000Z'});
      }
      await R.atomic(()=>{
        T.setStock(stock);T.setSaved(saved);
        R.set('roseachy_credit_customers_v1',JSON.stringify(customers));
        T.setTx([]);T.setOpening(T.stockSnapshot(stock));
        document.getElementById('openingCash').value='100000';
        document.getElementById('openingDebt').value='0';
        T.saveDraft();
      });
      await R.whenSaved();
    }""",{"products":products,"transactions":transactions})
    page.reload(wait_until="load",timeout=180000)
    ready(page)

def launch(p):
    return p.chromium.launch(executable_path="/usr/bin/chromium",headless=True,
        args=["--no-sandbox","--enable-precise-memory-info"])
