from common import *
with sync_playwright() as p:
 b=launch(p);c=context_for(b,'app');page,err=open_page(c);page.set_viewport_size({'width':1280,'height':720})
 
 for desk in ['market','financial','settings']:
  page.locator('#deskMenuBtn').click();page.locator('[data-desk="'+desk+'"]').click()
 e=page.locator('[data-theme-choice="cobalt"]')
 try:e.click(timeout=6000);print('CLICK PASSED')
 except Exception as ex:print(str(ex)[-1800:])
 for i in range(8):
  print(page.evaluate('''()=>{const e=document.querySelector('[data-theme-choice="cobalt"]'),p=document.getElementById('settingsStickyPreview');return{scroll:scrollY,rect:e.getBoundingClientRect().toJSON(),preview:p.getBoundingClientRect().toJSON(),class:p.className,transform:getComputedStyle(e).transform,translate:getComputedStyle(e).translate}}'''));page.wait_for_timeout(100)
 page.screenshot(path=str(ROOT/'results/settings-debug.png'));b.close()
