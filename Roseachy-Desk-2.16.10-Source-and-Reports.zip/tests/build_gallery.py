from pathlib import Path
import base64,html
r=Path(__file__).resolve().parents[1];parts=['''<!doctype html><html lang="en"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Roseachy 2.16.10 — Visual verification</title><style>body{font:16px/1.5 system-ui;margin:0;background:#f4f5f7;color:#19202e}main{max-width:1300px;margin:auto;padding:24px}h1{font-size:28px}section{margin:32px 0;padding:20px;background:white;border:1px solid #cbd0d8;border-radius:12px}.pair{display:grid;grid-template-columns:1fr 1fr;gap:16px}figure{margin:0}img{width:100%;height:auto;border:1px solid #ddd}figcaption{font-weight:600;margin-bottom:8px}summary{cursor:pointer;font-weight:600}p{max-width:850px}@media(max-width:600px){.pair{grid-template-columns:1fr}}</style><main><h1>Roseachy Desk 2.16.10</h1><p>Actual Chromium screenshots with synthetic data. Matched pairs compare 2.16.9 with the primary-card and precise-appearance refinement. Six themes and both modes remain supported. These samples illustrate the changes; the complete automated matrix and additional screenshots are in the source and reports download.</p>''']
def img(p,label):
 return '<figure><figcaption>'+html.escape(label)+'</figcaption><img loading="lazy" alt="'+html.escape(label)+'" src="data:image/png;base64,'+base64.b64encode(p.read_bytes()).decode()+'"></figure>'
for file in ['390-cobalt-light-financial.png','390-pearl-light-financial.png','390-ember-light-sales.png','1280-cobalt-light-reports.png','total-ember-light.png','input-ember-hover.png']:
 label=file[:-4].replace('-',' ');parts.append('<section><h2>'+label+'</h2><div class="pair">')
 for state,caption in [('before','Before · 2.16.9'),('after','After · 2.16.10')]:parts.append(img(r/'results/screenshots'/state/file,caption))
 parts.append('</div></section>')
parts.append('<section><h2>Precise appearance controls</h2><p>Actual settings and financial cards at slider values 0, 25, 50, 75 and 100. Both controls are set to the labelled value; normal defaults are 55 roundness and 30 border thickness.</p><div class="pair">')
for file in ['precise-settings.png','appearance-stop-0.png','appearance-stop-25.png','appearance-stop-50.png','appearance-stop-75.png','appearance-stop-100.png']:
 parts.append(img(r/'results/screenshots/after'/file,file[:-4].replace('-',' ')))
parts.append('</div></section><p>Limits: Chromium in this environment only. Physical devices, Safari/Firefox, and live Cloudflare deployment were not tested. Direct file URLs are blocked by the managed browser; standalone HTML was tested over local HTTP with no external requests.</p></main></html>')
(r/'deliverables/Roseachy-Desk-2.16.10-Visual-Report.html').write_text(''.join(parts));print('Gallery written')
