# ROSEACHY DESK — UX Refinements & Workflow Improvements

## Primary Objective

Improve Roseachy Desk's usability, speed, and precision by simplifying existing interactions and removing unnecessary steps.

**Implementation philosophy:** Every improvement must be simple, intuitively brilliant, efficient, and precise.

Do not overengineer solutions or introduce unnecessary complexity. Prefer small, intelligent changes to existing components and logic rather than building new systems.

Preserve existing functionality, data integrity, calculations, transaction records, and visual consistency.

## 1. Direct Editing of Individual Cart Items

When a user opens **Edit Cart**, every product in that cart must be individually selectable and editable.

- Clicking a product should activate editing for that specific product.
- Allow changes to quantity and other existing editable item properties, such as unit price where applicable.
- Changes must immediately reflect in the cart calculations.
- Saving must correctly update the existing transaction without creating duplicate records.
- Other cart items must remain unchanged unless individually edited.

**Expected behavior:** Click an item → edit its details → save. No unnecessary navigation or additional steps.

## 2. Replace the Two Cart Buttons With One Intelligent Button

Currently, the "Add to Cart" button opens the cart without adding the active product, while the "Add Item" button actually adds products.

This is unintuitive and unnecessarily complicated.

Replace this arrangement with **one unified "Add to Cart" button**.

### Required Behavior

- When a product is active or selected, clicking "Add to Cart" must immediately add that product to the cart and open or display the cart.
- The same button must add subsequently selected products to the existing cart.
- Products added to the cart must be displayed immediately.
- Every added product must have a small, clearly recognizable remove control.
- Removing a product must immediately update the cart and totals.
- If a product already exists in the cart, adding it again should increase its quantity rather than unnecessarily duplicating its row.
- Opening or reviewing an existing cart must not accidentally add another product.

Eliminate the redundant button and its unnecessary interaction logic.

**Goal:** One button handles adding products consistently, whether adding the first item or subsequent items.

## 3. Add a Clear Control to Product Suggestive Search

Improve the existing product suggestion/search input.

- When a product is selected, display a small **×** control inside or beside the selected product field.
- Clicking × must clear the selection immediately.
- Users should not need to repeatedly press Backspace.
- Clearing a selection must reset the relevant product input state without affecting products already added to the cart.
- Keep the control compact and visually consistent.

## 4. Collapsible and Editable Notes

Improve the existing notes functionality.

- Notes should be collapsible by default where appropriate.
- Clicking a note or its expansion control should reveal its full content.
- Expanded notes should be directly editable through a simple, obvious interaction.
- Allow users to save their changes without unnecessary dialogs.
- Whenever a note is successfully edited and saved, automatically update its **Last Saved** date to the current date.
- Keep the original creation date internally if it is already stored.
- Preserve existing notes and their content.

Use the existing notes structure wherever possible.

## 5. Subtle Highlighting of Cart Products in Record Tables

Improve the readability of grouped cart transactions in record tables.

- Products belonging to the same cart transaction should have a subtle visual distinction.
- Use a slightly tinted background or another restrained highlight consistent with the active theme.
- Ensure text remains readable.
- Avoid bright colors, thick borders, unnecessary badges, or excessive visual decoration.
- Preserve existing sorting, filtering, and table interactions.

**Goal:** Users should recognize products belonging to the same cart at a glance.

## 6. Refine Credit History Interface

### A. Reduce Private Credit Accounts Prominence

The existing element containing:

"Open private Credit Accounts"

"Private account purchases stay in their dedicated history"

currently draws more attention than necessary.

Make it visually quieter.

- Reduce unnecessary emphasis, contrast, and visual weight.
- Retain its functionality and accessibility.
- Use compact, secondary-level styling.
- Maintain consistency with the surrounding Credit History interface.

### B. Hide Total Outstanding by Default

In Credit History, **Total Outstanding** should not be immediately visible.

- Mask or hide the monetary amount by default.
- Provide a simple checkbox labeled "Show Total Outstanding."
- When checked, reveal the amount.
- When unchecked, hide it again.
- Ensure hiding the amount only affects visibility, not calculations or stored values.

Keep this feature discreet and straightforward.

## 7. Validate Amount Paid Before Applying Supplier Purchases

In **Market Desk**, when supplier purchases are reviewed for payment, improve the "Amount Paid" input interaction.

### Required Behavior

- The "Amount Paid" field must require an explicitly entered, valid numeric value before "Apply Selected" can proceed.
- If the field is empty, prevent the transaction from being applied.
- Draw attention to the field using a brief, subtle blinking or pulsing highlight.
- Clearly indicate that an amount must be entered.
- Stop the animation once the user enters a valid amount.
- If zero payment is legitimately supported for a fully credit-based supplier purchase, allow an explicitly entered `0`; do not treat an untouched empty field as zero.
- Preserve existing supplier credit, outstanding balance, and payment calculations.

The visual prompt must be noticeable but not distracting. Respect reduced-motion preferences.

**Goal:** Prevent accidental submissions caused by an overlooked payment field.

## 8. Hide Internal Cart Group Identifiers

Roseachy Desk generates internal cart identifiers such as:

`Cart grp-745d841f-f3a9-473c-bf91-0c0366523d72`

These identifiers are useful internally for associating multiple products with the same cart transaction, but they are not meaningful to users.

### Required Behavior

- Do not display raw cart group identifiers when editing cart purchases.
- Keep these identifiers fully functional internally.
- Preserve relationships between grouped products and their transactions.
- Do not modify existing identifiers or introduce unnecessary database changes.
- If a transaction needs a visible heading, use a simple user-friendly label such as "Cart Purchase" rather than its internal identifier.

**Important:** Hide the technical identifier from the interface without removing or breaking its underlying functionality.

---

## Implementation Rules

1. **Simplicity first:** Prefer the smallest effective change.
2. **Reuse existing logic:** Modify existing components, handlers, and styles rather than duplicating them.
3. **No unnecessary UI:** Avoid extra buttons, popups, confirmation dialogs, and navigation steps.
4. **Maintain consistency:** Preserve the application's existing visual language and theme compatibility.
5. **Protect data:** Existing sales, purchases, credit records, cart groups, balances, and notes must remain intact.
6. **Keep interactions immediate:** Updates should be responsive, predictable, and clearly reflected in the interface.
7. **Avoid regressions:** Do not break unrelated functionality while implementing these changes.
8. **Remove redundant code:** Safely clean up obsolete handlers or styling made unnecessary by the improvements.

## Final Verification

After implementation, test the affected workflows end to end.

Specifically verify that:

- Individual cart items can be edited and saved correctly.
- The single Add to Cart button works for first and subsequent items.
- Products can be removed without disrupting the cart.
- Product selections can be cleared using ×.
- Notes collapse, expand, edit, save, and update their last-saved dates.
- Cart transactions remain correctly grouped and subtly highlighted.
- Credit balances remain accurate while hidden or revealed.
- Supplier purchases cannot be applied with an empty Amount Paid field.
- Internal cart identifiers are hidden without breaking transaction relationships.
- Existing records, calculations, and other application features continue to work.

**Final expectation:** The improvements should feel naturally integrated into Roseachy Desk, as though these interactions had always been part of the original design.

The result should be simpler to use, faster to operate, visually cleaner, and technically reliable — not more complicated.