from common import *
import traceback
result={'checks':[]};out=ROOT/'results/compatibility-ui.json';shots=ROOT/'results/screenshots';shots.mkdir(exist_ok=True)
def record(name,detail=True):
 result['checks'].append({'name':name,'status':'passed','detail':detail});out.write_text(json.dumps(result,indent=2));print('PASS',name,flush=True)
with sync_playwright() as p:
 b=launch(p)
 try:
  c=context_for(b,'original');old,old_errors=open_page(c);fixture(old,4,0);old.on('dialog',lambda d:d.accept())
  old.evaluate("""async()=>{const T=__test,$=id=>document.getElementById(id);$('type').value='sale_cash';T.resetTxForm();for(const [i,q]of [[0,2],[1,3]]){T.chooseProductSuggestion(T.getStock()[i]);$('qty').value=q;T.computeTotal();$('holdBtn').click();}$('holdCustPaid').value=100;$('addBtn').click();await T.RS.whenSaved()}""")
  old.wait_for_function('!__test.busy');backup=old.evaluate('()=>__test.roseachySafeBackup()');(ROOT/'results/original-2.16.9-backup.json').write_text(json.dumps(backup));assert not old_errors,old_errors;c.close()
  c=context_for(b,'app');new,errors=open_page(c);new.on('dialog',lambda d:d.accept());new.on('download',lambda d:d.save_as(str(ROOT/'results'/d.suggested_filename)))
  assert new.evaluate('d=>__test.restoreFullBackup(d,{confirmRestore:false})',backup)
  values=new.evaluate('()=>({debts:__test.creditHistoryObligations().map(d=>[d.total,d.original,d.balance]),tx:__test.tx.map(t=>[t.id,t.amount,t.qty]),stock:__test.getStock().map(p=>p.qty)})')
  assert values['debts']==[[500,400,400]],values
  assert values['tx']==[[t['id'],t['amount'],t['qty']] for t in backup['draft']['tx']]
  record('Actual 2.16.9 backup restores unchanged line IDs/prices/stock with one derived cart obligation',values['debts'])
  assert not errors,errors;c.close()
  for profile in ['desktop','mobile']:
   c=context_for(b,'app',profile);page,errors=open_page(c);fixture(page,3,0);page.on('dialog',lambda d:d.accept())
   page.evaluate("""async()=>{const T=__test,rows=[0,1].map(i=>({id:'ui-'+i,type:'sale_cash',purchaseGroupId:'ui-cart',domain:'retail',refKind:'product',productId:'fixture-product-'+i,note:'Product '+i,productName:'Product '+i,amount:100,qty:1,unitPrice:100,unitSellingPrice:100,costSnapshot:60,division:'essentials',ts:new Date().toISOString()}));await T.inventoryCommit(()=>{const e=T.commitSalesLedger(rows);if(e)throw Error(e);return true},'Sales Desk')}""")
   cases=[]
   for theme in ['cobalt','ember','pearl','cyanflux','coralbank','monomint']:
    for mode in ['light','dark']:
     page.evaluate('v=>__test.saveAppearanceSettings({...__test.getAppearanceSettings(),theme:v.theme,colorMode:v.mode},false)',{'theme':theme,'mode':mode})
     for overlay in ['cartCorrectionOverlay','setupCorrectionOverlay']:
      page.evaluate("id=>{if(id==='cartCorrectionOverlay'){__test.switchDesk('sales');__test.CartCorrections.open('ui-cart')}else{__test.switchDesk('settings');__test.DailySetup.open()}}",overlay)
      page.locator('#'+overlay).wait_for(state='visible')
      bounds=page.locator('#'+overlay+' .marketPanel').bounding_box();width=page.viewport_size['width'];assert bounds and bounds['x']>=-1 and bounds['x']+bounds['width']<=width+1,(profile,theme,mode,overlay,bounds)
      overflow=page.locator('#'+overlay+' .marketPanel').evaluate('(e)=>e.scrollWidth>e.clientWidth+2');assert not overflow,(profile,theme,mode,overlay,'overflow')
      page.locator('#'+overlay).screenshot(path=str(shots/f'{profile}-{theme}-{mode}-{overlay}.png'),animations='disabled')
      close='cartCorrectionClose' if overlay=='cartCorrectionOverlay' else 'setupCorrectionClose'
      page.locator('#'+close).focus();page.keyboard.press('Shift+Tab');assert page.evaluate('document.activeElement.id') in ['cartCorrectionSave','setupCorrectionSave'],'focus trap'
      page.keyboard.press('Escape');assert not page.locator('#'+overlay).is_visible()
      cases.append([theme,mode,overlay])
   record(profile+' correction dialogs: 24 theme/mode cases fit viewport; focus trap and Escape work',cases)
   assert not errors,errors;c.close()
  result['status']='passed'
 except Exception as e:result['status']='failed';result['error']=str(e);traceback.print_exc()
 finally:out.write_text(json.dumps(result,indent=2));b.close()
raise SystemExit(0 if result.get('status')=='passed' else 1)
