from visual_support import *
with sync_playwright() as p:
 b=launch(p);c=context_for(b,'app');page,e=open_page(c);seed(page);page.set_viewport_size({'width':320,'height':900});theme(page,'cyanflux','light');screen(page,'market');page.evaluate("()=>{const e=document.getElementById('marketDebtSummary');e.classList.remove('hidden');e.textContent='Supplier Payments Outstanding · 1 purchase · ₦600.00 · View in Suppliers'}")
 print(page.locator('#marketDebtSummary').evaluate("e=>{const s=getComputedStyle(e),r=document.createRange();r.selectNodeContents(e);return {height:s.height,padding:s.padding,clientHeight:e.clientHeight,scrollHeight:e.scrollHeight,rect:e.getBoundingClientRect().toJSON(),text:r.getBoundingClientRect().toJSON()}}"));b.close()
