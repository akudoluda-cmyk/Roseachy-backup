from pathlib import Path
import subprocess,json,sys,hashlib,time
root=Path(__file__).resolve().parents[1]
commands=[['node','static_check.cjs'],*[['python',s,*args] for s,args in [('ux_workflows.py',[]),('cart_items.py',[]),('pricing.py',['app']),('cart_setup.py',[]),('credit_analytics.py',[]),('payment_matrix.py',[]),('safety.py',[]),('regression.py',['app']),('sync.py',[]),('item_sync.py',[]),('ux_mobile.py',[]),('compatibility_ui.py',[]),('pwa_update.py',[])]]]
status={'sourceSHA256':hashlib.sha256((root/'app/index.html').read_bytes()).hexdigest(),'jobs':[]}
for cmd in commands:
 print('RUN',' '.join(cmd),flush=True)
 start=time.time();p=subprocess.run(cmd,cwd=root/'tests',capture_output=True,text=True,timeout=420)
 (root/'results'/('final-'+cmd[1]+'.log')).write_text(p.stdout+p.stderr)
 status['jobs'].append({'command':' '.join(cmd),'exitCode':p.returncode,'seconds':round(time.time()-start,2)})
 (root/'results/final-validation.json').write_text(json.dumps(status,indent=2))
 print('DONE',cmd[1],p.returncode,flush=True)
 if p.returncode:print((p.stdout+p.stderr)[-4000:],flush=True)
status['passed']=all(x['exitCode']==0 for x in status['jobs']);(root/'results/final-validation.json').write_text(json.dumps(status,indent=2));sys.exit(0 if status['passed'] else 1)
